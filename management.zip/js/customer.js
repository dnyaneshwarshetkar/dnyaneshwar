$(document).ready(function() {
	// Setup - add a text input to each footer cell
	params = getAllUrlParams(window.location.href);
	if(!!params['customer_id']){
		
	}
    $('#customerTable tfoot th').each( function () {
        var title = $(this).text();
        $(this).html( '<input type="text" class="form-control" placeholder="Search '+title+'" />' );
    } );
	var table = $('#customerTable').DataTable( {
		paging :true,
		searchng : true,
		ajax: {
				url: "server/get_data.php?customer=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
        columns: [
			{ data: "user_id"},
			{ data: "customer_id"},
            { data: "first_name"},
            { data: "middle_name" },
            { data: "last_name" },
            { data: "organization_name" },
            { data: "address" },
            { data: "taluka"},
			{ data: "district"},
			{data:  "mobile"},
			{data:  "email"},
			{data:  "customer_id"},
        ],
		'columnDefs': [{'targets':0,
		'searchable' : true,
		'orderable':true,
		},{
		   'targets': 11,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   return '<button value="' + $('<div/>').text(data).html() + '" onclick="editCustomer(this.value)" class="btn btn-success btn-sm"  title="Edit Customer"><i class="fa fa-edit"></i></button><button value="' + $('<div/>').text(data).html() + '" onclick="deleteCustomer(this.value)"  class="btn btn-success btn-sm" title="Delete Customer"><i class="fa fa-trash-o"></i></button>';
		   }
		}]
    });
	// Apply the search
    table.columns().every( function () {
        var that = this;
 
        $( 'table input', this.footer() ).on( 'keyup change', function () {
            if ( that.search() !== this.value ) {
                that
                    .search( this.value )
                    .draw();
            }
        } );
    } );
});
//submit Function For Inserting General Information,Address,Education,Bank Details
var submitData = function(event,user_id){
	event.preventDefault();
	if(!user_id){
		var url = "server/put_data.php?customer=true&submit=true"; 
	}else{
		var url = "server/put_data.php?customer=true&update=true?user_id="+user_id;
	}
	var formData = {};
	var x = $('#customersForm').serializeArray();
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	var formData = JSON.stringify(formData);
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data){
			  alert(data);
			  $("#customerModal").modal('hide');
			  window.location.href="customer.php";
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
var editCustomer = function(x){
	$("#customerModal").modal();
}
var deleteCustomer = function(x){
	if (confirm('Are you sure you are going to Delete?')) {
		$.ajax({
		  type: "POST",
		  url: "server/delete_data.php?customer_id="+x,
		  data: null,
		  success: function(data){
			   var response = JSON.parse(data);
			   alert(response["message"]);
			   location.reload(true);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
	} else {
		alert('Why did you press cancel? You should have confirmed');
	}
}
var getAllUrlParams = function (url) {

  // get query string from url (optional) or window
  var queryString = url ? url.split('?')[1] : window.location.search.slice(1);

  // we'll store the parameters here
  var obj = {};

  // if query string exists
  if (queryString) {

    // stuff after # is not part of query string, so get rid of it
    queryString = queryString.split('#')[0];

    // split our query string into its component parts
    var arr = queryString.split('&');

    for (var i=0; i<arr.length; i++) {
      // separate the keys and the values
      var a = arr[i].split('=');

      // in case params look like: list[]=thing1&list[]=thing2
      var paramNum = undefined;
      var paramName = a[0].replace(/\[\d*\]/, function(v) {
        paramNum = v.slice(1,-1);
        return '';
      });

      // set parameter value (use 'true' if empty)
      var paramValue = typeof(a[1])==='undefined' ? true : a[1];

      // (optional) keep case consistent
      paramName = paramName.toLowerCase();
      paramValue = paramValue.toLowerCase();

      // if parameter name already exists
      if (obj[paramName]) {
        // convert value to array (if still string)
        if (typeof obj[paramName] === 'string') {
          obj[paramName] = [obj[paramName]];
        }
        // if no array index number specified...
        if (typeof paramNum === 'undefined') {
          // put the value on the end of the array
          obj[paramName].push(paramValue);
        }
        // if array index number specified...
        else {
          // put the value at that index number
          obj[paramName][paramNum] = paramValue;
        }
      }
      // if param name doesn't exist yet, set it
      else {
        obj[paramName] = paramValue;
      }
    }
  }

  return obj;
}