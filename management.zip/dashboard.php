<?php
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
	<div class="content-wrapper">
		<div class="container-fluid">
		  <!-- Breadcrumbs-->
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.html">dashboard</a></li>
				<li class="breadcrumb-item active">Home</li>
			</ol>
			<div class="row">
				<div class="col-sm">
					<div class="card  text-center">
					  <img class="card-img-top" src="images/employee.jpg" alt="Employee">
					  <div class="card-body">
						<h5 class="card-title">Employee</h5>
						<p class="card-text">Add,Edit,View,Delete Employee Details</p>
						<a href="employee.php" class="btn btn-primary">Change Employee</a>
					  </div>
					</div>
				</div>
				<div class="col-sm">
					<div class="card  text-center">
					  <img class="card-img-top" src="images/customer.jpg" alt="Customer">
					  <div class="card-body">
						<h5 class="card-title">Customer</h5>
						<p class="card-text">Add,Edit,View,Delete Cutomer Details</p>
						<a href="customer.php" class="btn btn-primary">Change Customer</a>
					  </div>
					</div>
				</div>
				<div class="col-sm">
					<div class="card text-center">
					  <img class="card-img-top" src="images/profile.jpg" alt="Profile">
					  <div class="card-body">
						<h5 class="card-title">Profile</h5>
						<p class="card-text">Add, View, Edit, Delete Profile Details</p>
						<a href="profile.php" class="btn btn-primary">Change Profile</a>
					  </div>
					</div>
				</div>
			</div>
		</div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
