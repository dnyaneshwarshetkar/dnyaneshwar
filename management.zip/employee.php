<?php
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
	<div class="content-wrapper">
		<div class="container-fluid">
		  <!-- Breadcrumbs-->
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.html">dashboard</a></li>
				<li class="breadcrumb-item active">Home</li>
			</ol>
			<div class="row">
			<div class="table-responsive">
              <table class="table table-bordered display" style="width:100%" id="employeeTable" width="100%" cellspacing="0">
				<caption>Employee List</caption>
                <thead>
                  <tr>
					<th>User Id</th>
                    <th>First Name</th>
                    <th>Middle Name</th>
                    <th>Last Name</th>
					<th>User Type</th>
					<th>Mobile</th>
					<th>Email</th>
					<th>Password</th>
					<th>Manage</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
				<tfoot>
					<tr>
					<th>User Id</th>
                    <th>First Name</th>
                    <th>Middle Name</th>
                    <th>Last Name</th>
					<th>User Type</th>
					<th>Mobile</th>
					<th>Email</th>
					<th>Password</th>
					<th>Manage</th>
					</tr>
                </tfoot>
              </table>
            </div>
			</div>
		</div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/employee.js"></script>
</body>

</html>
