<?php
require_once("..\connect.php");
session_start();
if(isset($_GET['profile'])){
	echo json_encode($_SESSION['user']);
}
if(isset($_GET['employee'])){
	$return = array();
	$query = mysqli_query($con,"SELECT * FROM users");
	while($row = mysqli_fetch_assoc($query)){
		array_push($return,$row);
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['customer'])){
	$return = array();
	$query = mysqli_query($con,"SELECT * FROM customer");
	while($row = mysqli_fetch_assoc($query)){
		array_push($return,$row);
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['address'])){
	$return = array();
	$user_id = $_GET['user_id'];
	$query = mysqli_query($con,"SELECT * FROM address where user_id=$user_id");
	while($row = mysqli_fetch_assoc($query)){
		array_push($return,$row);
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['education'])){
	$return = array();
	$user_id = $_GET['user_id'];
	$query = mysqli_query($con,"SELECT * FROM education where user_id=$user_id");
	while($row = mysqli_fetch_assoc($query)){
		array_push($return,$row);
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['edit_employee'])){
	$return = array();
	$user_id = $_GET['user_id'];
	$query = mysqli_query($con,"SELECT * FROM users where user_id=$user_id");
	$row = mysqli_fetch_assoc($query);
	$return = json_encode($row);
	echo $return;
}
?>