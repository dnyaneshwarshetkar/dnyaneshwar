<?php
include('../connect.php');
session_start();
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
if(isset($_GET["profile"])){
	$first_name = $decoded["first_name"];
	$middle_name = $decoded["middle_name"];
	$last_name = $decoded["last_name"];
	$email = $decoded["email"];
	$mobile = $decoded["mobile"];
	$password = $decoded["password"];
	$user_id = $_SESSION['user']['user_id'];
	$sql = "Update users set first_name='$first_name',middle_name='$middle_name',last_name='$last_name',email='$email',mobile='$mobile',password='$password' where user_id = '$user_id'";
	if($con->query($sql)){
		$_SESSION['user']['first_name'] = $decoded["first_name"];
		$_SESSION['user']['middle_name'] = $decoded["middle_name"];
		$_SESSION['user']['last_name'] = $decoded["last_name"];
		$_SESSION['user']['email'] = $decoded["email"];
		$_SESSION['user']['mobile'] = $decoded["mobile"];
		$_SESSION['user']['password'] = $decoded["password"];
		echo "Success"; 
	}
	else{
	
	echo mysqli_error($con);
	
	}
}
if(isset($_GET["address"])){
	if(isset($_GET['submit'])){
		$address = $decoded["address"];
		$at = $decoded["at"];
		$post = $decoded["post"];
		$taluka = $decoded["taluka"];
		$district = $decoded["district"];
		$state = $decoded["state"];
		$pincode = $decoded["pincode"];
		$user_id = $_GET['user_id'];
		$status = 1;
		$sql = "Insert into address(address,user_id,at,post,taluka,district,state,pincode,status)values('$address','$user_id','$at','$post','$taluka','$district','$state','$pincode','$status')";
		if($con->query($sql)){
			echo "Address Submitted Successfully"; 
		}
		else{
			echo mysqli_error($con);
		}
	}
	if(isset($_GET['update'])){
		$address = $decoded["address"];
		$at = $decoded["at"];
		$post = $decoded["post"];
		$taluka = $decoded["taluka"];
		$district = $decoded["district"];
		$state = $decoded["state"];
		$pincode = $decoded["pincode"];
		$user_id = $_GET['user_id'];
		$address_id = $_GET['address_id'];
		$sql = "update address set address='$address',at='$at',post='$post',taluka='$taluka',district='$district',state='$state',pincode='$pincode' where address_id ='$address_id')";
		if($con->query($sql)){
			echo "Address Updated Successfully"; 
		}
		else{
			echo mysqli_error($con);
		}
	}
}
if(isset($_GET["education"])){
	if(isset($_GET['submit'])){
		$at = $decoded["at"];
		$post = $decoded["post"];
		$taluka = $decoded["taluka"];
		$district = $decoded["district"];
		$state = $decoded["state"];
		$pincode = $decoded["pincode"];
		$user_id = $_SESSION['user']['user_id'];
		$sql = "Insert into address(user_id,at,post,taluka,district,state,pincode)values('$user_id','$at','$post','$taluka','$district','$state','$pincode')";
		if($con->query($sql)){
			echo "SUCCESS"; 
		}
		else{
			echo mysqli_error($con);
		}
	}
	if(isset($_GET['update'])){
		$at = $decoded["at"];
		$post = $decoded["post"];
		$taluka = $decoded["taluka"];
		$district = $decoded["district"];
		$state = $decoded["state"];
		$pincode = $decoded["pincode"];
		$user_id = $_SESSION['user']['user_id'];
		$sql = "update address set at='$at',post='$post',taluka='$taluka',district='$district',state='$state',pincode='$pincode' where user_id ='$user_id'";
		if($con->query($sql)){
			echo "SUCCESS"; 
		}
		else{
			echo mysqli_error($con);
		}
	}
}
if(isset($_GET['employee'])){
	if(isset($_GET['submit'])){
		$first_name = $decoded["first_name"];
		$middle_name = $decoded["middle_name"];
		$last_name = $decoded["last_name"];
		$user_type = $decoded["user_type"];
		$email = $decoded["email"];
		$password = $decoded["password"];
		$mobile = $decoded["mobile"];
		$status = 1;
		$sql = "Insert into users(first_name,middle_name,last_name,user_type,email,password,mobile,status)values('$first_name','$middle_name','$last_name','$user_type','$email','$password','$mobile','$status')";
		if($con->query($sql)){
			echo "SUCCESS"; 
		}
		else{
			echo mysqli_error($con);
		}
	}
	if(isset($_GET['update'])){
		$first_name = $decoded["first_name"];
		$middle_name = $decoded["middle_name"];
		$last_name = $decoded["last_name"];
		$user_type = $decoded["user_type"];
		$email = $decoded["email"];
		$password = $decoded["password"];
		$mobile = $decoded["mobile"];
		$user_id = $_GET['user_id'];
		$sql = "Update users set first_name = '$first_name',middle_name='$middle_name',last_name='$last_name',user_type='$user_type',email='$email',password='$password',mobile='$mobile'where user_id ='$user_id'";
		if($con->query($sql)){
			echo ""; 
		}
		else{
			echo mysqli_error($con);
		}
	}
}
if(isset($_GET['customer'])){
	if(isset($_GET['submit'])){
		$first_name = $decoded["first_name"];
		$middle_name = $decoded["middle_name"];
		$last_name = $decoded["last_name"];
		$address = $decoded["address"];
		$email = $decoded["email"];
		$mobile = $decoded["mobile"];
		$organization_name = $decoded["organization_name"];
		$taluka = $decoded["taluka"];
		$district = $decoded["district"];
		$user_id = $_SESSION["user"]["user_id"];
		$status = 1;
		$sql = "Insert into customer(first_name,middle_name,last_name,email,mobile,organization_name,user_id,status,address,taluka,district)values('$first_name','$middle_name','$last_name','$email','$mobile','$organization_name','$user_id','$status','$address','$taluka','$district')";
		if($con->query($sql)){
			echo "Customer Inserted Successfully"; 
		}
		else{
			echo mysqli_error($con);
		}
	}
	if(isset($_GET['update'])){
		$first_name = $decoded["first_name"];
		$middle_name = $decoded["middle_name"];
		$last_name = $decoded["last_name"];
		$user_type = $decoded["user_type"];
		$email = $decoded["email"];
		$password = $decoded["password"];
		$mobile = $decoded["mobile"];
		$user_id = $_GET['user_id'];
		$user_id = $_GET['user_id'];
		$sql = "Update customer set first_name = '$first_name',middle_name='$middle_name',last_name='$last_name',user_type='$user_type',email='$email',password='$password',mobile='$mobile'where user_id ='$user_id'";
		if($con->query($sql)){
			echo ""; 
		}
		else{
			echo mysqli_error($con);
		}
	}
}
 ?>