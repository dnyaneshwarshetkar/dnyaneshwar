<?php
	include('server/sessioncheck.php');
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
	<div class="content-wrapper">
		<div class="container-fluid">
		  <!-- Breadcrumbs-->
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="dashboard.html">Dashboard</a></li>
				<?php if(isset($_GET['user_id'])){?>
				<li class="breadcrumb-item active">Update Employee</li>
				<?php }else{?>
				<li class="breadcrumb-item active">Add Employee</li>
				<?php }?>
			</ol>
			<div class="row">
				<div class="col-md-12">
				<?php if(isset($_GET['user_id'])){?>
				<h5>Update Employee</h5>
				<?php }else{?>
				<h5>Add Employee</h5>
				<?php }?>
				<div id="accordion">
					<div class="card">
						<div class="card-header" id="generalInfo">
						  <h5 class="mb-0">
							<button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
							  General Information
							</button>
						  </h5>
						</div>

						<div id="collapseOne" class="collapse show" aria-labelledby="generalInfo" data-parent="#accordion">
						  <div class="card-body">
							<?php if(isset($_GET['user_id'])){?>
							<form  name="generalForm" id="generalForm" onsubmit="submitData(<?php echo $_GET['user_id']?>)">
							<?php }else{ ?>
							<form  name="generalForm" id="generalForm" onsubmit="submitData()">
							<?php } ?>
							  <div class="form-row">
								<div class="form-group col-sm-4">
								  <label for="first_name">First Name</label>
								  <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter First Name"required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="middle_name">Middle Name</label>
								  <input type="text" class="form-control" id="middle_name"  name="middle_name" placeholder="Enter Middle Name" required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="last_name">Last Name</label>
								  <input type="text" class="form-control" id="last_name"  name="last_name" placeholder="Enter Last Name" required>
								</div>
							  </div>
							  <div class="form-row">
								<div class="form-group col-sm-4">
								  <label for="email">Email</label>
								  <input type="email" class="form-control" id="email"  name="email" placeholder="Enter Email Address"required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="mobile">Mobile</label>
								  <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Enter Mobile Number" pattern="(7|8|9)\d{9}$"required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="password">Password</label>
								  <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" required>
								</div>
							  </div>
							  <div class="form-row">
								<div class="form-group col-sm-4">
								  <label for="user_type">User Type</label>
								  <select class="form-control custom-select" name="user_type" id="user_type">
										<option value="">Select User Type</option>
										<option value="admin">Admin</option>
										<option value="backoffice">Back Office</option>
										<option value="salesperson">Sales Person</option>
										<option value="developer">Developer</option>
									</select>
								</div>
							</div>
							  <!--<div class="form-row">
								<div class="form-group col-sm-4">
								  <label for="image">Profile Image</label>
								  <input type="file" class="form-control" id="image" name="image" placeholder="Choose Image"required>
								</div>
								<div class="form-group col-sm-4">
								  <img src="images/profile.jpg">
								</div>
							  </div>-->
							<?php if(isset($_GET['user_id'])){?>
							<button type="submit" class="btn btn-primary">Update</button>
							<?php }else{?>
							<button type="submit" class="btn btn-primary">Submit</button>
							  <?php }?>
							</form>
						  </div><!--card-body-->
						</div>
					</div>
					<?php if(isset($_GET['user_id'])){?>
					  <div class="card">
						<div class="card-header" id="address">
						  <h5 class="mb-0">
							<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
							  Address
							</button>
						  </h5>
						</div>
						<div id="collapseTwo" class="collapse" aria-labelledby="address" data-parent="#accordion">
						  <div class="card-body">
							<form  name="addressForm" id="addressForm" onsubmit="return submitAddress(event,<?php echo $_GET['user_id'] ?>)">
							<div class="form-row">
								<div class="form-group col-sm-12">
								  <label for="address">Address</label>
								  <input type="text" class="form-control" id="address" name="address" placeholder="Address"required>
								</div>
							</div>
							  <div class="form-row">
								<div class="form-group col-sm-4">
								  <label for="at">At</label>
								  <input type="text" class="form-control" id="at" name="at" placeholder="At"required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="post">Post</label>
								  <input type="text" class="form-control" id="post"  name="post" placeholder="Enter Post" required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="taluka">Taluka</label>
								  <input type="text" class="form-control" id="taluka"  name="taluka" placeholder="Enter Taluka" required>
								</div>
							  </div>
							  <div class="form-row">
								<div class="form-group col-sm-4">
								  <label for="district">District</label>
								  <input type="text" class="form-control" id="district"  name="district" placeholder="Enter District"required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="state">State</label>
								  <input type="text" class="form-control" id="state" name="state" placeholder="Enter State" required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="pincode">Pincode</label>
								  <input type="text" class="form-control" id="pincode" name="pincode" placeholder="Enter Pincode" required>
								</div>
							  </div>
							  <button type="submit" class="btn btn-primary">Submit</button>
							</form>
							<div class="table-responsive">
							  <table class="table table-bordered display" style="width:100%" width="100%" cellspacing="0" id="addressTable">
								<caption>Address List</caption>
								<thead>
								  <tr>
									<th>At</th>
									<th>Post</th>
									<th>Taluka</th>
									<th>District</th>
									<th>State</th>
									<th>Pincode</th>
									<th>Manage</th>
								  </tr>
								</thead>
								<tbody>
								</tbody>
							  </table>
							</div>
						  </div>
						</div>
					  </div>
					  <div class="card">
						<div class="card-header" id="educationDetails">
						  <h5 class="mb-0">
							<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
							  Educational Details
							</button>
						  </h5>
						</div>
						<div id="collapseThree" class="collapse" aria-labelledby="educationDetails" data-parent="#accordion">
						  <div class="card-body">
							<form  name="educationForm" id="educationForm" onsubmit="submitEducation()">
							  <div class="form-row">
								<div class="form-group col-sm-4">
								  <label for="education">Education</label>
								  <input type="text" class="form-control" id="education" name="education" placeholder="Education"required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="percentage">Percentage</label>
								  <input type="text" class="form-control" id="percentage"  name="percentage" placeholder="Enter Percentage" required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="result">Result</label>
								  <input type="text" class="form-control" id="result"  name="result" placeholder="Enter Result" required>
								</div>
							  </div>
							  <div class="form-row">
								<div class="form-group col-sm-4">
								  <label for="college">College</label>
								  <input type="text" class="form-control" id="college"  name="college" placeholder="Enter College"required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="certificate">Certificate</label>
								  <input type="text" class="form-control" id="certificate" name="certificate" placeholder="Enter Certificate" required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="taluka">Taluka</label>
								  <input type="text" class="form-control"name="taluka" placeholder="Enter Taluka" required>
								</div>
							</div>
							<div class="form-row">
								<div class="form-group col-sm-4">
								  <label for="district">District</label>
								  <input type="text" class="form-control" name="district" placeholder="Enter District" required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="state">State</label>
								  <input type="text" class="form-control" name="state" placeholder="Enter State" required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="pincode">Pincode</label>
								  <input type="text" class="form-control" name="pincode" placeholder="Enter Pincode" required>
								</div>
							</div>
							  <button type="button" class="btn btn-primary">Submit</button>
							</form>
							<div class="table-responsive">
							  <table class="table table-bordered display" style="width:100%" width="100%" cellspacing="0" id="educationTable">
								<caption>Educational Details</caption>
								<thead>
								  <tr>
									<th>Education</th>
									<th>Percentage</th>
									<th>Result</th>
									<th>College</th>
									<th>Certificate</th>
									<th>Taluka</th>
									<th>District</th>
									<th>State</th>
									<th>State</th>
								  </tr>
								</thead>
								<tbody>
								</tbody>
							  </table>
							</div>
						  </div>
						</div>
					  </div>
					  <div class="card">
						<div class="card-header" id="bankDetails">
						  <h5 class="mb-0">
							<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseThree">
							  Bank Details
							</button>
						  </h5>
						</div>
						<div id="collapseFour" class="collapse" aria-labelledby="bankDetails" data-parent="#accordion">
						  <div class="card-body">
							<form  name="bankForm" id="bankForm"onclick="submitBank()">
							  <div class="form-row">
								<div class="form-group col-sm-4">
								  <label for="ifsc">IFSC</label>
								  <input type="text" class="form-control" id="ifsc" name="ifsc" placeholder="IFSC"required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="micr">MICR</label>
								  <input type="text" class="form-control" id="micr"  name="micr" placeholder="Enter MICR" required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="account_number">Account Number</label>
								  <input type="text" class="form-control" id="account_number"  name="account_number" placeholder="Enter Account Number" required>
								</div>
							  </div>
							  <div class="form-row">
								<div class="form-group col-sm-4">
								  <label for="bank_name">Bank Name</label>
								  <input type="text" class="form-control" id="bank_name"  name="bank_name" placeholder="Enter Bank Name"required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="branch">Branch</label>
								  <input type="text" class="form-control" id="branch" name="branch" placeholder="Enter Branch" required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="pincode">Pincode</label>
								  <input type="text" class="form-control" name="pincode" placeholder="Enter Pincode" required>
								</div>
							  </div>
							  <div class="form-row">
							  <div class="form-group col-sm-4">
								  <label for="taluka">Taluka</label>
								  <input type="text" class="form-control" name="taluka" placeholder="Enter Taluka" required>
								</div>
								<div class="form-group col-sm-4">
								  <label for="district">District</label>
								  <input type="text" class="form-control" name="district" placeholder="Enter District" required>
								</div>
							  </div>
							  <button type="button" class="btn btn-primary">Submit</button>
							</form>
							<div class="table-responsive">
							  <table class="table table-bordered display" style="width:100%" width="100%" cellspacing="0" id="bankTable">
								<caption>Bank Details</caption>
								<thead>
								  <tr>
									<th>Account Number</th>
									<th>IFSC</th>
									<th>MICR</th>
									<th>Bank Name</th>
									<th>Branch</th>
									<th>Taluka</th>
									<th>District</th>
									<th>Pincode</th>
								  </tr>
								</thead>
								<tbody>
								</tbody>
							  </table>
							</div>
						  </div>
						</div>
					  </div>
					<?php }?>
				</div>
			</div>
			</div>
		</div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/addemployee.js"></script>
  </div>
</body>

</html>
