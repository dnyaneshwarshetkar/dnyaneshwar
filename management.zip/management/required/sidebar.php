<!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="index.html">OEMS</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="acc_stud_info.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseMulti1" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-sitemap"></i>
            <span class="nav-link-text">Student Registartion</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseMulti1">
            <li>
              <a href="acc_add_stud.php">Add Student</a>
            </li>
            <li>
              <a href="acc_stud_prof.php">Student Profile</a>
            </li>
          </ul>
        </li>
                      
                
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseMulti2" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-sitemap"></i>
            <span class="nav-link-text">Teacher Registration</span>
          </a>
           <ul class="sidenav-second-level collapse" id="collapseMulti2">
            <li>
              <a href="acc_add_tea.php">Add Teacher</a>
            </li>
            <li>
              <a href="acc_tea_prof.php">Teacher Profile</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseMulti3" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-sitemap"></i>
            <span class="nav-link-text">Fees</span>
          </a>
           <ul class="sidenav-second-level collapse" id="collapseMulti3">
            <li>
              <a href="acc_stud_info.php">Student information</a>
            </li>
            <li>
              <a href="acc_src_rec.php">Search Receipt</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="acc_bona.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Bonafide</span>
          </a> 
        </li>
		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseMulti4" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-sitemap"></i>
            <span class="nav-link-text">Exam</span>
          </a>
           <ul class="sidenav-second-level collapse" id="collapseMulti4">
				<li>
				  <a href="acc_add_exam.php">Add Exam</a>
				</li>
				<li>
				  <a href="acc_exams.php">Exams</a>
				</li>
				<li>
				  <a href="acc_add_class.php">Add Class</a>
				</li>
				<li>
				  <a href="acc_classes.php">Classes</a>
				</li>
				<li>
				  <a href="acc_add_subjects.php">Add Subject</a>
				</li>
				<li>
				  <a href="acc_subjects.php">Subjects</a>
				</li>
				<li>
				  <a href="acc_add_chapters.php">Add Chapters</a>
				</li>
				<li>
				  <a href="acc_chapters.php">Chapters</a>
				</li>
				<li>
				  <a href="acc_add_articles.php">Add Articles</a>
				</li>
				<li>
				  <a href="acc_articles.php">Articles</a>
				</li>
				<li>
				  <a href="acc_add_questions.php">Add Questions</a>
				</li>
				<li>
				  <a href="acc_questions.php">Questions</a>
				</li>
            </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseMulti4" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-sitemap"></i>
            <span class="nav-link-text">Reports</span>
          </a>
           <ul class="sidenav-second-level collapse" id="collapseMulti4">
            <li>
              <a href="acc_out_rep.php">Outstanding Report</a>
            </li>
            <li>
              <a href="acc_cus_rep.php">Custom Report</a>
            </li>
            <li>
              <a href="acc_col_rep.php">Collection Report</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="acc_time.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Timetable</span>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="logout.php">
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
        </li>
      </ul>
    </div>
  </nav>