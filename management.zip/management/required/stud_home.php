<?php
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('studentsidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Student Home</li>
      </ol>
      <div class="row">

      <div class="col-md-12">
         <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-table"></i> Student Homework</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th> Subject Name</th>
                    <th> Date</th>
                    <th> Status</th>
                  
                  </tr>

                </thead>
                <tbody>
                <?php
	include('connect.php');
	
	$sql1 = "SELECT
  `H`.`Home_id`      AS `Home_id`,
  `H`.`Content`      AS `Content`,
  `H`.`Class_id`     AS `Class_id`,
  `H`.`Date_Created` AS `Date_Created`,
  `S`.`Subject_Name` AS `Subject_Name`,
  `H`.`Status`       AS `Status`
FROM (`homework` `H`
   JOIN `subject` `S`
     ON ((`S`.`Subject_id` = `H`.`Sub_id`))) WHERE H.Class_id='$class'";
    $result = $con->query($sql1);
    while($row = $result->fetch_assoc()) 
      {
		echo "<tr>";
		echo "<td>".$row['Subject_Name']."</td>";
		echo "<td>".$row['Date_Created']."</td>";
		echo "<td>".$row['Content']."</td>";
		echo "</tr>";
      }
  ?>

                </tbody>
              </table>
            </div>
          </div>
          <div class="card-footer small text-muted"></div></div>
          </div>
      
    </div>
        
      </div>
      

 
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
