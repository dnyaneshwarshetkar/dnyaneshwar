/*
SQLyog Community v12.2.1 (64 bit)
MySQL - 5.5.43-37.2-log : Database - nvschool
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`nvschool` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `nvschool`;

/*Table structure for table `account` */

DROP TABLE IF EXISTS `account`;

CREATE TABLE `account` (
  `Stud_id` int(255) NOT NULL,
  `Datea` varchar(255) DEFAULT NULL,
  `Term1` int(255) DEFAULT NULL,
  `Term2` int(255) DEFAULT NULL,
  `Jan` int(255) DEFAULT NULL,
  `Feb` int(255) DEFAULT NULL,
  `March` int(255) DEFAULT NULL,
  `April` int(255) DEFAULT NULL,
  `May` int(255) DEFAULT NULL,
  `June` int(255) DEFAULT NULL,
  `July` int(255) DEFAULT NULL,
  `Aug` int(255) DEFAULT NULL,
  `Sept` int(255) DEFAULT NULL,
  `Octo` int(255) DEFAULT NULL,
  `Nov` int(255) DEFAULT NULL,
  `Deca` int(255) DEFAULT NULL,
  `Outstanding` int(255) DEFAULT NULL,
  `Total_Outstanding` int(255) DEFAULT NULL,
  `Receipt_id` int(255) NOT NULL AUTO_INCREMENT,
  `Class_id` int(255) DEFAULT NULL,
  `Teach_id` int(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Receipt_id`),
  KEY `Stud_id` (`Stud_id`),
  KEY `Class_id` (`Class_id`),
  KEY `Teach_id` (`Teach_id`),
  CONSTRAINT `account_ibfk_1` FOREIGN KEY (`Class_id`) REFERENCES `class` (`Class_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `account_ibfk_2` FOREIGN KEY (`Teach_id`) REFERENCES `teacher` (`Teach_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

/*Data for the table `account` */

insert  into `account`(`Stud_id`,`Datea`,`Term1`,`Term2`,`Jan`,`Feb`,`March`,`April`,`May`,`June`,`July`,`Aug`,`Sept`,`Octo`,`Nov`,`Deca`,`Outstanding`,`Total_Outstanding`,`Receipt_id`,`Class_id`,`Teach_id`,`Status`) values 
(1,'2018-02-06 02:55:42',1,2,1,2,0,4,5,6,7,8,9,11,1,1,1,11,1,1,1,'Active'),
(1,'2018-02-06 02:55:52',1,2,1,2,0,4,5,6,7,8,9,11,1,1,1,11,2,1,1,'Active'),
(1,'2018-02-06 03:02:41',1,2,1,2,3,4,5,6,7,8,9,10,11,12,120,1202,4,1,1,'Active'),
(1,'2018-02-06 03:04:39',1,2,1,2,3,4,5,6,7,8,9,10,11,12,120,1202,5,1,1,'Active'),
(1,'2018-02-06 03:12:16',12,12,100,100,100,100,100,100,100,100,100,100,100,100,1224,1224,7,1,1,'Active'),
(1,'2018-02-06',12,12,100,100,100,100,100,100,100,100,100,100,100,100,1224,1224,8,1,1,'Active'),
(1,'2018-02-06',12,12,100,100,100,100,100,100,100,100,100,100,100,100,1224,1224,9,1,1,'Active'),
(23,'2018-02-13 23:24:26',12,12,100,100,100,100,100,100,100,100,100,100,100,100,1224,1224,10,1,1,'Active'),
(23,'2018-02-14',12,12,100,100,100,100,100,100,100,100,100,100,100,100,1224,1224,11,1,1,'Active'),
(23,'2018-02-14',12,12,100,100,100,100,100,100,100,100,100,100,100,100,1224,1224,12,1,1,'Active');

/*Table structure for table `attend` */

DROP TABLE IF EXISTS `attend`;

CREATE TABLE `attend` (
  `Att_id` int(10) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `Stud_id` int(255) DEFAULT NULL,
  `Teach_id` int(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Att_id`),
  KEY `Stud_id` (`Stud_id`,`Teach_id`),
  CONSTRAINT `attend_ibfk_1` FOREIGN KEY (`Stud_id`) REFERENCES `student` (`Stud_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `attend` */

insert  into `attend`(`Att_id`,`date`,`Stud_id`,`Teach_id`,`Status`) values 
(1,'1-2-2018',1,2,'present');

/*Table structure for table `book` */

DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `Book_id` int(255) NOT NULL AUTO_INCREMENT,
  `Book Name` varchar(255) NOT NULL,
  `Book Author` varchar(255) NOT NULL,
  PRIMARY KEY (`Book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `book` */

/*Table structure for table `cancelled_receipt` */

DROP TABLE IF EXISTS `cancelled_receipt`;

CREATE TABLE `cancelled_receipt` (
  `Cancel_id` int(255) NOT NULL AUTO_INCREMENT,
  `Receipt_id` int(255) NOT NULL,
  PRIMARY KEY (`Cancel_id`),
  KEY `Receipt_id` (`Receipt_id`),
  CONSTRAINT `cancelled_receipt_ibfk_1` FOREIGN KEY (`Receipt_id`) REFERENCES `account` (`Receipt_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cancelled_receipt` */

/*Table structure for table `class` */

DROP TABLE IF EXISTS `class`;

CREATE TABLE `class` (
  `Class_id` int(255) NOT NULL AUTO_INCREMENT,
  `Class_Name` varchar(255) NOT NULL,
  PRIMARY KEY (`Class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `class` */

insert  into `class`(`Class_id`,`Class_Name`) values 
(1,'Nursery'),
(2,'LKG'),
(3,'UKG'),
(4,'I');

/*Table structure for table `details` */

DROP TABLE IF EXISTS `details`;

CREATE TABLE `details` (
  `Detail_id` int(255) NOT NULL AUTO_INCREMENT,
  `Adhar_No` bigint(12) NOT NULL,
  `DOB` varchar(255) NOT NULL,
  `DOB_Words` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `Caste` varchar(255) NOT NULL,
  `Subcaste` varchar(255) NOT NULL,
  `Religion` varchar(255) NOT NULL,
  `Handicap_status` varchar(255) NOT NULL,
  `Handicap_info` varchar(255) DEFAULT NULL,
  `Place_Birth` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

/*Data for the table `details` */

insert  into `details`(`Detail_id`,`Adhar_No`,`DOB`,`DOB_Words`,`Gender`,`Caste`,`Subcaste`,`Religion`,`Handicap_status`,`Handicap_info`,`Place_Birth`) values 
(1,681,'562','Afgcn','$gen','bjhcn','hgbjk','ghbjn','vgbhjn','gvhbj','ghbj'),
(23,0,'dob1','dobw1','gen1','cas1','subcaste1','eligion1','handicap_status1','handicap_info1','kjhbmn'),
(24,2135465,'2018-02-10','sdaff','','dfs','asdfrgty','asdff','sadfgh','asdfg','qawdsf'),
(25,0,'2016-01-01','u','','u','u','u','u','u','u'),
(26,1234556789,'2018-12-31','qwertyu','','wertyu','erty','wertyu','ertyu','ertyui','qwerty');

/*Table structure for table `fee` */

DROP TABLE IF EXISTS `fee`;

CREATE TABLE `fee` (
  `Fee_id` int(255) NOT NULL AUTO_INCREMENT,
  `Monthly_Fees` varchar(255) DEFAULT NULL,
  `Exam_Fees` varchar(255) DEFAULT NULL,
  `Total` varchar(255) DEFAULT NULL,
  `Class_id` int(255) DEFAULT NULL,
  `term1` varchar(255) DEFAULT NULL,
  `term2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Fee_id`),
  KEY `Class-id` (`Class_id`),
  CONSTRAINT `fee_ibfk_1` FOREIGN KEY (`Class_id`) REFERENCES `class` (`Class_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `fee` */

insert  into `fee`(`Fee_id`,`Monthly_Fees`,`Exam_Fees`,`Total`,`Class_id`,`term1`,`term2`) values 
(1,'100','50','150',1,'12','12');

/*Table structure for table `homework` */

DROP TABLE IF EXISTS `homework`;

CREATE TABLE `homework` (
  `Home_id` int(255) NOT NULL AUTO_INCREMENT,
  `Class_id` int(255) DEFAULT NULL,
  `Date_Created` varchar(255) DEFAULT NULL,
  `Content` varchar(511) DEFAULT NULL,
  `Teach_id` int(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  `Sub_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Home_id`),
  KEY `Class_id` (`Class_id`),
  KEY `Teach_id` (`Teach_id`),
  CONSTRAINT `homework_ibfk_2` FOREIGN KEY (`Teach_id`) REFERENCES `teacher` (`Teach_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `homework_ibfk_3` FOREIGN KEY (`Class_id`) REFERENCES `class` (`Class_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

/*Data for the table `homework` */

insert  into `homework`(`Home_id`,`Class_id`,`Date_Created`,`Content`,`Teach_id`,`Status`,`Sub_id`) values 
(2,1,'$datea','des',1,'Active','$sub'),
(3,1,'2018-02-04',' asdfghjk',1,'Active',''),
(5,1,'$datea','1',1,'Active','$sub'),
(10,1,'2018-02-10',' asdfghjk',1,'Active',''),
(11,1,'2018-02-07',' dfghjkl',2,'Active',''),
(12,2,'2018-02-09',' fdshsfdgfdsh',2,'Active','1\"\"'),
(13,1,'2018-12-31',' qwedrfghjkldfrgtyhujkwertyuwertyuiwertyuertyu',2,'Active','1\"\"'),
(14,1,'2018-12-31',' asdfghjklxcvbnm,zxcvbnm',2,'Active','1\"\"');

/*Table structure for table `library` */

DROP TABLE IF EXISTS `library`;

CREATE TABLE `library` (
  `Lib_id` int(255) NOT NULL AUTO_INCREMENT,
  `Book_id` int(255) DEFAULT NULL,
  `Stud_id` int(255) DEFAULT NULL,
  `Borrow_Date` varchar(255) DEFAULT NULL,
  `Return_Date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Lib_id`),
  KEY `Book_id` (`Book_id`,`Stud_id`),
  CONSTRAINT `library_ibfk_1` FOREIGN KEY (`Book_id`) REFERENCES `book` (`Book_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `library` */

/*Table structure for table `media` */

DROP TABLE IF EXISTS `media`;

CREATE TABLE `media` (
  `Media_id` int(255) NOT NULL AUTO_INCREMENT,
  `Sender_id` int(255) DEFAULT NULL,
  `Media` varchar(511) DEFAULT NULL,
  `Receiver_id` int(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  `Subject` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Media_id`),
  KEY `Sender_id` (`Sender_id`),
  KEY `Receiver_id` (`Receiver_id`),
  CONSTRAINT `media_ibfk_1` FOREIGN KEY (`Sender_id`) REFERENCES `teacher` (`Teach_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `media_ibfk_2` FOREIGN KEY (`Receiver_id`) REFERENCES `student` (`Stud_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `media` */

/*Table structure for table `notice` */

DROP TABLE IF EXISTS `notice`;

CREATE TABLE `notice` (
  `Notice_id` int(255) NOT NULL AUTO_INCREMENT,
  `Sender_id` int(255) NOT NULL,
  `Notice` varchar(511) DEFAULT NULL,
  `Receiver_id` int(255) NOT NULL,
  `Status` varchar(255) DEFAULT NULL,
  `Dates` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Notice_id`),
  KEY `Sender_id` (`Sender_id`),
  KEY `Receiver_id` (`Receiver_id`),
  CONSTRAINT `notice_ibfk_1` FOREIGN KEY (`Sender_id`) REFERENCES `teacher` (`Teach_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `notice_ibfk_2` FOREIGN KEY (`Receiver_id`) REFERENCES `student` (`Stud_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

/*Data for the table `notice` */

insert  into `notice`(`Notice_id`,`Sender_id`,`Notice`,`Receiver_id`,`Status`,`Dates`) values 
(1,1,'jjn',1,'ggsahghgs',NULL),
(21,1,'hjj',1,'active',NULL),
(22,1,'1',1,'Active',NULL),
(25,1,'des',1,'Active',NULL),
(26,1,' sdfgh',1,'Active',NULL),
(32,1,'fdbf',1,'Active',NULL),
(34,1,'fdbf',1,'Active',NULL),
(37,1,'fdbf',1,'Active',NULL),
(38,2,'fdbf',1,'Active',NULL),
(39,2,'fdbf',1,'Active',NULL);

/*Table structure for table `parent` */

DROP TABLE IF EXISTS `parent`;

CREATE TABLE `parent` (
  `Parent_id` int(255) NOT NULL AUTO_INCREMENT,
  `Father_Name` varchar(255) NOT NULL,
  `Mother_Name` varchar(255) NOT NULL,
  `Contact_no` bigint(10) NOT NULL,
  PRIMARY KEY (`Parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

/*Data for the table `parent` */

insert  into `parent`(`Parent_id`,`Father_Name`,`Mother_Name`,`Contact_no`) values 
(1,'cdgfn','cvxfbg',0),
(23,'dfgh','uygjh',8645),
(24,'asdf','asdf',0),
(25,'u','u',55446434),
(26,'qwert','werty',123456);

/*Table structure for table `receipt` */

DROP TABLE IF EXISTS `receipt`;

CREATE TABLE `receipt` (
  `Receipt_id` int(10) DEFAULT NULL,
  `Stud_id` int(10) DEFAULT NULL,
  `Month` varchar(255) DEFAULT NULL,
  `Paid` varchar(255) DEFAULT NULL,
  `Date` varchar(255) DEFAULT NULL,
  `Note` varchar(255) DEFAULT NULL,
  `Teach_id` int(10) DEFAULT NULL,
  `id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `Stud_id` (`Stud_id`),
  KEY `Teach_id` (`Teach_id`),
  CONSTRAINT `receipt_ibfk_1` FOREIGN KEY (`Stud_id`) REFERENCES `student` (`Stud_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `receipt_ibfk_2` FOREIGN KEY (`Teach_id`) REFERENCES `teacher` (`Teach_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `receipt` */

insert  into `receipt`(`Receipt_id`,`Stud_id`,`Month`,`Paid`,`Date`,`Note`,`Teach_id`,`id`) values 
(9,1,' -June','0','2018-02-06','120',1,2),
(11,23,' -June','0','2018-02-14','testing',1,3),
(12,23,' -June','0','2018-02-14','abvd',1,4);

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `Stud_id` int(255) NOT NULL AUTO_INCREMENT,
  `UDSIE_no` varchar(255) DEFAULT NULL,
  `Admission_no` varchar(255) DEFAULT NULL,
  `First_name` varchar(255) DEFAULT NULL,
  `Middle_name` varchar(255) DEFAULT NULL,
  `Last_name` varchar(255) DEFAULT NULL,
  `Mother_name` varchar(255) DEFAULT NULL,
  `Roll_no` varchar(255) DEFAULT NULL,
  `Password` bigint(10) DEFAULT NULL,
  `Class_id` int(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Stud_id`),
  KEY `Class_id` (`Class_id`),
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`Class_id`) REFERENCES `class` (`Class_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`Stud_id`,`UDSIE_no`,`Admission_no`,`First_name`,`Middle_name`,`Last_name`,`Mother_name`,`Roll_no`,`Password`,`Class_id`,`Address`,`Status`) values 
(1,'212132','32321345','priyanka','fsdasd','adssd','abcd','10',12345,1,'sadd','Active'),
(23,'541','hfg','as','dfgh','trdgf','uygjh','ujhbmn',94516,1,'tffhgvnk ygjhv','Active'),
(24,'212132','32321345','priyanka','Swapnil','Tak','saroja','fsdasd',94516,1,'sadd','Active'),
(25,'u','u','u','u','u','u','u',94516,1,'u','Active'),
(26,'1245','12345','qwer','qwert','qwer','werty','12456',94516,1,'wertyui','Active');

/*Table structure for table `subject` */

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `Subject_id` int(255) NOT NULL,
  `Class_id` int(255) DEFAULT NULL,
  `Subject_Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Subject_id`),
  KEY `Class_id` (`Class_id`),
  CONSTRAINT `subject_ibfk_1` FOREIGN KEY (`Class_id`) REFERENCES `class` (`Class_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `subject` */

insert  into `subject`(`Subject_id`,`Class_id`,`Subject_Name`) values 
(1,1,'Number1to50'),
(2,2,'Shishugeet'),
(3,3,'Marathi');

/*Table structure for table `teacher` */

DROP TABLE IF EXISTS `teacher`;

CREATE TABLE `teacher` (
  `Teach_id` int(255) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) DEFAULT NULL,
  `mname` varchar(255) DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `Mobile_No` bigint(10) DEFAULT NULL,
  `Designation` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Date_Of_Joining` varchar(255) DEFAULT NULL,
  `Class_id` int(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  `Date_of_birth` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Gender` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Teach_id`),
  KEY `Class_id` (`Class_id`),
  CONSTRAINT `teacher_ibfk_1` FOREIGN KEY (`Class_id`) REFERENCES `class` (`Class_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `teacher` */

insert  into `teacher`(`Teach_id`,`fname`,`mname`,`surname`,`Mobile_No`,`Designation`,`Password`,`Date_Of_Joining`,`Class_id`,`Status`,`Date_of_birth`,`Address`,`Gender`,`Email`) values 
(1,'Somesh','Kishanrao','Arewar',9011047390,'accountant','12345','5/11/2012',3,'Active','2018-03-08','Nanded','Male','somesh.arewar@gmail.com'),
(2,'radha','suresh','agrawal',9403476854,'teacher','12345','6/10/2013',1,'Active',NULL,NULL,NULL,NULL),
(3,'first','middle','last',555331,'Designation','622222','55333',1,'active','08/05/1992',NULL,NULL,NULL),
(4,'asfg','sdf','fgn',8541,'dfgh','8541','6845132',1,'Active','','485','Male','rohini.killedar@yahoo.com'),
(5,'sdfghjk','asdfghj','sdfgh',12356,'hjk','12356','123456',1,'Active','1245456','wertyui','Male','tyuiol@gmail.com');

/*Table structure for table `timetable` */

DROP TABLE IF EXISTS `timetable`;

CREATE TABLE `timetable` (
  `Time_id` int(255) NOT NULL AUTO_INCREMENT,
  `Class_id` int(255) DEFAULT NULL,
  `Teach_id` int(255) DEFAULT NULL,
  `Time` varchar(255) DEFAULT NULL,
  `Sub_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`Time_id`),
  KEY `Class_id` (`Class_id`),
  KEY `Teach-id` (`Teach_id`),
  KEY `Sub_id` (`Sub_id`),
  CONSTRAINT `timetable_ibfk_1` FOREIGN KEY (`Class_id`) REFERENCES `class` (`Class_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `timetable_ibfk_2` FOREIGN KEY (`Teach_id`) REFERENCES `teacher` (`Teach_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `timetable_ibfk_3` FOREIGN KEY (`Sub_id`) REFERENCES `subject` (`Subject_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `timetable` */

insert  into `timetable`(`Time_id`,`Class_id`,`Teach_id`,`Time`,`Sub_id`) values 
(1,1,1,'$tim',1),
(2,1,1,'tim',1),
(3,1,3,'09:45-10:25',1),
(4,3,1,'08:45-09:45',3),
(5,2,1,'02:25-03:05',2);

/*Table structure for table `classTeach` */

DROP TABLE IF EXISTS `classTeach`;

/*!50001 DROP VIEW IF EXISTS `classTeach` */;
/*!50001 DROP TABLE IF EXISTS `classTeach` */;

/*!50001 CREATE TABLE  `classTeach`(
 `Time` varchar(255) ,
 `Class_id` int(255) ,
 `Teach_id` int(255) ,
 `Class_name` varchar(255) 
)*/;

/*Table structure for table `coll` */

DROP TABLE IF EXISTS `coll`;

/*!50001 DROP VIEW IF EXISTS `coll` */;
/*!50001 DROP TABLE IF EXISTS `coll` */;

/*!50001 CREATE TABLE  `coll`(
 `Receipt_id` int(10) ,
 `Stud_id` int(10) ,
 `Paid` varchar(255) ,
 `Date` varchar(255) ,
 `First_name` varchar(255) ,
 `Middle_name` varchar(255) ,
 `Last_name` varchar(255) ,
 `Class_id` int(255) ,
 `Class_Name` varchar(255) 
)*/;

/*Table structure for table `full_stud` */

DROP TABLE IF EXISTS `full_stud`;

/*!50001 DROP VIEW IF EXISTS `full_stud` */;
/*!50001 DROP TABLE IF EXISTS `full_stud` */;

/*!50001 CREATE TABLE  `full_stud`(
 `Stud_id` int(255) ,
 `Class_id` int(255) ,
 `First_name` varchar(255) ,
 `Middle_name` varchar(255) ,
 `Last_name` varchar(255) ,
 `Class_Name` varchar(255) 
)*/;

/*Table structure for table `not_teach1` */

DROP TABLE IF EXISTS `not_teach1`;

/*!50001 DROP VIEW IF EXISTS `not_teach1` */;
/*!50001 DROP TABLE IF EXISTS `not_teach1` */;

/*!50001 CREATE TABLE  `not_teach1`(
 `fname` varchar(255) ,
 `mname` varchar(255) ,
 `surname` varchar(255) ,
 `Notice` varchar(511) ,
 `Notice_id` int(255) ,
 `Status` varchar(255) ,
 `Receiver_id` int(255) 
)*/;

/*Table structure for table `outstand` */

DROP TABLE IF EXISTS `outstand`;

/*!50001 DROP VIEW IF EXISTS `outstand` */;
/*!50001 DROP TABLE IF EXISTS `outstand` */;

/*!50001 CREATE TABLE  `outstand`(
 `Z` int(255) ,
 `Stud_id` int(255) ,
 `Total_Outstanding` int(255) ,
 `Outstanding` int(255) 
)*/;

/*Table structure for table `outstandingSo` */

DROP TABLE IF EXISTS `outstandingSo`;

/*!50001 DROP VIEW IF EXISTS `outstandingSo` */;
/*!50001 DROP TABLE IF EXISTS `outstandingSo` */;

/*!50001 CREATE TABLE  `outstandingSo`(
 `Stud_id` int(255) ,
 `Total_Outstanding` int(255) ,
 `Outstanding` int(255) ,
 `Z` int(255) ,
 `First_name` varchar(255) ,
 `Middle_name` varchar(255) ,
 `Last_name` varchar(255) ,
 `Class_id` int(255) 
)*/;

/*Table structure for table `stu_reg` */

DROP TABLE IF EXISTS `stu_reg`;

/*!50001 DROP VIEW IF EXISTS `stu_reg` */;
/*!50001 DROP TABLE IF EXISTS `stu_reg` */;

/*!50001 CREATE TABLE  `stu_reg`(
 `Stud_id` int(255) ,
 `Admission_no` varchar(255) ,
 `First_name` varchar(255) ,
 `Middle_name` varchar(255) ,
 `Last_name` varchar(255) ,
 `Roll_no` varchar(255) ,
 `Class_Name` varchar(255) 
)*/;

/*Table structure for table `stud_acc` */

DROP TABLE IF EXISTS `stud_acc`;

/*!50001 DROP VIEW IF EXISTS `stud_acc` */;
/*!50001 DROP TABLE IF EXISTS `stud_acc` */;

/*!50001 CREATE TABLE  `stud_acc`(
 `First_name` varchar(255) ,
 `Middle_name` varchar(255) ,
 `Last_name` varchar(255) ,
 `Class_name` varchar(255) ,
 `Class_id` int(255) ,
 `Datea` varchar(255) ,
 `Receipt_id` int(255) ,
 `Status` varchar(255) 
)*/;

/*Table structure for table `studbona` */

DROP TABLE IF EXISTS `studbona`;

/*!50001 DROP VIEW IF EXISTS `studbona` */;
/*!50001 DROP TABLE IF EXISTS `studbona` */;

/*!50001 CREATE TABLE  `studbona`(
 `Stud_id` int(255) ,
 `First_name` varchar(255) ,
 `Middle_name` varchar(255) ,
 `Last_name` varchar(255) ,
 `DOB` varchar(255) ,
 `DOB_Words` varchar(255) ,
 `Class_Name` varchar(255) 
)*/;

/*Table structure for table `student_parent_detail` */

DROP TABLE IF EXISTS `student_parent_detail`;

/*!50001 DROP VIEW IF EXISTS `student_parent_detail` */;
/*!50001 DROP TABLE IF EXISTS `student_parent_detail` */;

/*!50001 CREATE TABLE  `student_parent_detail`(
 `Stud_id` int(255) ,
 `UDSIE_no` varchar(255) ,
 `Admission_no` varchar(255) ,
 `First_name` varchar(255) ,
 `Middle_name` varchar(255) ,
 `Last_name` varchar(255) ,
 `Mother_name` varchar(255) ,
 `Roll_no` varchar(255) ,
 `PASSWORD` bigint(10) ,
 `Class_id` int(255) ,
 `Address` varchar(255) ,
 `STATUS` varchar(255) ,
 `Father_Name` varchar(255) ,
 `Contact_no` bigint(10) ,
 `Adhar_No` bigint(12) ,
 `DOB` varchar(255) ,
 `DOB_Words` varchar(255) ,
 `Gender` varchar(255) ,
 `Caste` varchar(255) ,
 `Subcaste` varchar(255) ,
 `Religion` varchar(255) ,
 `Handicap_Status` varchar(255) ,
 `Handicap_info` varchar(255) ,
 `Place_Birth` varchar(255) 
)*/;

/*Table structure for table `sub` */

DROP TABLE IF EXISTS `sub`;

/*!50001 DROP VIEW IF EXISTS `sub` */;
/*!50001 DROP TABLE IF EXISTS `sub` */;

/*!50001 CREATE TABLE  `sub`(
 `fname` varchar(255) ,
 `surname` varchar(255) ,
 `Teach_id` int(255) ,
 `Class_id` int(255) ,
 `Time` varchar(255) ,
 `Class_Name` varchar(255) ,
 `Sub_id` int(10) ,
 `Subject_Name` varchar(255) 
)*/;

/*Table structure for table `sub2` */

DROP TABLE IF EXISTS `sub2`;

/*!50001 DROP VIEW IF EXISTS `sub2` */;
/*!50001 DROP TABLE IF EXISTS `sub2` */;

/*!50001 CREATE TABLE  `sub2`(
 `fname` varchar(255) ,
 `surname` varchar(255) ,
 `Teach_id` int(255) ,
 `Class_id` int(255) ,
 `Time` varchar(255) ,
 `Class_Name` varchar(255) ,
 `Sub_id` int(10) ,
 `Subject_Name` varchar(255) 
)*/;

/*Table structure for table `sub_home1` */

DROP TABLE IF EXISTS `sub_home1`;

/*!50001 DROP VIEW IF EXISTS `sub_home1` */;
/*!50001 DROP TABLE IF EXISTS `sub_home1` */;

/*!50001 CREATE TABLE  `sub_home1`(
 `Home_id` int(255) ,
 `Content` varchar(511) ,
 `Class_id` int(255) ,
 `Date_Created` varchar(255) ,
 `Subject_Name` varchar(255) ,
 `Status` varchar(255) 
)*/;

/*Table structure for table `teach_id_class` */

DROP TABLE IF EXISTS `teach_id_class`;

/*!50001 DROP VIEW IF EXISTS `teach_id_class` */;
/*!50001 DROP TABLE IF EXISTS `teach_id_class` */;

/*!50001 CREATE TABLE  `teach_id_class`(
 `Teach_id` int(255) ,
 `fname` varchar(255) ,
 `mname` varchar(255) ,
 `surname` varchar(255) ,
 `Mobile_No` bigint(10) ,
 `Class_id` int(255) ,
 `Class_Name` varchar(255) 
)*/;

/*View structure for view classTeach */

/*!50001 DROP TABLE IF EXISTS `classTeach` */;
/*!50001 DROP VIEW IF EXISTS `classTeach` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `classTeach` AS (select `T`.`Time` AS `Time`,`T`.`Class_id` AS `Class_id`,`T`.`Teach_id` AS `Teach_id`,`C`.`Class_Name` AS `Class_name` from (`timetable` `T` join `class` `C` on((`T`.`Class_id` = `C`.`Class_id`)))) */;

/*View structure for view coll */

/*!50001 DROP TABLE IF EXISTS `coll` */;
/*!50001 DROP VIEW IF EXISTS `coll` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `coll` AS (select `R`.`Receipt_id` AS `Receipt_id`,`R`.`Stud_id` AS `Stud_id`,`R`.`Paid` AS `Paid`,`R`.`Date` AS `Date`,`S`.`First_name` AS `First_name`,`S`.`Middle_name` AS `Middle_name`,`S`.`Last_name` AS `Last_name`,`S`.`Class_id` AS `Class_id`,`C`.`Class_Name` AS `Class_Name` from ((`receipt` `R` join `student` `S` on((`R`.`Stud_id` = `S`.`Stud_id`))) join `class` `C` on((`S`.`Class_id` = `C`.`Class_id`)))) */;

/*View structure for view full_stud */

/*!50001 DROP TABLE IF EXISTS `full_stud` */;
/*!50001 DROP VIEW IF EXISTS `full_stud` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `full_stud` AS (select `S`.`Stud_id` AS `Stud_id`,`S`.`Class_id` AS `Class_id`,`S`.`First_name` AS `First_name`,`S`.`Middle_name` AS `Middle_name`,`S`.`Last_name` AS `Last_name`,`C`.`Class_Name` AS `Class_Name` from (`student` `S` join `class` `C` on((`S`.`Class_id` = `C`.`Class_id`)))) */;

/*View structure for view not_teach1 */

/*!50001 DROP TABLE IF EXISTS `not_teach1` */;
/*!50001 DROP VIEW IF EXISTS `not_teach1` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `not_teach1` AS (select `T`.`fname` AS `fname`,`T`.`mname` AS `mname`,`T`.`surname` AS `surname`,`N`.`Notice` AS `Notice`,`N`.`Notice_id` AS `Notice_id`,`N`.`Status` AS `Status`,`N`.`Receiver_id` AS `Receiver_id` from (`teacher` `T` join `notice` `N` on((`T`.`Teach_id` = `N`.`Sender_id`)))) */;

/*View structure for view outstand */

/*!50001 DROP TABLE IF EXISTS `outstand` */;
/*!50001 DROP VIEW IF EXISTS `outstand` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `outstand` AS (select max(`account`.`Receipt_id`) AS `Z`,`account`.`Stud_id` AS `Stud_id`,`account`.`Total_Outstanding` AS `Total_Outstanding`,min(`account`.`Outstanding`) AS `Outstanding` from `account` where (`account`.`Status` = 'active') group by `account`.`Stud_id` order by `account`.`Stud_id`) */;

/*View structure for view outstandingSo */

/*!50001 DROP TABLE IF EXISTS `outstandingSo` */;
/*!50001 DROP VIEW IF EXISTS `outstandingSo` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `outstandingSo` AS (select `O`.`Stud_id` AS `Stud_id`,`O`.`Total_Outstanding` AS `Total_Outstanding`,`O`.`Outstanding` AS `Outstanding`,`O`.`Z` AS `Z`,`S`.`First_name` AS `First_name`,`S`.`Middle_name` AS `Middle_name`,`S`.`Last_name` AS `Last_name`,`S`.`Class_id` AS `Class_id` from (`outstand` `O` join `student` `S` on((`O`.`Stud_id` = `S`.`Stud_id`)))) */;

/*View structure for view stu_reg */

/*!50001 DROP TABLE IF EXISTS `stu_reg` */;
/*!50001 DROP VIEW IF EXISTS `stu_reg` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `stu_reg` AS (select `S`.`Stud_id` AS `Stud_id`,`S`.`Admission_no` AS `Admission_no`,`S`.`First_name` AS `First_name`,`S`.`Middle_name` AS `Middle_name`,`S`.`Last_name` AS `Last_name`,`S`.`Roll_no` AS `Roll_no`,`C`.`Class_Name` AS `Class_Name` from (`student` `S` join `class` `C` on((`S`.`Class_id` = `C`.`Class_id`)))) */;

/*View structure for view stud_acc */

/*!50001 DROP TABLE IF EXISTS `stud_acc` */;
/*!50001 DROP VIEW IF EXISTS `stud_acc` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `stud_acc` AS (select `S`.`First_name` AS `First_name`,`S`.`Middle_name` AS `Middle_name`,`S`.`Last_name` AS `Last_name`,`C`.`Class_Name` AS `Class_name`,`C`.`Class_id` AS `Class_id`,`A`.`Datea` AS `Datea`,`A`.`Receipt_id` AS `Receipt_id`,`A`.`Status` AS `Status` from ((`student` `S` join `class` `C` on((`S`.`Class_id` = `C`.`Class_id`))) join `account` `A` on((`S`.`Stud_id` = `A`.`Stud_id`)))) */;

/*View structure for view studbona */

/*!50001 DROP TABLE IF EXISTS `studbona` */;
/*!50001 DROP VIEW IF EXISTS `studbona` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `studbona` AS (select `student`.`Stud_id` AS `Stud_id`,`student`.`First_name` AS `First_name`,`student`.`Middle_name` AS `Middle_name`,`student`.`Last_name` AS `Last_name`,`details`.`DOB` AS `DOB`,`details`.`DOB_Words` AS `DOB_Words`,`class`.`Class_Name` AS `Class_Name` from ((`student` join `details` on((`student`.`Stud_id` = `details`.`Detail_id`))) join `class` on((`student`.`Class_id` = `class`.`Class_id`)))) */;

/*View structure for view student_parent_detail */

/*!50001 DROP TABLE IF EXISTS `student_parent_detail` */;
/*!50001 DROP VIEW IF EXISTS `student_parent_detail` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `student_parent_detail` AS (select `s`.`Stud_id` AS `Stud_id`,`s`.`UDSIE_no` AS `UDSIE_no`,`s`.`Admission_no` AS `Admission_no`,`s`.`First_name` AS `First_name`,`s`.`Middle_name` AS `Middle_name`,`s`.`Last_name` AS `Last_name`,`s`.`Mother_name` AS `Mother_name`,`s`.`Roll_no` AS `Roll_no`,`s`.`Password` AS `PASSWORD`,`s`.`Class_id` AS `Class_id`,`s`.`Address` AS `Address`,`s`.`Status` AS `STATUS`,`p`.`Father_Name` AS `Father_Name`,`p`.`Contact_no` AS `Contact_no`,`d`.`Adhar_No` AS `Adhar_No`,`d`.`DOB` AS `DOB`,`d`.`DOB_Words` AS `DOB_Words`,`d`.`Gender` AS `Gender`,`d`.`Caste` AS `Caste`,`d`.`Subcaste` AS `Subcaste`,`d`.`Religion` AS `Religion`,`d`.`Handicap_status` AS `Handicap_Status`,`d`.`Handicap_info` AS `Handicap_info`,`d`.`Place_Birth` AS `Place_Birth` from ((`student` `s` join `parent` `p` on((`s`.`Stud_id` = `p`.`Parent_id`))) join `details` `d` on((`s`.`Stud_id` = `d`.`Detail_id`)))) */;

/*View structure for view sub */

/*!50001 DROP TABLE IF EXISTS `sub` */;
/*!50001 DROP VIEW IF EXISTS `sub` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `sub` AS (select `T`.`fname` AS `fname`,`T`.`surname` AS `surname`,`T`.`Teach_id` AS `Teach_id`,`B`.`Class_id` AS `Class_id`,`B`.`Time` AS `Time`,`C`.`Class_Name` AS `Class_Name`,`B`.`Sub_id` AS `Sub_id`,`S`.`Subject_Name` AS `Subject_Name` from (((`timetable` `B` join `teacher` `T` on((`B`.`Teach_id` = `T`.`Teach_id`))) join `class` `C` on((`B`.`Class_id` = `C`.`Class_id`))) join `subject` `S` on((`B`.`Sub_id` = `S`.`Subject_id`)))) */;

/*View structure for view sub2 */

/*!50001 DROP TABLE IF EXISTS `sub2` */;
/*!50001 DROP VIEW IF EXISTS `sub2` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `sub2` AS (select `T`.`fname` AS `fname`,`T`.`surname` AS `surname`,`T`.`Teach_id` AS `Teach_id`,`B`.`Class_id` AS `Class_id`,`B`.`Time` AS `Time`,`C`.`Class_Name` AS `Class_Name`,`B`.`Sub_id` AS `Sub_id`,`S`.`Subject_Name` AS `Subject_Name` from (((`timetable` `B` join `teacher` `T` on((`B`.`Teach_id` = `T`.`Teach_id`))) join `class` `C` on((`B`.`Class_id` = `C`.`Class_id`))) join `subject` `S` on((`B`.`Sub_id` = `S`.`Subject_id`)))) */;

/*View structure for view sub_home1 */

/*!50001 DROP TABLE IF EXISTS `sub_home1` */;
/*!50001 DROP VIEW IF EXISTS `sub_home1` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `sub_home1` AS (select `H`.`Home_id` AS `Home_id`,`H`.`Content` AS `Content`,`H`.`Class_id` AS `Class_id`,`H`.`Date_Created` AS `Date_Created`,`S`.`Subject_Name` AS `Subject_Name`,`H`.`Status` AS `Status` from (`homework` `H` join `subject` `S` on((`S`.`Subject_id` = `H`.`Sub_id`)))) */;

/*View structure for view teach_id_class */

/*!50001 DROP TABLE IF EXISTS `teach_id_class` */;
/*!50001 DROP VIEW IF EXISTS `teach_id_class` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`nvschool`@`%` SQL SECURITY DEFINER VIEW `teach_id_class` AS (select `T`.`Teach_id` AS `Teach_id`,`T`.`fname` AS `fname`,`T`.`mname` AS `mname`,`T`.`surname` AS `surname`,`T`.`Mobile_No` AS `Mobile_No`,`T`.`Class_id` AS `Class_id`,`C`.`Class_Name` AS `Class_Name` from (`teacher` `T` join `class` `C` on((`T`.`Class_id` = `C`.`Class_id`)))) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
