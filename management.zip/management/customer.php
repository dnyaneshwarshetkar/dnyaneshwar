<?php
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
	<div class="content-wrapper">
		<div class="container-fluid">
		  <!-- Breadcrumbs-->
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
				<li class="breadcrumb-item active">Home</li>
			</ol>
			<div class="row">
			<div class="col-sm-12">
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#customerModal">Add Customer</button>
			</div>
			<div class="col-sm-12 mt-2">
			<div class="table-responsive">
              <table class="table table-bordered display"style="width:100%" id="customerTable" width="100%" cellspacing="0" id="customerTable">
                <thead>
                  <tr>
					<th>User Id</th>
                    <th>Customer Id</th>
                    <th>First Name</th>
                    <th>Middle Name</th>
					<th>Last Name</th>
					<th>Organization Name</th>
					<th>Address</th>
					<th>Taluka</th>
					<th>District</th>
					<th>Mobile</th>
					<th>Email</th>
					<th>Manage</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
				<tfoot>
					<tr>
					<th>User Id</th>
                    <th>Customer Id</th>
                    <th>First Name</th>
                    <th>Middle Name</th>
					<th>Last Name</th>
					<th>Organization Name</th>
					<th>Address</th>
					<th>Taluka</th>
					<th>District</th>
					<th>Mobile</th>
					<th>Email</th>
					<th>Manage</th>
                  </tr>
                </tfoot>
              </table>
            </div>
			</div>
			</div>
		</div>
    </div>
<!--modal Starts-->
<div class="modal" tabindex="-1" role="dialog" id="customerModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
	<?php if(isset($_GET['customer_id'])){?>
		<form  name="customersForm" id="customersForm" onsubmit="return submitData(event,<?php echo $_GET['customer_id']?>)">
		<?php } else{?>
		<form  name="customersForm" id="customersForm" onsubmit="return submitData(event)">
		<?php } ?>
      <div class="modal-header">
		<?php if(isset($_GET['customer_id'])){?>
		<h5 class="modal-title text-center">Update Customer</h5>
		<?php } else{?>
		<h5 class="modal-title text-center">Add Customer</h5>
		<?php } ?>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		  <div class="form-row">
			<div class="form-group col-sm-4">
			  <label for="first_name">First Name</label>
			  <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter First Name" required>
			</div>
			<div class="form-group col-sm-4">
			  <label for="middle_name">Middle Name</label>
			  <input type="text" class="form-control" id="middle_name"  name="middle_name" placeholder="Enter Middle Name" required>
			</div>
			<div class="form-group col-sm-4">
			  <label for="last_name">Last Name</label>
			  <input type="text" class="form-control" id="last_name"  name="last_name" placeholder="Enter Last Name" required>
			</div>
		  </div>
		  <div class="form-row">
			<div class="form-group col-sm-4">
			  <label for="organization_name">Organization Name</label>
			  <input type="text" class="form-control" id="organization_name"  name="organization_name" placeholder="Enter Organization Name"required>
			</div>
		  <div class="form-group col-sm-4">
			  <label for="address">Address</label>
			  <input type="text" class="form-control" id="address" name="address" placeholder="Enter Address" required>
			</div>
			<div class="form-group col-sm-4">
			  <label for="taluka">Taluka</label>
			  <input type="text" class="form-control" id="taluka" name="taluka" placeholder="Enter Taluka" required>
			</div>
		</div>
		  <div class="form-row">
		  <div class="form-group col-sm-4">
			  <label for="district">District</label>
			  <input type="text" class="form-control" id="district" name="district" placeholder="Enter District" required>
			</div>
			<div class="form-group col-sm-4">
			  <label for="email">Email</label>
			  <input type="text" class="form-control" id="email"  name="email" placeholder="Enter Email"required>
			</div>
			<div class="form-group col-sm-4">
			  <label for="mobile">Mobile</label>
			  <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Enter Mobile" required>
			</div>
		  </div>
		</div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
	  </form>
    </div>
  </div>
</div><!--modal Ends-->
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/customer.js"></script>
</body>

</html>
