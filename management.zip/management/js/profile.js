var submitAddress = function(){
	 var x = $('#addressForm').serializeArray();
	 var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: "server/put_data.php?address=true&submit=true",
		  data: formData,
		  success: function(data,status){
			  alert(data+" "+status);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
}
var updateAddress = function(){
	 var x = $('#addressForm').serializeArray();
	 var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: "server/put_data.php?address=true&update=true",
		  data: formData,
		  success: function(data,status){
			  alert(data+" "+status);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
}
var submitEducation = function(){
	 var x = $('#educationForm').serializeArray();
	 var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: "server/put_data.php?education=true&submit=true",
		  data: formData,
		  success: function(data,status){
			  alert(data+" "+status);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
}
var updateEducation = function(){
	 var x = $('#educationForm').serializeArray();
	 var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: "server/put_data.php?education=true&update=true",
		  data: formData,
		  success: function(data,status){
			  alert(data+" "+status);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
}
var updateData = function(){
	 var x = $('#generalForm').serializeArray();
	 var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: "server/put_data.php?profile=true",
		  data: formData,
		  success: function(data,status){
			  alert(data+" "+status);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(function(){
	//for getting current users details.
	$.get("server/get_data.php?profile=true", function(data, status){
		data.length = 9;
        $.each(JSON.parse(data), function(key, value){
			if(key=="status"||key=="length"){
			}else{
				$('form [name=' + key + ']').val(value);
			}
		});
    });
});