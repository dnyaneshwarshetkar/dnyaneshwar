<?php
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
	<div class="content-wrapper">
		<div class="container-fluid">
		  <!-- Breadcrumbs-->
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
				<li class="breadcrumb-item active">Home</li>
			</ol>
			<div class="row">
			<div class="col-sm-12">
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#productModal">Add Product</button>
			</div>
			<div class="col-sm-12 mt-2">
			<div class="table-responsive">
              <table class="table table-bordered display"style="width:100%" width="100%" cellspacing="0" id="productTable">
                <thead>
                  <tr>
					<th>User Id</th>
                    <th>Product Id</th>
                    <th>Product Name</th>
                    <th>Price</th>
					<th>Discount</th>
					<th>Gst</th>
					<th>Manage</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
				<tfoot>
					<tr>
					<th>User Id</th>
                    <th>Product Id</th>
                    <th>Product Name</th>
                    <th>Price</th>
					<th>Discount</th>
					<th>Gst</th>
					<th>Manage</th>
                  </tr>
                </tfoot>
              </table>
            </div>
			</div>
			</div>
		</div>
    </div>
<!--modal Starts-->
<div class="modal" tabindex="-1" role="dialog" id="productModal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
	<?php if(isset($_GET['product_id'])){?>
		<form  name="customersForm" id="customersForm" onsubmit="return submitData(event,<?php echo $_GET['customer_id']?>)">
		<?php } else{?>
		<form  name="customersForm" id="customersForm" onsubmit="return submitData(event)">
		<?php } ?>
      <div class="modal-header">
		<?php if(isset($_GET['product_id'])){?>
		<h5 class="modal-title text-center">Update Product</h5>
		<?php } else{?>
		<h5 class="modal-title text-center">Add Product</h5>
		<?php } ?>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		  <div class="form-row">
			<div class="form-group col-sm-4">
			  <label for="product_name">Product Name</label>
			  <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Enter Product Name" required>
			</div>
			<div class="form-group col-sm-4">
			  <label for="image">Image</label>
			  <input type="file" class="form-control" id="image"  name="image" placeholder="Select Image" required>
			</div>
			<div class="form-group col-sm-4">
			  <label for="video">Video</label>
			  <input type="file" class="form-control" id="video"  name="video" placeholder="Select Video" required>
			</div>
		  </div>
		  <div class="form-row">
			<div class="form-group col-sm-4">
			  <label for="ppt">PPT</label>
			  <input type="file" class="form-control" id="ppt"  name="ppt" placeholder="Select PPT"required>
			</div>
		  <div class="form-group col-sm-4">
			  <label for="price">Price</label>
			  <input type="text" class="form-control" id="price" name="price" placeholder="Enter Price" required>
			</div>
			<div class="form-group col-sm-4">
			  <label for="features">Features</label>
			  <textarea type="text" class="form-control" id="features" name="features" placeholder="Enter Features" required></textarea>
			</div>
		</div>
		  <div class="form-row">
		  <div class="form-group col-sm-4">
			  <label for="version">Version</label>
			  <input type="text" class="form-control" id="version" name="version" placeholder="Enter Version" required>
			</div>
			<div class="form-group col-sm-4">
			  <label for="launching_date">Launching Date</label>
			  <input type="date" class="form-control" id="launching_date"  name="launching_date" placeholder="Enter Launching Date"required>
			</div>
			<div class="form-group col-sm-4">
			  <label for="expiry_date">Expiry Date</label>
			  <input type="text" class="form-control" id="expiry_date" name="expiry_date" placeholder="Enter Expiry Date" required>
			</div>
		  </div>
		  <div class="form-row">
		  <div class="form-group col-sm-4">
			  <label for="discount">Discount</label>
			  <input type="text" class="form-control" id="discount" name="discount" placeholder="Enter Discount" required>
			</div>
			<div class="form-group col-sm-4">
			  <label for="gst">GST</label>
			  <input type="text" class="form-control" id="gst"  name="gst" placeholder="Enter GST"required>
			</div>
		  </div>
		</div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
	  </form>
    </div>
  </div>
</div><!--modal Ends-->
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/product.js"></script>
</body>

</html>
