<?php
	ini_set('display_errors', 1); 
	error_reporting(E_ALL);
    session_start();
    require "connect.php";
 
   if(isset($_POST['email']) && isset($_POST['password']) )
   { 
		$email = $_POST['email'];
		$password = $_POST['password'];
		$_SESSION['email'] = $email;
		$_SESSION['password'] = $password;
		$sql="SELECT * FROM users WHERE email='$email' AND password='$password'";
		$result = $con->query($sql);
		if($result->num_rows==1)
		{
			$row = mysqli_fetch_assoc($result);
			$_SESSION['user'] = $row;
			header("location: dashboard.php");
		}
	   else
	   {
		   echo "<script>alert('Your Email or Password is Incorrect');			window.location.assign('index.html');</script>";
	   }
   }
   else
   {
	   echo "<script>alert('Enter Username or Password');				window.location.assign('index.html');</script>";
   }
?>
