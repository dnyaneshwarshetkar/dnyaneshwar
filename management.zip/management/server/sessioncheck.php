<?php
	session_start();
	if(!isset($_SESSION['user'])){
		echo "<script>alert('Session Expired');			window.location.assign('index.html');</script>";
	}
?>