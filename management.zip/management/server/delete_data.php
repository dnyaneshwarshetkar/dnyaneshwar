<?php
include('../connect.php');
if(isset($_GET["customer_id"])){
	$customer_id = $_GET["customer_id"];
	$sql = "delete from customer where customer_id=$customer_id";
	$result = mysqli_query($con,$sql);
	if($result){
		$response = array();
		$response["message"] ="Customer Deleted Successfully";
		$response["status"] ="success";
		echo json_encode($response);
	}else{
		echo json_encode(array("Customer Not Deleted Successfully ".mysqli_error()));
	}
}
 ?>