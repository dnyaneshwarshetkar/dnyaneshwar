<?php
	include('header.php');
?>
<body onload="myFunction()">


<?php 
	include('sidebar.php');
?>
<?php 
	include('connect.php');
	if(isset($_GET['Receipt_id']))
		{
		$rec=$_GET['Receipt_id'];
		$sql1 = "SELECT * FROM receipt WHERE Receipt_id='$rec'";
		$result = $con->query($sql1);	
		if ($result->num_rows==1) 
			{
			while($row = $result->fetch_assoc()) 
				{
				$Sid=$row['Stud_id'];
				$Month=$row['Month'];
				$Paid=$row['Paid'];
				$Date=$row['Date'];
				$tid=$row['Teach_id'];
				$note=$row['Note'];
				}  
			}
			
		$sql2 = "SELECT
  `S`.`Stud_id`      AS `Stud_id`,
  `S`.`Admission_no` AS `Admission_no`,
  `S`.`First_name`   AS `First_name`,
  `S`.`Middle_name`  AS `Middle_name`,
  `S`.`Last_name`    AS `Last_name`,
  `S`.`Roll_no`      AS `Roll_no`,
  `C`.`Class_Name`   AS `Class_Name`
FROM (`student` `S`
   JOIN `class` `C`
     ON ((`S`.`Class_id` = `C`.`Class_id`))) WHERE S.Stud_id='$Sid'";
		$result = $con->query($sql2);	
		if ($result->num_rows==1) 
			{
			while($row = $result->fetch_assoc()) 
				{
				$name = $row['First_name']." ".$row['Middle_name']." ".$row['Last_name'];
				$add = $row['Admission_no'];
				$roll = $row['Roll_no'];
				$cla = $row['Class_Name'];
				}  
			}

		$sql3 = "SELECT * FROM teacher WHERE Teach_id='$tid'";
		$result = $con->query($sql3);	
		if ($result->num_rows==1) 
			{
			while($row = $result->fetch_assoc()) 
				{
				$tname = $row['fname']." ".$row['surname'];
				}  
			}
		}
?>
<!-- main content -->
<section class="content home">
    <div class="container-fluid">
      <!--  <div class="block-header">
            	
	<!--input   type="submit" value="print"-->
	
	 <div id="dvContents" style="border:8px;border-color:black;visibility:hidden;">
   
<div class="col-md-10 content-wrapper">
						<!-- main -->
						<div class="content">
							
							
 <!-- <div class="container" ><!-->
 <div class="container-fluid">

	<div class="col-md-4">
	
	<img src="assets/images/logo.png" height="100" width="100" style="margin-left:5px;">
</div>
<div class="col-md-5">
<h1 style="text-align:center;margin-left:100px;    margin-top: -100px;"><b>OXFORD THE GLOBAL SCHOOL<b></h1>
<p style="text-align:center;">At.Post, Puyani,Nila Road, Nanded, Contact no : 9422189321</p>

</div>
</br>
<div class="col-md-12">
	<hr>
</div>
		 
	
		 
       <div class="container">
        <h2 align="center"></h2>
        <div class="row">
        <div class="col-md-6">
        <p >Reg No.: <?php echo $add;?><label  name="reg_no" /></label></p>
        </div>
        <div class="col-md-6">
        <p style="margin-left:400px;margin-top:-35px;">Receipt No.: <?php echo $rec;?> <label name="reg_no" /></label></p>
        </div>
        </div>
        <div class="row">
        <div class="col-md-6">
        <p>Receipt Date: <?php echo $Date;?>  <label name="reg_no" /></label></p>
        </div>
        <div class="col-md-6">
        <p style="margin-left:400px;margin-top:-35px;">Roll No.: <?php echo $roll;?> <label name="reg_no" /></label></p>
        </div>
        </div>
        <div class="row">
        <div class="col-md-6">
        <p>Board : <label name="reg_no" />Maharashtra</label></p>
        </div>
        <div class="col-md-6">
        <p style="margin-left:400px;margin-top:-35px;">Class : <?php echo $cla;?><label name="reg_no" /></p>
        </div>
        </div>
        <div class="row">
        <div class="col-md-6">
        <h4>Name : <?php echo $name;?><label name="student_name"/></label></h4>
        </div>
        </div>
        <div class="row">
        <div class="col-md-12">
        <table border="1"  style="margin-left:100px;" cellpadding="10">
        <thead>
        <tr>
        <th>Sr. No.</th>
        <th>Month</th>
        <th>Amount</th>
        </tr>
        </thead>
		<tbody>
			<tr>
				<td><?php echo $tid; ?></td>
				<td><?php echo $Month; ?> </td>
				<td><?php echo $Paid; ?> </td>
			</tr>
		<tbody>
		 </div>
      </tr>
        </table>
        </div>
        </div>
        <div class="row">
        <div class="col-md-4">
        <h4>Payment Mode: Cash<label name="pay"></label></h4>
        </div>
		
		 </div>
        <div class="col-md-4">
         <p >Note: <?php echo $note;?></p>
		<div class="col-md-4">
        
		
		<div class="col-md-4">
       
        </div>
        <div class="col-md-4">
        <h4 style="margin-left:400px;margin-top:-35px;">Total Received (Rs.): <?php echo $Paid ;?><label name="tot_rec"></label></h4>
        </div>
        
        
        <div class="col-md-4">
        <h4>Received By: <?php echo $tname;?> </h4>
        </div>
		<div class="col-md-4">
        
       
       
		</div>
        </div>
        </div>
        </div>
        </div>
        
     </div>	
</section>
<!-- main content -->

<div class="color-bg"></div>


</body>


 <script>
function myFunction() {
    var contents = document.getElementById("dvContents").innerHTML;
            var frame1 = document.createElement('iframe');
            frame1.name = "frame1";
            frame1.style.position = "absolute";
            frame1.style.top = "-1000000px";
            document.body.appendChild(frame1);
            var frameDoc = frame1.contentWindow ? frame1.contentWindow : frame1.contentDocument.document ? frame1.contentDocument.document : frame1.contentDocument;
            frameDoc.document.open();
            frameDoc.document.write('<html><head><title></title>');
            frameDoc.document.write('</head><body>');
            frameDoc.document.write(contents);
            frameDoc.document.write('</body></html>');
            frameDoc.document.close();
            setTimeout(function () {
                window.frames["frame1"].focus();
                window.frames["frame1"].print();
                document.body.removeChild(frame1);
            }, 10);
            return false;
}
</script>



</html>