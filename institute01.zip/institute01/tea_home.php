<?php
 include('header.php');
 include('connect.php');
 include('session_teacher.php');
  
  
if(isset($_POST['save']))
  {
	$datea=$_POST['datea'];
    $cla=$_POST['cla'];
	$sub=$_POST['sub'];
    $des=$_POST['hom'];
    $sql = "INSERT INTO homework(Home_id,Class_id,Date_Created,Content,Teach_id,Status,Sub_id) 
			VALUES(NULL,'$cid','$datea','$des','$tid','Active','$sub')";
      if($con->query($sql)){
        echo "<script>alert('Added Succesfully');
         </script>";
		// header("Refresh:0");
      }
      else{
                die('Could not add data'.mysql_error());

      } 
  }

?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('teachersidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Blank Page</li>
      </ol>
      <div class="row">
        
      </div>
      
   

 

<form method="POST" action="">
 <div class="form-row">
	<div class="col-md-4">
		<label for="exampleInputLastName">select date</label>
		<input class="form-control" id="exampleInputName" name="datea" type="date" aria-describedby="nameHelp" placeholder="select date"> 
    </div>
    <div class="col-md-4">
        <label for="exampleInputLastName">class</label>
            <select  name="class" class="form-control">
                <option value="">----Select class----</option>
                <option value="">1</option>
                <option value="">2</option>
            </select>
    </div>
    <div class="col-md-4">
        <label for="exampleInputLastName">Select subject</label>
            <select  name="sub" class="form-control">
				<option value="">----Select subject----</option>
                <option value=1"">math</option>
                <option value="2">marathi</option>
            </select>
    </div>
 </div>

<br>
<br>

 <div class="row">
	<div class="col-md-2">
        <label for="exampleInputName">Homework</label>
    </div>
    <div class="col-md-10">
        <textarea class="form-control" name="hom" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name"> </textarea>
    </div>
</div>
<br>
  
 <div class="row">
        <div class="col-4">
         <br>
            <input type="submit" name="save" class="btn btn-primary"/>
        </div>
 </div>
      <br>
	  </form>
       </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
