<?php
  include('header.php');
   session_start();
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('studentsidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Blank Page</li>
      </ol>
      <div class="row">
        
      </div>
      <div class="form-row">
          <div class="col-md-4">
                <label for="exampleInputName">First name</label>
                <input class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name">
          </div>
           <div class="col-md-4">
                <label for="exampleInputLastName">Middle name</label>
                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter middle name">
           </div>
           <div class="col-md-4">
                <label for="exampleInputLastName">Last name</label>
                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter last name">
           </div>
      
      </div>
   <br>

 <div class="form-row">
              <div class="col-md-4">
                <label for="exampleInputName">Designation</label>
                <input class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">Phone Number</label>
                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter middle name">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">Date Of Birth</label>
                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter last name">
              </div>
            </div>
      <br>


 <div class="form-row">
     <div class="col-md-4">
        <label for="exampleInputLastName">Gender</label>
            <select class="form-control">
            <option value="">Select gender</option>
                <option value="">Male</option>
                   <option value="">Female</option>
                             
            </select>
     </div>
       <div class="col-md-4">
          <label for="exampleInputLastName">Date of joining</label>
            <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter last name">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">class</label>
                    <select class="form-control">
                    <option value="">Select class</option>
                      <option value="">1</option>
                        <option value="">2</option>
                    </select>
                 </div>
            </div>
      <br>

  
 <div class="form-row">
              <div class="col-md-4">
                <label for="exampleInputName">Address</label>
                <input class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name">
              </div>
        <div class="col-md-4">
                <label for="exampleInputLastName">Email_id</label>
                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter middle name">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">Contact_no</label>
                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter last name">
              </div>
            </div>
            <div class="col-4">
         <br>
            <input type="submit" name="save" class="btn btn-primary"/>
        </div>
      <br>
       </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
