<?php
  include('header.php');
?>
<body>
	<div class="container-fluid">
	<div class="row">
		<div class="col-sm-3">
			<p>SSC Examination On English</p>
			<p>Class : 10th Subject : Grammer</p>
			<p>Chapter : Tense Article : A</p>
		</div>
		<div class="col-sm-6 text-center text-warning">
			<h2 id="countDown"></h2>
		</div>
		<div class="col-sm-3">
			<p>Spoke Eng </p>
			<p>Leader of English</p>
			<p>Achive Your Goals</p>
		</div>
	</div>
	<hr/>
	 <div class="row">
	  <div class="col-sm-9 questionList">
	  </div>
	  <div class="col-sm-3">
		<div class="statusTemplate"></div>
		<p>
			<button class="btn btn-success solved" data-content="key" data-value="key">1</button><b>Solved</b>
		</p>
		<p>
			<button class="btn btn-danger unsolved" data-content="key" data-value="key">2</button><b>Un Solved</b>
		</p>
	  </div>
	</div>
	<script type="text/html" id="status">
		<button class="btn btn-success solved" data-content="key" data-value="key" onclick="goOn(this.value)"></button>
	</script>
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
    <script src="js/sb-admin-charts.min.js"></script>
	<script src="js/jquery.loadTemplate.min.js"></script>
	 <script src="js/basic.js"></script>
	 <script src="search.js"></script>
	<script>
	var countDown = function(minutes){
		var total_seconds = minutes*60;
		var hours = Math.floor(total_seconds/3600);
		var minutes = Math.floor((total_seconds%3600)/60);
		var seconds = Math.floor((total_seconds%3600)%60);
		$("#countDown").text(hours+" HR "+minutes+" MIN "+seconds+" SEC ");
		setInterval(function(){
			total_seconds = total_seconds - 1;
			if(total_seconds==0){
				endTest();
			}else{
				var hours = Math.floor(total_seconds/3600);
				var minutes = Math.floor((total_seconds%3600)/60);
				var seconds = Math.floor((total_seconds%3600)%60);
				$("#countDown").text(hours+" HR "+minutes+" MIN "+seconds+" SEC ");
			}
			
		},1000);
	}
	var endTest = function(){
		var examResponse = {};
		var marks_per_question = Number(exam.marks_per_question);
		var marks_per_wrong_question = marks_per_question*exam.negative_type;
		var marks_gained = 0;
		var negative_marks = 0;
		var correct = 0;
		var wrong = 0;
		var not_attempted = 0;
		var attempted = 0;
		var total_marks = 0;
		$.each(questionList,function(key,value){
			if(value['correct_option']==value['response']){
				//Only for Correct Answers
				marks_gained += marks_per_question;
				correct+= 1;
			}else{
				if(!value['response']){
					not_attempted+= 1;
				}else{
					negative_marks += marks_per_wrong_question;
					wrong+= 1;
				}
				
			}
		});
		attempted = correct + wrong;
		total_marks = marks_gained - negative_marks;
		examResponse.response = JSON.stringify(questionList);
		examResponse.class_id = exam.class_id;
		examResponse.exam_id = exam.exam_id;
		examResponse.marks_gained = marks_gained;
		examResponse.negative_marks = negative_marks;
		examResponse.passing_marks = exam.passing_marks;
		examResponse.correct = correct;
		examResponse.wrong = wrong;
		examResponse.not_attempted = not_attempted;
		examResponse.attempted = attempted;
		examResponse.total_marks = total_marks;
		if(total_marks>=exam.passing_marks){
			examResponse.result = "pass";
		}else{
			examResponse.result = "fail";
		}
		examResponse = JSON.stringify(examResponse);
		var url = "server/result.php";
		$.ajax({
		  type: "POST",
		  url: url,
		  data: examResponse,
		  success: function(){
			 localStorage.setItem("examResponse", examResponse);
			 window.location = "stud_exam_report.php";
		  },
		  datatype : "text",
		  contentType: "application/json"
		});
	}
	var setAnswer = function(selectedAnswer){
		questionList[selectedAnswer.name-1].response = selectedAnswer.value;
		console.log(questionList);
	}
	var goPrevious = function(id){
		id = Number(id)-1;
		goOn(id);
	}
	var goNext = function(id){
		id = Number(id)+1;
		goOn(id);
	}
	var goOn = function(id){
		if(id==0){
			alert("First Question");
		}
		else if(id==questionList.length+1){
			alert("Last Question");
		}else{
			$.each(questionList,function(key,value){
				if(value['key']==id){
					$("#"+value['key']).show();
				}else{
					$("#"+value['key']).hide();
				}
			});
		}
	}
	$(document).ready(function(){
	var params = getAllUrlParams(window.location.href);
	var url = "server/get_data.php?questionpaper=true&exam_id="+params['exam_id'];
	$.ajax({
	  type: "GET",
	  url: url,
	  data: null,
	  success: function(questionList){
			  window.questionList = JSON.parse(questionList);
				  $.each(window.questionList,function(key,value){
					  value['key'] = key+1;
					  value['questionsrc'] = "data:"+value['question_mime']+";base64,"+value['question_image'];
					  value['optionAsrc'] = "data:"+value['optionA_mime']+";base64,"+value['optionA_image'];
					  value['optionBsrc'] = "data:"+value['optionB_mime']+";base64,"+value['optionB_image'];
					  value['optionCsrc'] = "data:"+value['optionC_mime']+";base64,"+value['optionC_image'];
					  value['optionDsrc'] = "data:"+value['optionD_mime']+";base64,"+value['optionD_image'];
				  });
			  $(".questionList").loadTemplate("question.html",window.questionList);
			  $(".statusTemplate").loadTemplate("#status",window.questionList);
			  setTimeout(function(){goOn(1)},500);
		  },
	  datatype : "application/json",
	  contentType: "application/json"
	});
	var url2 = "server/get_data.php?exam=true&exam_id="+params['exam_id'];
	$.ajax({
	  type: "GET",
	  url: url2,
	  data: null,
	  success: function(exam){
			window.exam = JSON.parse(exam);
			countDown(new Number(window.exam.exam_duration));
		  },
	  datatype : "application/json",
	  contentType: "application/json"
	});
});
</script>
</body>
</html>