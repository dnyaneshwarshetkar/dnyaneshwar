<?php
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('studentsidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Student Exam Report</li>
      </ol>
			<div class="col-sm-12  table-responsive">
              <table class="table table-bordered" id="examTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Exam No</th>
				    <th>Marks</th>
					<th>Passing Marks</th>
					<th>No of Questions</th>
					<th>Exam Duration</th>
					<th>Exam Date</th>
					<th>Manage</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
		  </div>
	</div>
  </div>
  <?php
      include('footer.php');
  ?>
  <script src="js/stud_exam.js"></script>
</body>
</html>
