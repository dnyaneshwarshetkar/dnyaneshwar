<?php
  include('header.php');
  include('connect.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a> 
        </li>
        <li class="breadcrumb-item active">Exams</li>
      </ol>
      <div class="row">
      <div class="col-md-12">
            <div class="table-responsive">
              <table class="table table-bordered" id="examTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>Exam ID</th>
					<th>Exam Name</th>
                    <th>No of Questions</th>
					<th>Marks</th>
					<th>Passing Marks</th>
					<th>Exam Duration</th>
					<th>Exam Type</th>
					<th>Negative Type</th>
					<th>Exam Date</th>
					<th>Manage</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
    </div>
    
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/exam.js"></script>
</body>

</html>
