<?php
  include('header.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
		<?php if(isset($_GET['stud_id'])){?>
        <li class="breadcrumb-item active">Edit Student</li>
		<?php }else{ ?>
		<li class="breadcrumb-item active">Add Student</li>
		<?php } ?>
      </ol>
	  <?php if(isset($_GET['stud_id'])){ ?>
      <form name="addStudentForm" onsubmit="return submitData(event,<?php echo $_GET['stud_id']?>)" id="addStudentForm">
	  <?php }else{ ?>
	  <form name="addStudentForm" onsubmit="return submitData(event)" id="addStudentForm">
	  <?php } ?>
		<div class="form-row">
		  <div class="form-group col-md-4">
				<label for="first_name">First Name</label>
				<input class="form-control" id="first_name" type="text" name="first_name" placeholder="Enter First Name">
		  </div>
		   <div class="form-group col-md-4">
				<label for="middle_name">Middle Name</label>
				<input class="form-control" id="middle_name" type="text" name="middle_name" placeholder="Enter Middle Name">
		   </div>
		   <div class="form-group col-md-4">
				<label for="last_name">Last Name</label>
				<input class="form-control" id="last_name" type="text" name="last_name" placeholder="Enter Last Name">
		   </div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="mother_name">Mother name</label>
				<input class="form-control" id="mother_name" type="text" name="mother_name" placeholder="Enter Mother Name">
			</div>
			<div class="form-group col-md-4">
				<label for="phone">Phone</label>
				<input class="form-control" id="phone" type="text" name="phone" placeholder="Enter Phone Number">
			</div>
			<div class="form-group col-md-4">
				<label for="dob">Date of Birth</label>
				<input class="form-control" id="dob" type="date" name="dob" placeholder="Enter Date of Birth">
			</div>
        </div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="dob_words">DOB in word</label>
				<input class="form-control" id="dob_words" type="text"  name="dob_words" placeholder="Enter Date of Birth in Words">
			</div>
			<div class="form-group col-md-4">
				<label for="gender">Gender</label>
				<select  name="gender" class="form-control">
					<option value="">Select Gender</option>
				   <option value="male">Male</option>
				   <option value="female">Female</option> 
				</select>
			</div>
			<div class="form-group col-md-4">
				<label for="birth_place"> Birth Place</label>
				<input class="form-control" id="birth_place" type="text" name="birth_place" placeholder="Enter Birth Place">
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="religion">Religion</label>
				<input class="form-control" id="religion" type="text" name="religion" placeholder="Enter Religion">
			</div>
			<div class="form-group col-md-4">
				<label for="caste">Caste</label>
				<input class="form-control" id="caste" type="text" name="caste" placeholder="Enter Caste">
			</div>
			<div class="form-group col-md-4">
				<label for="sub_caste">Sub Caste</label>
				<input class="form-control" id="sub_caste" type="text" name="sub_caste" placeholder="Enter Sub Caste">
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="category">Category</label>
				<input class="form-control" id="category" type="text" name="category" placeholder="Enter Category">
			</div>
			<div class="form-group col-md-4">
				<label for="roll_no">Roll no</label>
				<input class="form-control" id="roll_no" type="text" name="roll_no" placeholder="Enter Roll no">
			</div>
			<div class="form-group col-md-4">
				<label for="class_id">Class</label>
				<select class="form-control custom-select" name="class_id" id="class_id">
					<option value="">Select Class</option>
				</select>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="mother_tongue">Mother Tongue</label>
				<input class="form-control" id="mother_tongue" type="text" name="mother_tongue" placeholder="Enter Mother Tongue">
				</div>
			<div class="form-group col-md-4">
				<label for="address">Address</label>
				<input class="form-control" id="address" type="text" name="address"placeholder="Address">
			</div>
			<div class="form-group col-md-4">
				<label for="handicap_status">Handicap Status</label>
				<select class="form-control custom-select" name="handicap_status" id="handicap_status">
					<option value="">Select Handicap Status</option>
					<option value="yes">YES</option>
					<option value="no">NO</option>
				</select>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="handicap_info">Handicap Information</label>
				<input class="form-control" id="handicap_info" type="text" name="handicap_info" aria-describedby="nameHelp" placeholder="Handicap information">
			</div>
			<div class="form-group col-md-4">
				<label for="udsie_no">UDSIE no</label>
				<input class="form-control" id="udsie_no" type="text" name="udsie_no" placeholder="Enter UDSIE no">
			</div>
			<div class="form-group col-md-4">
				<label for="adhar">Adhar</label>
				<input class="form-control" id="adhar" type="text" name="adhar" aria-describedby="nameHelp" placeholder="Enter Adhar">
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="serial_no">Serial no</label>
				<input class="form-control" id="serial_no" type="text" name="serial_no" placeholder="Enter Serial No">
			</div>
			<div class="form-group col-md-4">
				<label for="admission_no">Admission No</label>
				<input class="form-control" id="admission_no" type="text" name="admission_no" placeholder="Admission No">
			</div>
			<div class="form-group col-md-4">
				<label for="password">Password</label>
				<input class="form-control" id="password" type="password" name="password" placeholder="Enter your Password">
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="status">Status</label>
				<select class="form-control custom-select" name="status" id="status">
					<option value="">Select Status</option>
					<option value="1">Active</option>
					<option value="0">Inactive</option>
				</select>
			</div>
		</div>
        <input type="submit" name="submit" class="btn btn-primary"/>
		</form>
	</div>
  </div>
<?php
  include('footer.php');
?>
<script src="js/student.js"></script>
</body>
</html>
