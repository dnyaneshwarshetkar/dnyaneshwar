<?php
	ini_set('display_errors', 1); 
	error_reporting(E_ALL);
    session_start();
    require "connect.php";
 
   if(isset($_POST['username']) && isset($_POST['password']) )
   { 
		$myusername = $_POST['username'];
		$mypassword = $_POST['password']; 
  
		$_SESSION['username']=$myusername;
		$_SESSION['passsword']=$mypassword;
	
		$sql="SELECT * FROM student WHERE first_name='$myusername' AND phone='$mypassword'";
	
		$result = $con->query($sql);

		$sql1="SELECT * FROM teacher WHERE first_name ='$myusername' AND mobile='$mypassword'";
	
		$result1 = $con->query($sql1);

		$sql2="SELECT * FROM teacher WHERE first_name ='$myusername' AND mobile='$mypassword' AND designation='Accountant'";
	
		$result2 = $con->query($sql2);
		if($result->num_rows==1)
			{
				$row = mysqli_fetch_assoc($result);
				$_SESSION['class_id'] = $row['class_id'];
				$_SESSION['stud_id'] = $row['stud_id'];
				$_SESSION['student'] = $row;
				header("location: sdashboard.php");
			}
		if($result1->num_rows==1)
			{
				$row = mysqli_fetch_assoc($result1);
				$_SESSION['teacher'] = $row;
				header("location: tea_home.php");
			}
		if($result2->num_rows==1)
			{
				$row = mysqli_fetch_assoc($result2);
				$_SESSION['teacher'] = $row;
				header("location: dashboard.php");
			}
		else 
			{
				echo "<script>alert('invalid username and password');			
						window.location.assign('index.html');
						</script>";
			}
	   }
	   else
	   {
		   echo "<script>alert('Enter Username or Password');
						window.location.assign('index.html');
						</script>";
	   }
?>
