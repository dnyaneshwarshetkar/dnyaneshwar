<?php
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Student List</li>
      </ol>
      <div class="row">
    <div class="col-md-12">
		<div class="table-responsive">
		  <table class="table table-bordered" id="studentTable" width="100%" cellspacing="0">
		  <caption>Student List</caption>
			<thead>
			  <tr>
				<th>Sr. No.</th>
				<th>Student Name</th>
				<th>Class</th>
				<th>Phone</th>
				<th>Password</th>
				<th>Status</th>
				<th>Manage</th>
			  </tr>
			</thead>
			<tbody>
			</tbody>
		  </table>
		</div>
    </div>
    <div class="bonafied" style="display:none"></div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/student.js"></script>
	<script src="js/jquery.loadTemplate.min.js"></script>
	<script type="text/html" id="bonafied">
		<h1>Bonafied</h1>
		<p>this is to certify that Mr. 
			<b data-content="first_name"></b>
			<b data-content="middle_name"></b>
			<b data-content="last_name"></b>
			is student of class <b data-content="class_name"></b>
		</p>
	</script>
  </div>
</body>

</html>
