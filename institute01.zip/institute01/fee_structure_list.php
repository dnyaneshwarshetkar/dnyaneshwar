<?php
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Fee Structure List</li>
      </ol>
    <div class="row">
    <div class="col-md-12">
		<div class="table-responsive">
		  <table class="table table-bordered" id="feeTable" width="100%" cellspacing="0">
		  <caption>Fee Structure List</caption>
			<thead>
			  <tr>
				<th>Fee Id</th>
				<th>Class</th>
				<th>Monthly Fees</th>
				<th>Exam Fees</th>
				<th>Term 1</th>
				<th>Term 2</th>
				<th>Manage</th>
			  </tr>
			</thead>
			<tbody>
			</tbody>
		  </table>
		</div>
    </div>
    
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/fee_structure.js"></script>
  </div>
</body>

</html>
