<?php
include('../connect.php');
session_start();
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
$exam_id = $decoded['exam_id'];
$stud_id = $_SESSION['Stud_id'];
$correct = $decoded['correct'];
$wrong = $decoded['wrong'];
$marks_gained = $decoded['marks_gained'];
$attempted = $decoded['attempted'];
$not_attempted = $decoded['not_attempted'];
$result = $decoded['result'];
$negative_marks = $decoded['negative_marks'];
$total_marks = $decoded['total_marks'];
$response = $decoded['response'];
$sql = "INSERT INTO student_exam(exam_id,stud_id,correct,wrong,marks_gained,negative_marks,total_marks,response,attempted,not_attempted,result)VALUES ('$exam_id','$stud_id','$correct','$wrong','$marks_gained','$negative_marks','$total_marks','$response','$attempted','$not_attempted','$result')";
if($con->query($sql)){
	echo "SUCCESS";
}
else{
echo mysqli_error($con); 
}
 ?>