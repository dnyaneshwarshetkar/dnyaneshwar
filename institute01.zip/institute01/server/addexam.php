<?php
include('../connect.php');
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
print_r($decoded);
$exam_type = $decoded["exam_type"];
if($exam_type==1){
	$class_id = $decoded["class_id"];
	$subject_id =0;
	$chapter_id =0;
	$article_id =0;
}
if($exam_type==2){
	$class_id = $decoded["class_id"];
	$subject_id =$decoded["subject_id"];
	$chapter_id =0;
	$article_id =0;
	
}
if($exam_type==3){
	$class_id = $decoded["class_id"];
	$subject_id =$decoded["subject_id"];
	$chapter_id =$decoded["chapter_id"];
	$article_id =0;
}
if($exam_type==4){
	$class_id = $decoded["class_id"];
	$subject_id =$decoded["subject_id"];
	$chapter_id =$decoded["chapter_id"];
	$article_id =$decoded["article_id"];
}
$exam_name=str_ireplace("%20"," ", trim($decoded["exam_name"]));
$exam_date = $decoded["exam_date"];
$marks = $decoded["marks"];
$passing_marks = $decoded["passing_marks"];
$no_of_questions = $decoded["no_of_questions"];
$marks_per_question = $decoded["marks_per_question"];
$questions = $decoded["questions"];
$exam_type = $decoded["exam_type"];
$negative_type = $decoded["negative_type"];
$exam_duration = $decoded["exam_duration"];
$sql = "INSERT INTO exam(class_id,subject_id,chapter_id,article_id,exam_name,exam_date,marks,passing_marks,exam_duration,no_of_questions,questions,exam_type,negative_type,marks_per_question)VALUES ('$class_id','$subject_id','$chapter_id','$article_id','$exam_name','$exam_date','$marks','$passing_marks','$exam_duration','$no_of_questions','$questions','$exam_type','$negative_type','$marks_per_question')";
if($con->query($sql)){
	echo "Success";
}
  else{
	echo mysqli_error($con); 
  }
 ?>