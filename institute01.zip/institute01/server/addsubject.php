<?php
include('../connect.php');
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
$class_id = trim($decoded["class_id"]); 
$subject_name = trim($decoded["subject_name"]); 
$subject_name=str_ireplace("%20"," ",$subject_name);
$sql = "INSERT INTO subject(class_id,subject_name)VALUES ('$class_id','$subject_name')";
if($con->query($sql)){
	echo "SUCCESS";
}
  else{
	echo mysqli_error($con); 
  }
 ?>