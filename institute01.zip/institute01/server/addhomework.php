<?php
include('../connect.php');
session_start();
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
if($_GET['table']=='homework'){
$class_id = trim($decoded["class_id"]);
$subject_id = trim($decoded["subject_id"]);
$homework = trim($decoded["homework"]);
$teach_id = $_SESSION['teacher']['teach_id'];
$date = $decoded["date"];
$status = 1;
if(isset($_GET['home_id'])){
	$home_id = $_GET['home_id'];
	$sql = "update homework set class_id='$class_id',subject_id='$subject_id',homework='$homework',teach_id='$teach_id',status='$status',date='$date' where home_id=$home_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Homework Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Homework Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "insert into  homework(class_id,subject_id,homework,teach_id,date,status)values('$class_id','$subject_id','$homework','$teach_id','$date','$status')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Homework Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Homework Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}else{
	
}
 ?>