<?php
include('../connect.php');
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
$class_id = $decoded["class_id"]; 
$subject_id = $decoded["subject_id"]; 
$chapter_id = $decoded["chapter_id"]; 
$article_name = trim($decoded["article_name"]); 
$article_name=str_ireplace("%20"," ",$article_name);
$sql = "INSERT INTO articles(class_id,subject_id,chapter_id,article_name)VALUES ('$class_id','$subject_id','$chapter_id','$article_name')";
if($con->query($sql)){
	echo "Success"; 
}
  else{
	echo "Wrong"; 
  }
 ?>