<?php
include('../connect.php');
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if($_GET['table']=='fee'){
$class_id	=	$decoded['class_id'];
$monthly_fees =	$decoded['monthly_fees'];
$exam_fees	=	$decoded['exam_fees'];
$term1	=	$decoded['term1'];
$term2	=	$decoded['term2'];
if(isset($_GET['fee_id'])){
	$fee_id = $_GET['fee_id'];
	$sql = "update fee set monthly_fees='$monthly_fees',exam_fees='$exam_fees',term1='$term1',term2='$term2' where fee_id=$fee_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Fee Struture Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Fee Structure Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  fee(monthly_fees,exam_fees,term1,term2)VALUES ('$class_id','$monthly_fees','$exam_fees','$term1','$term2')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Fee Structure Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Fee Structure Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}	
}
 ?>