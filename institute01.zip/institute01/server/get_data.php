<?php
require_once("..\connect.php");
session_start();
if(isset($_GET['subject'])&& isset($_GET['class_id'])){
	$return = array();
	$class_id = $_GET['class_id'];
	$query = mysqli_query($con,"SELECT * FROM subject where class_id =$class_id");
	while($row=mysqli_fetch_assoc($query)){
		array_push($return,$row);
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['chapter'])&& isset($_GET['subject_id'])){
	$return = array();
	$subject_id = $_GET['subject_id'];
	$query = mysqli_query($con,"SELECT * FROM chapters where subject_id =$subject_id");
	while($row=mysqli_fetch_assoc($query)){
		array_push($return,$row);
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['article'])&& isset($_GET['chapter_id'])){
	$return = array();
	$chapter_id = $_GET['chapter_id'];
	$query = mysqli_query($con,"SELECT * FROM articles where chapter_id =$chapter_id");
	while($row=mysqli_fetch_assoc($query)){
		array_push($return,$row);
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['question'])){
	if(isset($_GET['class_id'])){
		$class_id = $_GET['class_id'];
		$query = mysqli_query($con,"SELECT * FROM questions where class_id =$class_id");
	}
	if(isset($_GET['subject_id'])){
		$subject_id = $_GET['subject_id'];
		$query = mysqli_query($con,"SELECT * FROM questions where subject_id =$subject_id");
	}
	if(isset($_GET['chapter_id'])){
		$chapter_id = $_GET['chapter_id'];
		$query = mysqli_query($con,"SELECT * FROM questions where chapter_id =$chapter_id");
	}
	if(isset($_GET['article_id'])){
		$article_id = $_GET['article_id'];
		$query = mysqli_query($con,"SELECT * FROM questions where article_id =$article_id");
	}
	$return = array();
	while($row=mysqli_fetch_assoc($query)){
		array_push($return,$row);
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['stud_exam'])){
	$return = array();
	$class_id = $_SESSION['class_id'];
	$result=mysqli_query($con,"SELECT * FROM exam where class_id=$class_id");
	while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['exam'])&&isset($_GET['data'])){
	$return = array();
	$result=mysqli_query($con,"SELECT * FROM exam");
	while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['questionpaper'])&&isset($_GET['exam_id'])){
	$return = array();
	$exam_id = $_GET['exam_id'];
	$result = mysqli_query($con,"SELECT * FROM exam where exam_id=$exam_id");
	$row = mysqli_fetch_assoc($result);
	$ids = join(",",json_decode($row['questions']));
	$que= "SELECT * from questions where question_id IN ($ids)";
	$questions = mysqli_query($con,$que);
	while($row = mysqli_fetch_assoc($questions)){
		$row['question_image'] = base64_encode($row['question_image']);
		$row['optionA_image'] = base64_encode($row['optionA_image']);
		$row['optionB_image'] = base64_encode($row['optionB_image']);
		$row['optionC_image'] = base64_encode($row['optionC_image']);
		$row['optionD_image'] = base64_encode($row['optionD_image']);
		array_push($return,$row);
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['printpaper'])&&isset($_GET['exam_id'])){
	$questionBank = array();
	$exam_id = $_GET['exam_id'];
	$result = mysqli_query($con,"SELECT * FROM exam where exam_id=$exam_id");
	$exam = mysqli_fetch_assoc($result);
	$ids = join(",",json_decode($exam['questions']));
	$que= "SELECT * from questions where question_id IN ($ids)";
	$questions = mysqli_query($con,$que);
	while($row = mysqli_fetch_assoc($questions)){
		array_push($questionBank,$row);
	}
	$return = array();
	$return['exam'] = $exam;
	$return['questions'] = $questionBank;
	echo json_encode($return);
}
if(isset($_GET['exam'])&&isset($_GET['exam_id'])){
	$exam_id = $_GET['exam_id'];
	$result = mysqli_query($con,"SELECT * FROM exam where exam_id=$exam_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}
if(isset($_GET['student'])&&isset($_GET['stud_id'])){
	$stud_id = $_GET['stud_id'];
	$result = mysqli_query($con,"SELECT * FROM student where stud_id=$stud_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}
if(isset($_GET['student'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT  s.stud_id,s.first_name,s.middle_name,s.last_name,s.password,s.phone,s.status,c.class_id,c.class_name FROM student as s inner join class as c on s.class_id = c.class_id");
	echo mysqli_error($con);
	while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['teacher'])&&isset($_GET['teach_id'])){
	$teach_id = $_GET['teach_id'];
	$result = mysqli_query($con,"SELECT * FROM teacher where teach_id=$teach_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}
if(isset($_GET['teacher'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT  t.teach_id,t.first_name,t.middle_name,t.last_name,t.mobile,t.password,t.status,c.class_id,c.class_name FROM teacher as t inner join class as c on t.class_id = c.class_id");
	if(mysqli_affected_rows($con)>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}else{
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['fee'])&&isset($_GET['fee_id'])){
	$fee_id = $_GET['fee_id'];
	$result = mysqli_query($con,"SELECT * FROM fee where fee_id=$fee_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}
if(isset($_GET['fee'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT  f.fee_id,f.monthly_fees,f.exam_fees,f.term1,f.term2,c.class_id,c.class_name FROM fee as f inner join class as c on f.class_id = c.class_id");
	echo mysqli_error($con);
	while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['time_table'])&&isset($_GET['time_id'])){
	$time_id = $_GET['time_id'];
	$result = mysqli_query($con,"SELECT * FROM timetable where time_id=$time_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}
if(isset($_GET['time_table'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT  t.time_id,t.time,t.class_id,t.subject_id,s.subject_name,t.teach_id,l.first_name,l.middle_name,l.last_name,c.class_name FROM timetable as t inner join class as c on t.class_id = c.class_id inner join teacher as l on t.teach_id = l.teach_id inner join subject as s on t.subject_id = s.subject_id");
	echo mysqli_error($con);
	if(mysqli_affected_rows($con)>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}else{
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['stime_table'])&&isset($_GET['data'])){
	$return = array();
	$class_id = $_SESSION['class_id'];
	$result = mysqli_query($con,"SELECT  t.time_id,t.time,t.class_id,t.subject_id,s.subject_name,t.teach_id,l.first_name,l.middle_name,l.last_name,c.class_name FROM timetable as t inner join class as c on t.class_id = c.class_id inner join teacher as l on t.teach_id = l.teach_id inner join subject as s on t.subject_id = s.subject_id where t.class_id=$class_id");
	echo mysqli_error($con);
	if(mysqli_affected_rows($con)>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}else{
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['notice'])&&isset($_GET['notice_id'])){
	$notice_id = $_GET['notice_id'];
	$result = mysqli_query($con,"SELECT * FROM notice where notice_id=$notice_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}
if(isset($_GET['notice'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT n.notice_id,n.notice,n.receiver,n.date,n.status,n.sender_id,t.first_name,t.middle_name,t.last_name from notice as n inner join teacher as t on n.sender_id = t.teach_id");
	echo mysqli_error($con);
	if(mysqli_affected_rows($con)>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}else{
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['snotice'])&&isset($_GET['data'])){
	$return = array();
	$receiver = $_SESSION['class_id'];
	$result = mysqli_query($con,"SELECT n.notice_id,n.notice,n.receiver,n.date,n.status,n.sender_id,t.first_name,t.middle_name,t.last_name from notice as n inner join teacher as t on n.sender_id = t.teach_id where receiver = $receiver or receiver='allclass'");
	echo mysqli_error($con);
	if(mysqli_affected_rows($con)>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}else{
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['homework'])&&isset($_GET['home_id'])){
	$home_id = $_GET['home_id'];
	$result = mysqli_query($con,"SELECT * FROM homework where home_id=$home_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}
if(isset($_GET['homework'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT h.home_id,h.class_id,h.subject_id,h.teach_id,h.homework,h.date,c.class_name,s.subject_name,t.first_name,t.middle_name,t.last_name from homework as h inner join class as c on h.class_id = c.class_id inner join subject as s on h.subject_id = s.subject_id inner join teacher as t on h.teach_id = t.teach_id");
	if(mysqli_affected_rows($con)>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}else{
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['shomework'])&&isset($_GET['data'])){
	$return = array();
	$class_id = $_SESSION['class_id'];
	$result = mysqli_query($con,"SELECT h.home_id,h.class_id,h.subject_id,h.teach_id,h.homework,h.date,c.class_name,s.subject_name,t.first_name,t.middle_name,t.last_name from homework as h inner join class as c on h.class_id = c.class_id inner join subject as s on h.subject_id = s.subject_id inner join teacher as t on h.teach_id = t.teach_id where h.class_id=$class_id");
	//echo mysqli_error($con);
	if(mysqli_affected_rows($con)>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}else{
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['class'])&&isset($_GET['class_id'])){
	$class_id = $_GET['class_id'];
	$result = mysqli_query($con,"SELECT * FROM class where class_id=$class_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}
if(isset($_GET['class'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT * from class");
	if(mysqli_affected_rows($con)>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}else{
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['attendance'])&&isset($_GET['data'])&&isset($_GET['class_id'])){
	$class_id = $_GET['class_id'];
	$return = array();
	$result = mysqli_query($con,"SELECT  s.stud_id, s.first_name,s.middle_name,s.last_name from student as s where s.class_id='$class_id'");
	if(mysqli_affected_rows($con)>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}else{
		
	}
	$return = json_encode($return);
	echo $return;
}
if(isset($_GET['questions'])&&isset($_GET['question_id'])){
	$question_id = $_GET['question_id'];
	$return = array();
	$result = mysqli_query($con,"SELECT q.class_id,q.subject_id,q.chapter_id,q.article_id,q.question_type,q.question,q.option_type,q.optionA,q.optionB,q.optionC,q.optionD,q.reason,q.correct_option,q.question_image as qi,q.question_mime as qm,q.optionA_image as oai,q.optionA_mime as oam,q.optionB_image as obi,q.optionB_mime as obm,q.optionC_image as oci,q.optionC_mime as ocm,q.optionD_image as odi,q.optionD_mime as odm from questions as q where question_id=$question_id");
	$row = mysqli_fetch_assoc($result);
	$row['qi'] = base64_encode($row['qi']);
	$row['oai'] = base64_encode($row['oai']);
	$row['obi'] = base64_encode($row['obi']);
	$row['oci'] = base64_encode($row['oci']);
	$row['odi'] = base64_encode($row['odi']);
	$row = json_encode($row);
	echo $row;
}
if(isset($_GET['questions'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT q.question_id,q.question,q.status,c.class_name,s.subject_name,ch.chapter_name,s.subject_name,a.article_name from questions as q inner join class as c on q.class_id=c.class_id inner join subject as s on q.subject_id = s.subject_id inner join chapters as ch on q.chapter_id = ch.chapter_id inner join articles as a on q.article_id = a.article_id");
	if(mysqli_affected_rows($con)>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}else{
		
	}
	$return = json_encode($return);
	echo $return;
}
?>