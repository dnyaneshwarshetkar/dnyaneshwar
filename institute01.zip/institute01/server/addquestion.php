<?php
include('../connect.php');
//print_r($_POST);
//print_r($_FILES);
$decoded = $_POST;
if($_GET['table']=='questions'){
$class_id=$decoded['class_id'];
$subject_id=$decoded['subject_id'];
$chapter_id=$decoded['chapter_id'];
$article_id = $decoded['article_id'];
$question_type =$decoded["question_type"];
$option_type =$decoded["option_type"];
$correct_option = $decoded['correct_option'];
$reason =$decoded["reason"];
//if question type is text then we have to set only question
if($question_type=='text'){
	$question =$decoded["question"];
}
if($option_type=='text'){
	$optionA =$decoded["optionA"];
	$optionB =$decoded["optionB"];
	$optionC =$decoded["optionC"];
	$optionD =$decoded["optionD"];
}
//if question type is image then we have to set only question_image,question_mime
if($question_type=='image'){
	if($_FILES['question_image']['error']==0){
		$fp0 = fopen($_FILES['question_image']['tmp_name'], "r");
		$question_image  = fread($fp0, $_FILES['question_image']['size']);
		$question_mime =  $_FILES['question_image']['type'];
		fclose($fp0);
		$question_image = mysqli_real_escape_string($con, $question_image);
	}
}
//if option type is image then we have to set only optionABCD_image,optionABCD_mime
if($option_type=='image'){
	if($_FILES['optionA_image']['error']==0){
		$fp1 = fopen($_FILES['optionA_image']['tmp_name'], "r");
		$optionA_image = fread($fp1, $_FILES['optionA_image']['size']);
		$optionA_mime =  $_FILES['optionA_image']['type'];
		fclose($fp1);
		$optionA_image= mysqli_real_escape_string($con, $optionA_image);
	
	}
	if($_FILES['optionB_image']['error']==0){
		$fp2 = fopen($_FILES['optionB_image']['tmp_name'], "r");
		$optionB_image = fread($fp2, $_FILES['optionB_image']['size']);
		$optionB_mime =  $_FILES['optionB_image']['type'];
		fclose($fp2);
		$optionB_image= mysqli_real_escape_string($con, $optionB_image);
	}
	if($_FILES['optionC_image']['error']==0){
		$fp3 = fopen($_FILES['optionC_image']['tmp_name'], "r");
		$optionC_image = fread($fp3, $_FILES['optionC_image']['size']);
		$optionC_mime =  $_FILES['optionC_image']['type'];
		fclose($fp3);
		$optionC_image= mysqli_real_escape_string($con, $optionC_image);
	}
	if($_FILES['optionD_image']['error']==0){
		$fp4 = fopen($_FILES['optionD_image']['tmp_name'], "r");
		$optionD_image = fread($fp4, $_FILES['optionD_image']['size']);
		$optionD_mime =  $_FILES['optionD_image']['type'];
		fclose($fp4);
		$optionD_image= mysqli_real_escape_string($con, $optionD_image);
	}
}
//if question type is textimage then we have to set only question,question_image,question_mime
if($question_type=='textimage'){
	$question =$decoded["question"];
	if($_FILES['question_image']['error']==0){
		$fp0 = fopen($_FILES['question_image']['tmp_name'], "r");
		$question_image  = fread($fp0, $_FILES['question_image']['size']);
		$question_mime =  $_FILES['question_image']['type'];
		fclose($fp0);
		$question_image = mysqli_real_escape_string($con, $question_image);
	}
}
//if option type is textimage then we have to set only optionABCD,optionABCD_image,optionABCD_mime
if($option_type=="textimage"){
	$optionA =$decoded["optionA"];
	$optionB =$decoded["optionB"];
	$optionC =$decoded["optionC"];
	$optionD =$decoded["optionD"];
	if($_FILES['optionA_image']['error']==0){
		$fp1 = fopen($_FILES['optionA_image']['tmp_name'], "r");
		$optionA_image = fread($fp1, $_FILES['optionA_image']['size']);
		$optionA_mime =  $_FILES['optionA_image']['type'];
		fclose($fp1);
		$optionA_image= mysqli_real_escape_string($con, $optionA_image);
	}
	if($_FILES['optionB_image']['error']==0){
	$fp2 = fopen($_FILES['optionB_image']['tmp_name'], "r");
	$optionB_image = fread($fp2, $_FILES['optionB_image']['size']);
		$optionB_mime =  $_FILES['optionB_image']['type'];
		fclose($fp2);
		$optionB_image= mysqli_real_escape_string($con, $optionB_image);
	}
	if($_FILES['optionC_image']['error']==0){
		$fp3 = fopen($_FILES['optionC_image']['tmp_name'], "r");
		$optionC_image = fread($fp3, $_FILES['optionC_image']['size']);
		$optionC_mime =  $_FILES['optionC_image']['type'];
		fclose($fp3);
		$optionC_image= mysqli_real_escape_string($con, $optionC_image);
	}
	if($_FILES['optionD_image']['error']==0){
		$fp4 = fopen($_FILES['optionD_image']['tmp_name'], "r");
		$optionD_image = fread($fp4, $_FILES['optionD_image']['size']);
		$optionD_mime =  $_FILES['optionD_image']['type'];
		fclose($fp4);
		$optionD_image= mysqli_real_escape_string($con, $optionD_image);
	}
}
if(isset($_GET['question_id'])){
	$question_id = $_GET['question_id'];
	$sql = "";
	if($question_type=='text'&&$option_type=='text'){
		$mendotary = "update questions set class_id='$class_id',subject_id='$subject_id',chapter_id='$chapter_id',article_id='$article_id',question_type='$question_type',question='$question',option_type='$option_type',optionA='$optionA',optionB='$optionB',optionC='$optionC',optionD='$optionD',correct_option='$correct_option',reason='$reason' where question_id=$question_id";
		$sql = $mendotary."where question_id=$question_id";
	}
	if($question_type=='text'&&$option_type=='image'){
		$mendotary = "update questions set class_id='$class_id',subject_id='$subject_id',chapter_id='$chapter_id',article_id='$article_id',question_type='$question_type',question='$question',option_type='$option_type',correct_option='$correct_option',reason='$reason'";
		if(isset($optionA_image)&&isset($optionA_mime)){
			$mendotary.=",optionA_image='$optionA_image',optionA_mime='$optionA_mime'";
		}
		if(isset($optionB_image)&&isset($optionB_mime)){
			$mendotary.=",optionB_image='$optionB_image',optionB_mime='$optionB_mime'";
		}
		if(isset($optionC_image)&&isset($optionC_mime)){
			$mendotary.=",optionC_image='$optionC_image',optionC_mime='$optionC_mime'";
		}
		if(isset($optionD_image)&&isset($optionD_mime)){
			$mendotary.=",optionD_image='$optionD_image',optionD_mime='$optionD_mime'";
		}
		$sql = $mendotary."where question_id=$question_id";
	}
	if($question_type=='text'&&$option_type=='textimage'){
		$mendotary = "update questions set class_id='$class_id',subject_id='$subject_id',chapter_id='$chapter_id',article_id='$article_id',question_type='$question_type',question='$question',option_type='$option_type',correct_option='$correct_option',reason='$reason'";
		if(isset($optionA_image)&&isset($optionA_mime)){
			$mendotary.=",optionA_image='$optionA_image',optionA_mime='$optionA_mime'";
		}
		if(isset($optionB_image)&&isset($optionB_mime)){
			$mendotary.=",optionB_image='$optionB_image',optionB_mime='$optionB_mime'";
		}
		if(isset($optionC_image)&&isset($optionC_mime)){
			$mendotary.=",optionC_image='$optionC_image',optionC_mime='$optionC_mime'";
		}
		if(isset($optionD_image)&&isset($optionD_mime)){
			$mendotary.=",optionD_image='$optionD_image',optionD_mime='$optionD_mime'";
		}
		$sql = $mendotary."where question_id=$question_id";
	}
	if($question_type=='image'&&$option_type=='text'){
		$mendotary = "update questions set class_id='$class_id',subject_id='$subject_id',chapter_id='$chapter_id',article_id='$article_id',question_type='$question_type',question='$question',option_type='$option_type',correct_option='$correct_option',reason='$reason'";
		if(isset($question_image)&&isset($question_mime)){
			$mendotary.=",question_image='$question_image',question_mime='$question_mime'";
		}
		$sql = $mendotary."where question_id=$question_id";
	}
	if($question_type=='image'&&$option_type=='image'){
		$mendotary = "update questions set class_id='$class_id',subject_id='$subject_id',chapter_id='$chapter_id',article_id='$article_id',question_type='$question_type',question='$question',option_type='$option_type',correct_option='$correct_option',reason='$reason'";
		if(isset($question_image)&&isset($question_mime)){
			$mendotary.=",question_image='$question_image',question_mime='$question_mime'";
		}
		if(isset($optionA_image)&&isset($optionA_mime)){
			$mendotary.=",optionA_image='$optionA_image',optionA_mime='$optionA_mime'";
		}
		if(isset($optionB_image)&&isset($optionB_mime)){
			$mendotary.=",optionB_image='$optionB_image',optionB_mime='$optionB_mime'";
		}
		if(isset($optionC_image)&&isset($optionC_mime)){
			$mendotary.=",optionC_image='$optionC_image',optionC_mime='$optionC_mime'";
		}
		if(isset($optionD_image)&&isset($optionD_mime)){
			$mendotary.=",optionD_image='$optionD_image',optionD_mime='$optionD_mime'";
		}
		$sql = $mendotary."where question_id=$question_id";
	}
	if($question_type=='image'&&$option_type=='textimage'){
		$mendotary = "update questions set class_id='$class_id',subject_id='$subject_id',chapter_id='$chapter_id',article_id='$article_id',question_type='$question_type',question='$question',option_type='$option_type',correct_option='$correct_option',reason='$reason'";
		if(isset($question_image)&&isset($question_mime)){
			$mendotary.=",question_image='$question_image',question_mime='$question_mime'";
		}
		if(isset($optionA_image)&&isset($optionA_mime)){
			$mendotary.=",optionA_image='$optionA_image',optionA_mime='$optionA_mime'";
		}
		if(isset($optionB_image)&&isset($optionB_mime)){
			$mendotary.=",optionB_image='$optionB_image',optionB_mime='$optionB_mime'";
		}
		if(isset($optionC_image)&&isset($optionC_mime)){
			$mendotary.=",optionC_image='$optionC_image',optionC_mime='$optionC_mime'";
		}
		if(isset($optionD_image)&&isset($optionD_mime)){
			$mendotary.=",optionD_image='$optionD_image',optionD_mime='$optionD_mime'";
		}
		$sql = $mendotary."where question_id=$question_id";
	}
	if($question_type=='textimage'&&$option_type=='text'){
		$mendotary = "update questions set class_id='$class_id',subject_id='$subject_id',chapter_id='$chapter_id',article_id='$article_id',question_type='$question_type',question='$question',option_type='$option_type',optionA='$optionA',optionB='$optionB',optionC='$optionC',optionD='$optionD',correct_option='$correct_option',reason='$reason'";
		if(isset($question_image)&&isset($question_mime)){
			$mendotary+=",question_image='$question_image',question_mime='$question_mime'";
		}
		$sql = $mendotary."where question_id=$question_id";
	}
	if($question_type=='textimage'&&$option_type=='image'){
		$mendotary = "update questions set class_id='$class_id',subject_id='$subject_id',chapter_id='$chapter_id',article_id='$article_id',question_type='$question_type',question='$question',option_type='$option_type',correct_option='$correct_option',reason='$reason'";
		if(isset($question_image)&&isset($question_mime)){
			$mendotary.=",question_image='$question_image',question_mime='$question_mime'";
		}
		if(isset($optionA_image)&&isset($optionA_mime)){
			$mendotary.=",optionA_image='$optionA_image',optionA_mime='$optionA_mime'";
		}
		if(isset($optionB_image)&&isset($optionB_mime)){
			$mendotary.=",optionB_image='$optionB_image',optionB_mime='$optionB_mime'";
		}
		if(isset($optionC_image)&&isset($optionC_mime)){
			$mendotary.=",optionC_image='$optionC_image',optionC_mime='$optionC_mime'";
		}
		if(isset($optionD_image)&&isset($optionD_mime)){
			$mendotary.=",optionD_image='$optionD_image',optionD_mime='$optionD_mime'";
		}
		$sql = $mendotary."where question_id=$question_id";
	}
	if($question_type=='textimage'&&$option_type=='textimage'){
		//echo "TextImage";
		$mendotary = "update questions set class_id='$class_id',subject_id='$subject_id',chapter_id='$chapter_id',article_id='$article_id',question_type='$question_type',question='$question',option_type='$option_type',optionA='$optionA',optionB='$optionB',optionC='$optionC',optionD='$optionD',correct_option='$correct_option',reason='$reason'";
		if(isset($question_image)&&isset($question_mime)){
			$mendotary.=",question_image='$question_image',question_mime='$question_mime'";
		}
		if(isset($optionA_image)&&isset($optionA_mime)){
			$mendotary.=",optionA_image='$optionA_image',optionA_mime='$optionA_mime'";
		}
		if(isset($optionB_image)&&isset($optionB_mime)){
			$mendotary.=",optionB_image='$optionB_image',optionB_mime='$optionB_mime'";
		}
		if(isset($optionC_image)&&isset($optionC_mime)){
			$mendotary.=",optionC_image='$optionC_image',optionC_mime='$optionC_mime'";
		}
		if(isset($optionD_image)&&isset($optionD_mime)){
			$mendotary.=",optionD_image='$optionD_image',optionD_mime='$optionD_mime'";
		}
		$sql = $mendotary."where question_id=$question_id";
		//echo $sql;
	}
	$con->query($sql);
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Question Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Student Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	
	if($question_type=='text'&&$option_type=='text'){
		$sql = "INSERT INTO questions(class_id,subject_id,chapter_id,article_id,question,question_type,option_type,optionA,optionB,optionC,optionD,correct_option,reason,status)VALUES ('$class_id','$subject_id','$chapter_id','$article_id','$question','$question_type','$option_type','$optionA','$optionB','$optionC','$optionD','$correct_option','$reason',1)";
	}
	if($question_type=='text'&&$option_type=='image'){
		$sql = "INSERT INTO questions(class_id,subject_id,chapter_id,article_id,question,question_type,option_type,correct_option,reason,optionA_image,optionA_mime,optionB_image,optionB_mime,optionC_image,optionC_mime,optionD_image,optionD_mime,status)VALUES ('$class_id','$subject_id','$chapter_id','$article_id','$question','$question_type','$option_type','$correct_option','$reason','$optionA_image','$optionA_mime','$optionB_image','$optionB_mime','$optionC_image','$optionC_mime','$optionD_image','$optionD_mime',1)";
	}
	if($question_type=='text'&&$option_type=='textimage'){
		$sql = "INSERT INTO questions(class_id,subject_id,chapter_id,article_id,question_type,question,option_type,optionA,optionB,optionC,optionD,correct_option,reason,optionA_image,optionA_mime,optionB_image,optionB_mime,optionC_image,optionC_mime,optionD_image,optionD_mime,status)VALUES ('$class_id','$subject_id','$chapter_id','$article_id','$question','$question_type','$option_type','$optionA','$optionB','$optionC','$optionD','$correct_option','$reason','$question_image','$question_mime','$optionA_image','$optionA_mime','$optionB_image','$optionB_mime','$optionC_image','$optionC_mime','$optionD_image','$optionD_mime',1)";
	}
	if($question_type=='image'&&$option_type=='text'){
		$sql = "INSERT INTO questions(class_id,subject_id,chapter_id,article_id,question_type,option_type,optionA,optionB,optionC,optionD,correct_option,reason,question_image,question_mime,optionA_image,optionA_mime,optionB_image,optionB_mime,optionC_image,optionC_mime,optionD_image,optionD_mime,status)VALUES ('$class_id','$subject_id','$chapter_id','$article_id','$question_type','$option_type','$optionA','$optionB','$optionC','$optionD','$correct_option','$reason','$question_image','$question_mime',1)";
	}
	if($question_type=='image'&&$option_type=='image'){
		$sql = "INSERT INTO questions(class_id,subject_id,chapter_id,article_id,question_type,option_type,correct_option,reason,question_image,question_mime,optionA_image,optionA_mime,optionB_image,optionB_mime,optionC_image,optionC_mime,optionD_image,optionD_mime,status)VALUES ('$class_id','$subject_id','$chapter_id','$article_id','$question_type','$option_type','$correct_option','$reason','$question_image','$question_mime','$optionA_image','$optionA_mime','$optionB_image','$optionB_mime','$optionC_image','$optionC_mime','$optionD_image','$optionD_mime',1)";
	}
	if($question_type=='image'&&$option_type=='textimage'){
		$sql = "INSERT INTO questions(class_id,subject_id,chapter_id,article_id,question_type,option_type,optionA,optionB,optionC,optionD,correct_option,reason,question_image,question_mime,optionA_image,optionA_mime,optionB_image,optionB_mime,optionC_image,optionC_mime,optionD_image,optionD_mime,status)VALUES ('$class_id','$subject_id','$chapter_id','$article_id','$question_type','$option_type','$optionA','$optionB','$optionC','$optionD','$correct_option','$reason','$question_image','$question_mime','$optionB_image','$optionB_mime','$optionB_image','$optionB_mime','$optionC_image','$optionC_mime','$optionD_image','$optionD_mime',1)";
	}
	if($question_type=='textimage'&&$option_type=='text'){
		$sql = "INSERT INTO questions(class_id,subject_id,chapter_id,article_id,question_type,question,option_type,optionA,optionB,optionC,optionD,correct_option,reason,question_image,question_mime,optionA_image,optionA_mime,optionB_image,optionB_mime,optionC_image,optionC_mime,optionD_image,optionD_mime,status)VALUES ('$class_id','$subject_id','$chapter_id','$article_id','$question','$question_type','$option_type','$optionA','$optionB','$optionC','$optionD','$correct_option','$reason','$question_image','$question_mime',1)";
	}
	if($question_type=='textimage'&&$option_type=='image'){
		$sql = "INSERT INTO questions(class_id,subject_id,chapter_id,article_id,question_type,question,option_type,correct_option,reason,question_image,question_mime,optionA_image,optionA_mime,optionB_image,optionB_mime,optionC_image,optionC_mime,optionD_image,optionD_mime,status)VALUES ('$class_id','$subject_id','$chapter_id','$article_id','$question','$question_type','$option_type','$correct_option','$reason','$question_image','$question_mime','$optionA_image','$optionA_mime','$optionB_image','$optionB_mime','$optionC_image','$optionC_mime','$optionD_image','$optionD_mime',1)";
	}
	if($question_type=='textimage'&&$option_type=='textimage'){
		$sql = "INSERT INTO questions(class_id,subject_id,chapter_id,article_id,question_type,question,option_type,optionA,optionB,optionC,optionD,correct_option,reason,question_image,question_mime,optionA_image,optionA_mime,optionB_image,optionB_mime,optionC_image,optionC_mime,optionD_image,optionD_mime,status)VALUES ('$class_id','$subject_id','$chapter_id','$article_id','$question','$question_type','$option_type','$optionA','$optionB','$optionC','$optionD','$correct_option','$reason','$question_image','$question_mime','$optionA_image','$optionA_mime','$optionB_image','$optionB_mime','$optionC_image','$optionC_mime','$optionD_image','$optionD_mime',1)";
	}
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Question Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Student Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}	
}else{
}
 ?>