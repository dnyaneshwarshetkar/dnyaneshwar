<?php
include('../connect.php');
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if($_GET['table']=='student'){
$first_name	=	$decoded['first_name'];
$middle_name =	$decoded['middle_name'];
$last_name	=	$decoded['last_name'];
$mother_name	=	$decoded['mother_name'];
$phone	=	$decoded['phone'];
$dob	=	$decoded['dob'];
$dob_words	=	$decoded['dob_words'];
$birth_place	=	$decoded['birth_place'];
$religion	=	$decoded['religion'];
$caste	=	$decoded['caste'];
$sub_caste	=	$decoded['sub_caste'];
$category	=	$decoded['category'];
$roll_no	=	$decoded['roll_no'];
$class_id	=	$decoded['class_id'];
$mother_tongue	=	$decoded['mother_tongue'];
$address	=	$decoded['address'];
$handicap_status	= $decoded['handicap_status'];
$handicap_info = $decoded['handicap_info'];
$adhar= $decoded['adhar'];
$serial_no = $decoded['serial_no'];
$udsie_no = $decoded['udsie_no'];
$admission_no = $decoded['admission_no'];
$gender = $decoded['gender'];
$password = $decoded['password'];
$status = $decoded['status'];
if(isset($_GET['stud_id'])){
	$stud_id = $_GET['stud_id'];
	$sql = "update student set first_name='$first_name',middle_name='$middle_name',last_name='$last_name',mother_name='$mother_name',phone='$phone',dob='$dob',dob_words='$dob_words',gender='$gender',birth_place='$birth_place',religion='$religion',caste='$caste',sub_caste='$sub_caste',category='$category',roll_no='$roll_no',class_id='$class_id',mother_tongue='$mother_tongue',address='$address',handicap_status='$handicap_status',handicap_info='$handicap_info',udsie_no='$udsie_no',adhar='$adhar',serial_no='$serial_no',admission_no='$admission_no',password='$password',status='$status' where stud_id=$stud_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Student Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Student Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  student(first_name,middle_name,last_name,mother_name,phone,dob_words,dob,gender,birth_place,religion,caste,sub_caste,category,roll_no,class_id,mother_tongue,address,handicap_status,handicap_info,udsie_no,adhar,serial_no,admission_no,password,status)VALUES ('$first_name','$middle_name','$last_name','$mother_name','$phone','$dob','$dob_words','$gender','$birth_place','$religion','$caste','$sub_caste','$category','$roll_no','$class_id','$mother_tongue','$address','$handicap_status','$handicap_info','$udsie_no','$adhar','$serial_no','$admission_no','$password','$status')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Student Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Student Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}	
}else{
}
 ?>