<?php
include('../connect.php');
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
if(isset($decoded['table'])){
	$table = $decoded['table'];
}else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Name of Table is Wrong".mysqli_error($con);
		echo json_encode($response);
}
if(isset($decoded['class_id'])){
	$column_id ='class_id';
	$id = $decoded['class_id'];
}
if(isset($decoded['stud_id'])){
	$column_id ='stud_id';
	$id = $decoded['stud_id'];
}
if(isset($decoded['teach_id'])){
	$column_id ='teach_id';
	$id = $decoded['teach_id'];
}
if(isset($decoded['question_id'])){
	$column_id ='question_id';
	$id = $decoded['question_id'];
}
$status = $decoded['status'];
$sql = "update $table set status = $status where $column_id=$id";
if($con->query($sql)){
	$response = array();
	$response['status'] ="SUCCESS";
	$response['message'] ="The Status is changed".mysqli_error($con);
	echo json_encode($response);
}