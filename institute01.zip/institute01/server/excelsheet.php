<?php
require_once "../vendor/autoload.php";
 
$fileName = "../excelsheet/abc.xls";
ini_set('memory_limit', '-1');
/** automatically detect the correct reader to load for this file type */
$excelReader = PHPExcel_IOFactory::createReaderForFile($fileName); 
 
//the default behavior is to load all sheets
$excelReader->setLoadAllSheets();

//$excelObj = $excelReader->load($fileName);

//$data = $excelObj->getActiveSheet()->toArray(null, true,true,true);
//show the final array
//print_r($data);
class ChunkReadFilter implements PHPExcel_Reader_IReadFilter
{
private $_startRow = 0;
private $_endRow = 0;
 
/** Set the list of rows that we want to read */
public function setRows($startRow, $chunkSize) {
$this->_startRow = $startRow;
$this->_endRow = $startRow + $chunkSize;
}
 
public function readCell($column, $row, $worksheetName = '') {
// Only read the heading row, and the configured rows
if (($row == 1) || ($row >= $this->_startRow && $row < $this->_endRow)) {
return true;
}
return false;
}
}
 
/** Define how many rows we want to read for each "chunk" **/
$chunkSize = 2048;
/** Create a new Instance of our Read Filter **/
$chunkFilter = new chunkReadFilter();
 
/** Tell the Reader that we want to use the Read Filter **/
$excelReader->setReadFilter($chunkFilter);
 
/** Loop to read our worksheet in "chunk size" blocks **/
for ($startRow = 2; $startRow <= 65536; $startRow += $chunkSize) {
/** Tell the Read Filter which rows we want this iteration **/
$chunkFilter->setRows($startRow,$chunkSize);
/** Load only the rows that match our filter **/
$excelObj = $excelReader->load($FileName);
$data = $excelObj->getActiveSheet()->toArray(null, true,true,true);
print_r($data);
}

?>