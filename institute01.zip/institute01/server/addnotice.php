<?php
include('../connect.php');
session_start();
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
if($_GET['table']=='notice'){
$notice = trim($decoded["notice"]); 
$receiver = trim($decoded["receiver"]);
$date = date('d-m-Y');
if(isset($_SESSION['teacher'])){
	$sender_id = $_SESSION['teacher']['teach_id'];
}
$status = 1;
if(isset($_GET['notice_id'])){
	$notice_id = $_GET['notice_id'];
	$sql = "update notice set notice='$notice',receiver='$receiver',date='$date',sender_id='$sender_id',status='$status' where notice_id=$notice_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Notice Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Notice Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  notice(notice,receiver,date,sender_id,status)values('$notice','$receiver','$date','$sender_id','$status')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Notice Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Notice Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}else{
	
}
 ?>