<?php
include('../connect.php');
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
if($_GET['table']=='timetable'){
$time = trim($decoded["time"]); 
$class_id = trim($decoded["class_id"]); 
$subject_id = trim($decoded["subject_id"]);
$teach_id = trim($decoded["teach_id"]);
if(isset($_GET['time_id'])){
	$time_id = $_GET['time_id'];
	$sql = "update timetable set time='$time',class_id='$class_id',subject_id='$subject_id',teach_id='$teach_id' where time_id=$time_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Time Table Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Time Table Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  timetable(time,class_id,subject_id,teach_id)values('$time','$class_id','$subject_id','$teach_id')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Time Table Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Time Table Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}else{
	
}
 ?>