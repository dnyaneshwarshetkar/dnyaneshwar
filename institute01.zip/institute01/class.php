<?php
  include('header.php');
  include('connect.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a> 
        </li>
        <li class="breadcrumb-item active">Classes</li>
      </ol>
		<?php if(isset($_GET['class_id'])){ ?>
      <form class="form-inline"name="addclassForm" onsubmit="return submitData(event,<?php echo $_GET['class_id']?>)" id="addclassForm">
	  <?php }else{ ?>
	  <form class="form-inline" name="addclassForm" onsubmit="return submitData(event)" id="addclassForm">
	  <?php } ?>
		  <div class="form-group">
			<label for="class_name">Class Name</label>
			<input type="text" class="form-control mx-sm-3"id="class_name" name="class_name" placeholder="Enter Class Name" required>
		  </div>
		  <button type="submit" name="submit" value="submit" class="btn btn-success">Submit</button>
		</form>
		<div class="table-responsive mt-2">
		  <table class="table table-bordered" id="classTable" width="100%" cellspacing="0">
			<thead>
			  <tr>
				<th>Sr.No</th>
				<th>Class</th>
				<th>Status</th>
				<th>Manage</th>
			  </tr>
			</thead>
			<tbody>
			</tbody>
		  </table>
		</div>
    </div>
</div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  <script src="js/class.js"></script>
</body>

</html>
