<?php
  include('header.php');
  // 		 session_start();
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('studentsidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Blank Page</li>
      </ol>
      <div class="row">
      <div class="col-md-3">
            <!-- Example Social Card-->
            <div class="card">
              <a href="#">
                <img class="card-img-top img-fluid w-100" src="https://unsplash.it/700/450?image=281" alt="">
              </a>
               <hr class="my-0">
              
            </div>
      <br>
    </div>  
    <div class="col-md-3">
            <!-- Example Social Card-->
            <div class="card">
              <a href="#">
                <img class="card-img-top img-fluid w-100" src="https://unsplash.it/700/450?image=281" alt="">
              </a>
               <hr class="my-0">
              
            </div>
      <br>
    </div>  
    <div class="col-md-3">
            <!-- Example Social Card-->
            <div class="card">
              <a href="#">
                <img class="card-img-top img-fluid w-100" src="https://unsplash.it/700/450?image=281" alt="">
              </a>
               <hr class="my-0">
              
            </div>
      <br>
    </div>  
    <div class="col-md-3">
            <!-- Example Social Card-->
            <div class="card">
              <a href="#">
                <img class="card-img-top img-fluid w-100" src="https://unsplash.it/700/450?image=281" alt="">
              </a>
               <hr class="my-0">
              
            </div>
      <br>
    </div>  

        
      </div>
      
   
       </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
