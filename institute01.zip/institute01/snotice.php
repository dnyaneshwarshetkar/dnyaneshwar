<?php
  include('header.php');
 // include('session_student.php');
   
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('studentsidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Notice</li>
      </ol>
            <div class="table-responsive">
              <table class="table table-bordered" id="noticeTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Sr. No.</th>
                    <th>Sender Name</th>
                    <th>Notice</th>
					<th>Date</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
    </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/snotice.js"></script>
</body>

</html>
