<?php
  include('header.php');
  include('connect.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Chapters</li>
      </ol>
      <div class="row">
      <div class="col-md-12">
         <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-table"></i>Articles</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>Class</th>
                    <th>Subject</th>
                    <th>Chapter</th>
					<th>Article</th>
					<th>Edit</th>
                  </tr>
                </thead>
                <tbody>
					<?php $que = "SELECT 
	`A`.`article_id`  AS `article_id`,
  `C`.`Class_Name`  AS `Class`,
  `S`.`Subject_Name`  AS `Subject`,
  `P`.`Chapter_Name`  AS `Chapter`,
  `A`.`Article_Name`  AS `Article`
FROM (`class` As `C`
   INNER JOIN `subject` As `S` ON(`S`.`Class_id` = `C`.`Class_id`) INNER JOIN `chapters` As `P`
     ON (`P`.`subject_id` = `S`.`subject_id`)INNER JOIN `articles` As `A` ON (`A`.`chapter_id` = `P`.`chapter_id`))";
	 $res = $con->query($que);
	 echo mysqli_error($con);
	 while ($row = $res->fetch_assoc()) {
	 ?>
					<tr>
						<td><?php echo $row['Class'] ?></td>
						<td><?php echo $row['Subject'] ?></td>
						<td><?php echo $row['Chapter'] ?></td>
						<td><?php echo $row['Article'] ?></td>
						<td><a href="edit_stud.php?article_id=<?php echo $row['article_id'] ?>">Edit</a></td>
					</tr>
	 <?php }?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="card-footer small text-muted"></div></div>
          </div>
      
    </div>
    
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
