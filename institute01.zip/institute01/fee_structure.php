<?php
  include('header.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
		<?php if(isset($_GET['fee_id'])){?>
        <li class="breadcrumb-item active">Edit Fee Structure</li>
		<?php }else{ ?>
		<li class="breadcrumb-item active">Add Fee Structure</li>
		<?php } ?>
      </ol>
	  <?php if(isset($_GET['fee_id'])){ ?>
      <form name="addFeeStructureForm" onsubmit="return submitData(event,<?php echo $_GET['fee_id']?>)" id="addFeeStructureForm">
	  <?php }else{ ?>
	  <form name="addFeeStructureForm" onsubmit="return submitData(event)" id="addFeeStructureForm">
	  <?php } ?>
		<div class="form-row">
		  <div class="form-group col-md-4">
				<label for="class_id">Class</label>
				<select class="form-control custom-select" name="class_id" id="class_id">
					<option value="">Select Class</option>
				</select>
			</div>
		   <div class="form-group col-md-4">
				<label for="monthly_fees">Monthly Fees</label>
				<input class="form-control" id="monthly_fees" type="number" name="monthly_fees" placeholder="Enter Monthly Fees">
		   </div>
		   <div class="form-group col-md-4">
				<label for="exam_fees">Exam Fees</label>
				<input class="form-control" id="exam_fees" type="number" name="exam_fees" placeholder="Enter Exam Fees">
		   </div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="term1">Term 1</label>
				<input class="form-control" id="term1" type="number" name="term1" placeholder="Enter Term 1 Fees">
			</div>
			<div class="form-group col-md-4">
				<label for="term2">Term 2</label>
				<input class="form-control" id="term1" type="number" name="term2" placeholder="Enter Term 2 Fees">
			</div>
        </div>
        <input type="submit" name="submit" class="btn btn-primary"/>
		</form>
	</div>
  </div>
<?php
  include('footer.php');
?>
<script src="js/fee_structure.js"></script>
</body>
</html>
