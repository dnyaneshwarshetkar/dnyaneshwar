$(document).ready(
function() {
	var url ="server/get_data.php?stime_table=true&data=true";
    var timetable = $('#timeTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [{data:"time_id"}, {
			data : "time"
		},  {
			data : "subject_name"
		}, {
			data : "first_name",render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		}],
        "order": [[ 1, 'asc' ]]
	});
	timetable.on( 'order.dt search.dt', function () {
        timetable.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
}
);