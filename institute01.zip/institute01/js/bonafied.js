var getClass = function(){
	var url = "server/get_data.php?class=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(classList){
				classList = JSON.parse(classList);
			    var mySelect = $('#class_id');
				$.each(classList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['class_id']).html(value['class_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getClass();
var submitData = function(event,stud_id){
	event.preventDefault();
	if(!!stud_id){
		var url = "server/addstudent.php?table=student&stud_id="+stud_id;
	}else{
		var url = "server/addstudent.php?table=student";
	}
	var x = $('#addStudentForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(function(){
	var params = getAllUrlParams(window.location.href);
	if(!!params['stud_id']){
		editStudent(params['stud_id']);
	}
	var table = $('#bonafiedTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?student=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "stud_id"
		}, {
			data : "first_name",
		}, {
			data : "class_name"
		}, {
			data : "phone"
		},{
			data : "stud_id",'render': function (data, type, full, meta){
			   return '<button class="btn btn-sm btn-success">Print Bonafied</button>';
		   }
		}]
	});
	$('#bonafiedTable tbody').on( 'click', 'button', function () {
        var data = table.row( $(this).parents('tr') ).data();
        $('.bonafied').loadTemplate("#bonafied",data);
		w=window.open();
		w.document.write($('.bonafied').html());
		w.print();
		w.close();
    } );
	
});
