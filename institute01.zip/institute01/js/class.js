var submitData = function(event,class_id){
	event.preventDefault();
	if(!!class_id){
		var url = "server/addclass.php?table=class&class_id="+class_id;
	}else{
		var url = "server/addclass.php?table=class";
	}
	var x = $('#addclassForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	console.log(formData);
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  window.location.href="class.php";
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(
function() {
	var params = getAllUrlParams(window.location.href);
	if(!!params['class_id']){
		editClass(params['class_id']);
	}
	var url ="server/get_data.php?class=true&data=true";
    var timetable = $('#classTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [{data:"class_id",width:"10%"}, {
			data : "class_name",width:"20%"
		},{
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},
		{
			data : "class_id"
		}],
		'columnDefs': [{
		   'targets': 3,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0)" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   
			   return '<button value="' + $('<div/>').text(data).html() + '" onclick="updateClass(this.value)" class="btn btn-success btn-sm"  title="Edit Class">Edit</button>'+status;
		   }
		}],
        "order": [[ 1, 'asc' ]]
	});
	timetable.on( 'order.dt search.dt', function () {
        timetable.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
}
);
var updateClass = function(class_id){
	window.location.href= "class.php?class_id="+class_id;
}
var editClass = function(class_id){
	$.get("server/get_data.php?class=true&class_id="+class_id, function(data, status){
		data =JSON.parse(data);
		$.each(data, function(key, value){
		if(key=="status"||key=="length"){
		}else{
				$('form [name=' + key + ']').val(value);
			}
		});
	});
}
var changeStatus = function(class_id,status){
	var data = JSON.stringify({table:"class",class_id : class_id,status:status});
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}