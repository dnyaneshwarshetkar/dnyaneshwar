var getReceiver = function(){
	var url = "server/get_data.php?class=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(classList){
				classList = JSON.parse(classList);
			    var mySelect = $('#class');
				$.each(classList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['class_id']).html(value['class_name']));
				});
				mySelect.append(
						$('<option></option>').val("teacher").html("teacher"));
				mySelect.append(
						$('<option></option>').val("allclass").html("allclass"));
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getReceiver();
var submitData = function(event,notice_id){
	event.preventDefault();
	console.log("Hello");
	if(!!notice_id){
		var url = "server/addnotice.php?table=notice&notice_id="+notice_id;
	}else{
		var url = "server/addnotice.php?table=notice";
	}
	var x = $('#addnoticeForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData);
	console.log(formData);
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  window.location.href="notice.php";
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(
function() {
	var params = getAllUrlParams(window.location.href);
	if(!!params['notice_id']){
		editNotice(params['notice_id']);
	}
	var url ="server/get_data.php?notice=true&data=true";
    var notice = $('#noticeTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ 
		{
			data : "notice_id"
		}, {
			data : "receiver",
		}, {
			data : "notice",
		},{
			data : "first_name",
			render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		}, 
		{
			data : "date"
		},{
			data : "notice_id"
		}],
		'columnDefs': [{
		   'targets': 5,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   return '<button value="' + $('<div/>').text(data).html() + '" onclick="updateNotice(this.value)" class="btn btn-success btn-sm"  title="Edit Notice">Edit</button>';
		   }
		}],
        "order": [[ 1, 'asc' ]]
	});
	notice.on( 'order.dt search.dt', function () {
        notice.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
}
);
var updateNotice = function(notice_id){
	window.location.href= "notice.php?notice_id="+notice_id;
}
var editNotice = function(notice_id){
	$.get("server/get_data.php?notice=true&notice_id="+notice_id, function(data, status){
		data.length = 0;
		$.each(JSON.parse(data), function(key, value){
			if(key=="status"||key=="length"){
			}else{
				$('form [name=' + key + ']').val(value);
				}
			});
	});
}