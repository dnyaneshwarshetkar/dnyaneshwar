var getClass = function(){
	var url = "server/get_data.php?class=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(classList){
				classList = JSON.parse(classList);
			    var mySelect = $('#class_id');
				$.each(classList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['class_id']).html(value['class_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getClass();
var submitData = function(event,teach_id){
	event.preventDefault();
	if(!!teach_id){
		var url = "server/addteacher.php?table=teacher&teach_id="+teach_id;
	}else{
		var url = "server/addteacher.php?table=teacher";
	}
	var x = $('#addTeacherForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(function(){
	var params = getAllUrlParams(window.location.href);
	if(!!params['teach_id']){
		editTeacher(params['teach_id']);
	}
	$('#teacherTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?teacher=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "teach_id"
		}, {
			data : "first_name",render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		}, {
			data : "class_name"
		}, {
			data : "mobile"
		},{
			data : "password"
		},{
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "teach_id"
		}],
		'columnDefs': [{
		   'targets': 6,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0)" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<button value="' + $('<div/>').text(data).html() + '" onclick="editData(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button>'+status;
		   }
		}]
	});
	
});
var editData = function(teach_id){
	window.location.href = "acc_add_tea.php?teach_id="+teach_id;
}
var editTeacher = function(teach_id){
	$.get("server/get_data.php?teacher=true&teach_id="+teach_id, function(data, status){
		data.length = 25;
		$.each(JSON.parse(data), function(key, value){
				$('form [name=' + key + ']').val(value);
			});
	});
}
var changeStatus = function(teach_id,status){
	var data = JSON.stringify({table:"teacher",teach_id : teach_id,status:status});
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}