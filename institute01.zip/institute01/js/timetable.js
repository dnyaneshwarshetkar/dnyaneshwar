var getClass = function(){
	var url = "server/get_data.php?class=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(classList){
				classList = JSON.parse(classList);
			    var mySelect = $('#class');
				$.each(classList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['class_id']).html(value['class_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getClass();
var getSubject = function(class_id){
var url  = "server/get_data.php?subject=true&class_id="+class_id;
	$.ajax({
	  type: "GET",
	  url: url,
	  data: null,
	  success: function(subjectList){
			  subjectList = JSON.parse(subjectList);
			  $('#subject').find('option').not(':first').remove()
			  var mySelect = $('#subject');
				$.each(subjectList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['subject_id']).html(value['subject_name']));
				});
		  },
	  datatype : "application/json",
	  contentType: "application/json"
	});
	return true;
};
var getTeacher = function(){
	var url = "server/get_data.php?teacher=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(classList){
				classList = JSON.parse(classList);
			    var mySelect = $('#teacher');
				$.each(classList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['teach_id']).html(value['first_name']+" "+value['middle_name']+" "+value['last_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getTeacher();
var submitData = function(event,time_id){
	event.preventDefault();
	if(!!time_id){
		var url = "server/addtimetable.php?table=timetable&time_id="+time_id;
	}else{
		var url = "server/addtimetable.php?table=timetable";
	}
	var x = $('#addtimetableForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	console.log(formData);
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  window.location.href="timetable.php";
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
var getSubject = function(class_id){
var url  = "server/get_data.php?subject=true&class_id="+class_id;
	$.ajax({
	  type: "GET",
	  url: url,
	  data: null,
	  success: function(subjectList){
			  subjectList = JSON.parse(subjectList);
			  $('#subject').find('option').not(':first').remove()
			  var mySelect = $('#subject');
				$.each(subjectList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['subject_id']).html(value['subject_name']));
				});
		  },
	  datatype : "application/json",
	  contentType: "application/json"
	});
};

$(document).ready(
function() {
	var params = getAllUrlParams(window.location.href);
	if(!!params['time_id']){
		editTime(params['time_id']);
	}
	var url ="server/get_data.php?time_table=true&data=true";
    var timetable = $('#timeTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [{data:"time_id"}, {
			data : "time"
		}, {
			data : "class_name",
		}, {
			data : "subject_name"
		}, {
			data : "first_name",render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		},
		{
			data : "time_id"
		}],
		'columnDefs': [{
		   'targets': 5,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   return '<button value="' + $('<div/>').text(data).html() + '" onclick="updateTime(this.value)" class="btn btn-success btn-sm"  title="Edit Time Slot">Edit</button>';
		   }
		}],
        "order": [[ 1, 'asc' ]]
	});
	timetable.on( 'order.dt search.dt', function () {
        timetable.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
}
);
var updateTime = function(time_id){
	console.log(time_id);
	window.location.href= "timetable.php?time_id="+time_id;
}
var editTime = function(time_id){
	$.get("server/get_data.php?time_table=true&time_id="+time_id, function(data, status){
		data =JSON.parse(data);
		getSubject(data['class_id']);
		$.when(getSubject(data['class_id'])).then(function(x){
			$.each(data, function(key, value){
			if(key=="status"||key=="length"){
			}else{
					$('form [name=' + key + ']').val(value);
				}
			});
		});
	});
}