$(document).ready(
function() {
	var url ="server/get_data.php?snotice=true&data=true";
    var notice = $('#noticeTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ 
		{
			data : "notice_id"},
		{
			data : "notice"
		},{
			data : "first_name",
			render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		}, 
		{
			data : "date",type: 'date-uk'
		}],
        "order": [[ 3, 'asc' ]]
	});
	notice.on( 'order.dt search.dt', function () {
        notice.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
}
);