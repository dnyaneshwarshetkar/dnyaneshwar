var startTest = function(exam_id){
	window.location.href = "stud_exam_instructions.php?exam_id="+exam_id;
}
$(document).ready(
function() {
	var url ="server/get_data.php?stud_exam=true";
    $('#examTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "exam_id"
		}, {
			data : "marks",
		}, {
			data : "passing_marks"
		}, {
			data : "no_of_questions"
		},
		{
			data : "exam_duration"
		},/*{
			data : "exam_type"
		},{
			data : "negative_type"
		},*/
		{
			data : "exam_date"
		},{
			data : "exam_id"
		}],
		'columnDefs': [{
		   'targets': 6,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   return '<button value="' + $('<div/>').text(data).html() + '" onclick="startTest(this.value)" class="btn btn-success btn-sm"  title="Start Test">Start Test</button><button value="' + $('<div/>').text(data).html() + '" onclick="openReport(this.value)"  class="btn btn-success btn-sm" title="View Report">Report</button>';
		   }
		}]
	});
}
);