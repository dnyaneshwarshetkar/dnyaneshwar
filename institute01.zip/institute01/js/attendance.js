var getClass = function(){
	var url = "server/get_data.php?class=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(classList){
				classList = JSON.parse(classList);
			    var mySelect = $('#class');
				$.each(classList, function(key,value) {
					if(key==0){
						mySelect.append(
						$('<option selected></option>').val(value['class_id']).html(value['class_name']));
					}else{
					mySelect.append(
						$('<option></option>').val(value['class_id']).html(value['class_name']));
					}
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getClass();
var setDate = function(){
	var d = new Date();
	var dd = d.getDate();
	var mm = d.getMonth()+1;
	mm = "0"+mm;
	var yyyy = d.getFullYear();
	today = yyyy+"-"+mm+"-"+dd;
	$("#date").val(today);
};
setDate();

$(document).ready(
function() {
	url ="server/get_data.php?attendance=true&data=true&class_id=1";
    attendance = $('#attendanceTable').DataTable({
		processing : true,
		searching : false,
		paging : false,
		destroy: true,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ 
		{
			data : "stud_id",width:"10%"
		},{
			data : "first_name",
			render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		},
		{
			data : "stud_id"
		}],
		'columnDefs': [{
		   'targets': 2,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   return '<select name="attendance" class="form-control" ><option value="">Select Attendance</option><option value="p" selected>Present</option><option value="a">Absent</option></select>';
		   }
		}],
        "order": [[ 1, 'asc' ]]
	});
	attendance.on( 'order.dt search.dt', function () {
        attendance.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
}
);
var getStudents=function(class_id){
		url = "server/get_data.php?attendance=true&data=true&class_id="+class_id;
		attendance.ajax.reload();
	}