var getClass = function(){
	var url = "server/get_data.php?class=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(classList){
				classList = JSON.parse(classList);
			    var mySelect = $('#class_id');
				$.each(classList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['class_id']).html(value['class_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getClass();
var submitData = function(event,fee_id){
	event.preventDefault();
	if(!!fee_id){
		var url = "server/addfeestructure.php?table=fee&fee_id="+fee_id;
	}else{
		var url = "server/addfeestructure.php?table=fee";
	}
	var x = $('#addFeeStructureForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(function(){
	var params = getAllUrlParams(window.location.href);
	if(!!params['fee_id']){
		editFee(params['fee_id']);
	}
	$('#feeTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?fee=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "fee_id"
		}, {
			data : "class_name",
		}, {
			data : "monthly_fees"
		}, {
			data : "exam_fees"
		},{
			data : "term1"
		},{
			data : "term2"
		},{
			data : "fee_id"
		}],
		'columnDefs': [{
		   'targets': 6,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   return '<button value="' + $('<div/>').text(data).html() + '" onclick="editData(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button>';
		   }
		}]
	});
	
});
var editData = function(fee_id){
	window.location.href = "fee_structure.php?fee_id="+fee_id;
}
var editFee = function(fee_id){
	$.get("server/get_data.php?fee=true&fee_id="+fee_id, function(data, status){
		data.length = 25;
		$.each(JSON.parse(data), function(key, value){
			if(key=="status"||key=="length"){
			}else{
				$('form [name=' + key + ']').val(value);
				}
			});
	});
}