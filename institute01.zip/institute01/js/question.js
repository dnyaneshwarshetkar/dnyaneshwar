$(document).ready(function(){
	$('#questionTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?questions=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "question_id"
		}, {
			data : "class_name"
		}, {
			data : "subject_name"
		}, {
			data : "chapter_name"
		},{
			data : "article_name"
		},{
			data : "question"
		},{
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "question_id"
		}],
		'columnDefs': [{
		   'targets': 7,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status=='1'){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0)" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<button value="' + $('<div/>').text(data).html() + '" onclick="editData(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button>'+status;
		   }
		}]
	});
	
});
var editData = function(question_id){
	window.location.href = "acc_add_questions.php?question_id="+question_id;
}
var changeStatus = function(question_id,status){
	var data = JSON.stringify({table:"questions",question_id : question_id,status:status});
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}