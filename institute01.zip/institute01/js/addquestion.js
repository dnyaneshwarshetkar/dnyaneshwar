
var getClass = function(){
	var url = "server/get_data.php?class=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(classList){
				classList = JSON.parse(classList);
			    var mySelect = $('#class');
				$.each(classList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['class_id']).html(value['class_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getClass();
var getSubject = function(class_id){
var url  = "server/get_data.php?subject=true&class_id="+class_id;
	$.ajax({
	  type: "GET",
	  url: url,
	  data: null,
	  success: function(subjectList){
			  subjectList = JSON.parse(subjectList);
			  $('#subject').find('option').not(':first').remove()
			  var mySelect = $('#subject');
				$.each(subjectList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['subject_id']).html(value['subject_name']));
				});
		  },
	  datatype : "application/json",
	  contentType: "application/json"
	});
};
var getChapter = function(subject_id){
	var url  = "server/get_data.php?chapter=true&subject_id="+subject_id;
	$.ajax({
	  type: "GET",
	  url: url,
	  data: null,
	  success: function(chapterList){
			  chapterList = JSON.parse(chapterList);
			  $('#chapter').find('option').not(':first').remove()
			  var mySelect = $('#chapter');
				$.each(chapterList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['chapter_id']).html(value['chapter_name']));
				});
		  },
	  datatype : "application/json",
	  contentType: "application/json"
	});

}
var getArticle = function(chapter_id){
	var url = "server/get_data.php?article=true&chapter_id="+chapter_id;
	$.ajax({
	  type: "GET",
	  url: url,
	  data: null,
	  success: function(articleList){
			  articleList = JSON.parse(articleList);
			  $('#article').find('option').not(':first').remove()
			  var mySelect = $('#article');
				$.each(articleList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['article_id']).html(value['article_name']));
				});
		  },
	  datatype : "application/json",
	  contentType: "application/json"
	});
};

var submitData = function(event,question_id){
	event.preventDefault();
	if(!!question_id){
		var url = "server/addquestion.php?table=questions&question_id="+question_id;
	}else{
		var url = "server/addquestion.php?table=questions";
	}

	var qform =  new FormData(document.getElementById('addQuestion'));
	$.ajax({
		  type: "POST",
		  url: url,
		  data: qform,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  location.reload();
		  },
		  processData: false,
		  contentType: false,
		  datatype : "application/json"
		});
}
function ConvertFormToJSON(form){
    var array = $(form).serializeArray();
    var json = {};
    
    $.each(array, function() {
        json[this.name] = this.value || '';
    });
    
    return JSON.stringify(json);
}
$(document).ready(function(){
	var params = getAllUrlParams(window.location.href);
	if(!!params['question_id']){
		editQuestion(params['question_id']);
	}else{
		$('form [name=question_type]').val('text');
		$('form [name=option_type]').val('text');
		questionType("text");
		optionType("text");
	}
});
var editQuestion = function(question_id){
	$.get("server/get_data.php?questions=true&question_id="+question_id, function(data, status){
		data =JSON.parse(data);
		$.when(getSubject(data['class_id'])).then($.when(getChapter(data['subject_id'])).then($.when(getArticle(data['chapter_id'])).then(
			setTimeout(function(x){
				$.each(data, function(key, value){
				if(key=="status"||key=="length"){
				}else{
						$('form [name=' + key + ']').val(value);
					}
				if(key=='question_type'){
					questionType(value);
					if(value=='image'||value=='textimage'){
						$("#qi").attr("src","data:image/jpeg;base64,"+data['qi']);
					}
				}
				if(key=='option_type'){
					optionType(value);
					if(value=='image'||value=='textimage'){
						$("#oai").attr("src","data:image/jpeg;base64,"+data['oai']);
						$("#obi").attr("src","data:image/jpeg;base64,"+data['obi']);
						$("#oci").attr("src","data:image/jpeg;base64,"+data['oci']);
						$("#odi").attr("src","data:image/jpeg;base64,"+data['odi']);
					}
				}
				
				});
				
			},100)
		)));	
	});
}
var questionType = function(question_type){
	if(question_type=='text'){
		$('form [name=question]').attr("disabled",false);
		$('form [name=question_image]').attr("disabled",true);
	}
	if(question_type=='image'){
		$('form [name=question]').attr("disabled",true);
		$('form [name=question_image]').attr("disabled",false);
	}
	if(question_type=='textimage'){
		$('form [name=question]').attr("disabled",false);
		$('form [name=question_image]').attr("disabled",false);
	}
}
var optionType = function(option_type){
	if(option_type=='text'){
		$('form [name=optionA]').attr("disabled",false);
		$('form [name=optionA_image]').attr("disabled",true);
		$('form [name=optionB]').attr("disabled",false);
		$('form [name=optionB_image]').attr("disabled",true);
		$('form [name=optionC]').attr("disabled",false);
		$('form [name=optionC_image]').attr("disabled",true);
		$('form [name=optionD]').attr("disabled",false);
		$('form [name=optionD_image]').attr("disabled",true);
		
	}
	if(option_type=='image'){
		$('form [name=optionA]').attr("disabled",true);
		$('form [name=optionA_image]').attr("disabled",false);
		$('form [name=optionB]').attr("disabled",true);
		$('form [name=optionB_image]').attr("disabled",false);
		$('form [name=optionC]').attr("disabled",true);
		$('form [name=optionC_image]').attr("disabled",false);
		$('form [name=optionD]').attr("disabled",true);
		$('form [name=optionD_image]').attr("disabled",false);
	}
	if(option_type=='textimage'){
		$('form [name=optionA]').attr("disabled",false);
		$('form [name=optionA_image]').attr("disabled",false);
		$('form [name=optionB]').attr("disabled",false);
		$('form [name=optionB_image]').attr("disabled",false);
		$('form [name=optionC]').attr("disabled",false);
		$('form [name=optionC_image]').attr("disabled",false);
		$('form [name=optionD]').attr("disabled",false);
		$('form [name=optionD_image]').attr("disabled",false);
	}
}