$(document).ready(
function() {
	var url ="server/get_data.php?shomework=true&data=true";
    var notice = $('#homeworkTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ 
		{
			data : "home_id"
		},{
			data : "first_name",
			render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		}, {
			data : "subject_name",
		},
		{
			data : "homework"
		},{
			data : "date"
		}],
        "order": [[ 1, 'asc' ]]
	});
	notice.on( 'order.dt search.dt', function () {
        notice.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
}
);