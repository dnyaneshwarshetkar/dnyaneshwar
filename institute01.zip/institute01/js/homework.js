var getClass = function(){
	var url = "server/get_data.php?class=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(classList){
				classList = JSON.parse(classList);
			    var mySelect = $('#class');
				$.each(classList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['class_id']).html(value['class_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getClass();
var getSubject = function(class_id){
var url  = "server/get_data.php?subject=true&class_id="+class_id;
	$.ajax({
	  type: "GET",
	  url: url,
	  data: null,
	  success: function(subjectList){
			  subjectList = JSON.parse(subjectList);
			  $('#subject').find('option').not(':first').remove()
			  var mySelect = $('#subject');
				$.each(subjectList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['subject_id']).html(value['subject_name']));
				});
		  },
	  datatype : "application/json",
	  contentType: "application/json"
	});
	return true;
};
var submitData = function(event,home_id){
	event.preventDefault();
	if(!!home_id){
		var url = "server/addhomework.php?table=homework&home_id="+home_id;
	}else{
		var url = "server/addhomework.php?table=homework";
	}
	var x = $('#addhomeworkForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData);
	console.log(formData);
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  window.location.href="homework.php";
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(
function() {
	var params = getAllUrlParams(window.location.href);
	if(!!params['home_id']){
		editHomework(params['home_id']);
	}
	var url ="server/get_data.php?homework=true&data=true";
    var notice = $('#homeworkTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ 
		{
			data : "home_id"
		},{
			data : "first_name",
			render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		},{
			data : "class_name",
		}, {
			data : "subject_name",
		},
		{
			data : "homework"
		},{
			data : "date"
		},{
			data : "home_id"
		}],
		'columnDefs': [{
		   'targets': 6,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   return '<button value="' + $('<div/>').text(data).html() + '" onclick="updateHomework(this.value)" class="btn btn-success btn-sm"  title="Edit Homework">Edit</button>';
		   }
		}],
        "order": [[ 1, 'asc' ]]
	});
	notice.on( 'order.dt search.dt', function () {
        notice.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
}
);
var updateHomework = function(home_id){
	window.location.href= "homework.php?home_id="+home_id;
}
var editHomework = function(home_id){
	$.get("server/get_data.php?homework=true&home_id="+home_id, function(data, status){
		data.length = 0;
		data =JSON.parse(data);
		getSubject(data['class_id']);
		$.when(getSubject(data['class_id'])).then(function(x){
			$.each(data, function(key, value){
			if(key=="status"||key=="length"){
			}else{
					$('form [name=' + key + ']').val(value);
				}
			});
		});
		
	});
}