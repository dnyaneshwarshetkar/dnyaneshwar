$(document).ready(
function() {
	var url ="server/get_data.php?exam=true&data=true";
    $('#examTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "exam_id"
		}, {
			data : "exam_name",
		},{
			data : "no_of_questions"
		}, {
			data : "marks"
		}, {
			data : "passing_marks"
		},
		{
			data : "exam_duration"
		},{
			data : "exam_type"
		},{
			data : "negative_type"
		},
		{
			data : "exam_date"
		},{
			data : "exam_id"
		}],
		'columnDefs': [{
		   'targets': 9,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   return '<button value="' + $('<div/>').text(data).html() + '" onclick="editExam(this.value)" class="btn btn-success btn-sm"  title="View Exam">Edit Exam</button><button value="' + $('<div/>').text(data).html() + '" onclick="viewExam(this.value)" class="btn btn-success btn-sm"  title="View Exam">View Exam</button><button value="' + $('<div/>').text(data).html() + '" onclick="viewReport(this.value)"  class="btn btn-success btn-sm" title="View Report">View Report</button>';
		   }
		}]
	});
}
);
var viewExam = function(exam_id){
	window.open("print_question_paper.php?exam_id="+exam_id,'_blank');
}