<?php
include('connect.php');

if($_GET['Stud_id']){
			$Sid=$_GET['Stud_id'];
			$sql="INSERT INTO attend(att_id,datea,Stud_id,teach_id,status) VALUES(NULL,NOW(),'1','1','Absent')";
			
			if($con->query($sql)){
				echo "<script>  alert('Absent student');</script>";
			}
			else{
				echo "<script>  alert('Error Occured');</script>";
			}
			 
			header('Location:tea_class.php');	
	}
	?>