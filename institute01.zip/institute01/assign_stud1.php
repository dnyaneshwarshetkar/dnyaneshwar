<?php
//		ABCDEF
  include('header.php');
  require "connect.php";
?>
<?php
	if(isset($_GET['stud_id']))
	{
		$stud_id=$_GET['stud_id'];
		$sql = "SELECT * FROM student WHERE stud_id='$stud_id'";
		$result = $con->query($sql);
		$data = array();
		if ($result->num_rows==1) 
		{
		while($row = $result->fetch_assoc()) 
			{
			$first_name=$row['first_name'];
			$middle_name=$row['middle_name'];
			$last_name=$row['last_name'];
			$class_id=$row['class_id'];
			}
		}
	}
		
	if(isset($_POST['submit']))
		{
		$jan=$_POST['jan'];
		$feb=$_POST['feb'];
		$mar=$_POST['mar'];
		$apr=$_POST['apr'];
		$may=$_POST['may'];
		$jun=$_POST['jun'];
		$jul=$_POST['jul'];
		$aug=$_POST['aug'];
		$sept=$_POST['sept'];
		$oct=$_POST['oct'];
		$nov=$_POST['nov'];
		$dec=$_POST['dec'];
		$term1=$_POST['term1'];
		$term2=$_POST['term2'];
		
		$disjan=$_POST['disj'];
		$disfeb=$_POST['disf'];
		$dismar=$_POST['disma'];
		$disapr=$_POST['disap'];
		$dismay=$_POST['dism'];
		$disjun=$_POST['disjun'];
		$disjul=$_POST['disju'];
		$disaug=$_POST['disau'];
		$dissept=$_POST['diss'];
		$disoct=$_POST['diso'];
		$disnov=$_POST['disnov'];
		$disdec=$_POST['disd'];
		$disterm1=$_POST['dist1'];
		$disterm2=$_POST['dist2'];
		
			$tot1=$jan-$disjan;
			$tot2=$feb-$disfeb;
			$tot3=$mar-$dismar;
			$tot4=$apr-$disapr;
			$tot5=$may-$dismay;
			$tot6=$jun-$disjun;
			$tot7=$jul-$disjul;
			$tot8=$aug-$disaug;
			$tot9=$sept-$dissept;
			$tot10=$oct-$disoct;
			$tot11=$nov-$disnov;
			$tot12=$dec-$disdec;
			$totterm1=$term1-$disterm1;
			$totterm2=$term2-$disterm2;
			$Out=$tot1+$tot2+$tot3+$tot4+$tot5+$tot6+$tot7+$tot8+$tot9+$tot10+$tot11+$tot12+$totterm1+$totterm2;
			$Tot_O=$Out;
			$date = date("d-m-yy");
			$sql="insert into account(stud_id,date,term1,term2,jan,feb,march,april,may,june,july,aug,sept,octo,nov,deca,outstanding,total_outstanding,class_id,status)values('$stud_id','$date','$term1','$term2','$tot1','$tot2','$tot3','$tot4','$tot5','$tot6','$tot7','$tot8','$tot9','$tot10','$tot11','$tot12','$Out','$Tot_O','$class_id',1)";
		if($con->query($sql)){
			echo "<script>alert('Added Succesfully');
			       </script>";
			}
		else{
                die('Could Not add data'.mysqli_error($con));

      }	
		}
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Discount</li>
      </ol>
      <div class="row">
		<div class="col-sm-12">
	    <h3> Assign Student</h3>
		</div>
      </div>
	  <form method="post" action="">
        <div class="col-4">
			<button type="submit" name="suba" value="Default" class="btn btn-raised g-bg-blush2">Set Default Fee</button>
		</div>
	  </form>
	  <?php
			$per=0;
			$exam=0;
			$t1=0;
			$t2=0;
			if(isset($_POST['suba']))
				{
				$sql1 = "SELECT * FROM fee WHERE class_id=$class_id";
				$result = $con->query($sql1);
				$fname = "";
				$lname = "";    
				$data = array();
				if ($result->num_rows==1) 
					{
					while($row = $result->fetch_assoc()) 
						{
						$per=$row['monthly_fees'];
						$exam=$row['exam_fees'];
						$t1=$row['term1'];
						$t2=$row['term2'];
						}
					}
				}
		
		?>
	  <div class="row">
	   <div class="col-md-4">
	     <center><button type="button" class="btn btn-warning">MONTH NAME</button></center>
	   </div>
	   <div class="col-md-4">
	     <center><button type="button" class="btn btn-warning">PER MONTH</button></center>
	   </div>
	   <div class="col-md-4">
	     <center><button type="button" class="btn btn-warning">DISCOUNT</button></center>
	   </div>
	  </div>
	  <hr>
	  <form method="POST" action="">	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>June</h4></center>
	  </div>
	  <div class="col-md-3">
	    <div class="form-group">
			<div class="form-line">
				<input type="text" class="form-control" name="jun" value="<?php echo $per;?>" placeholder="<?php echo $per;?>" required="">
			</div>
		</div>
	  </div>
	  <div class="col-md-3">
	    <div class="form-group">
			<div class="form-line">
				<input type="text" class="form-control" name="disjun" value="0" placeholder="discount" required="">
			</div>
		</div>
     </div>
   	</div>	
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>July</h4></center>
	  </div>
	  <div class="col-md-3">
	  <div class="form-group">
	  <div class="form-line">
	    <input type="text" class="form-control" name="jul" value="<?php echo $per;?>" placeholder="<?php echo $per;?>" required="">
		</div>
		</div>
	 </div>
	  <div class="col-md-3">
	  <div class="form-group">
			<div class="form-line">
      	<input type="text" class="form-control" name="disju" value="0" placeholder="discount" required="">
      </div>
	 </div>
	 </div>
   	</div>
	<div class="row clearfix">
      <div class="col-md-3">
	  <center><h4>Aug</h4></center>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
	     <input type="text" class="form-control" name="aug" value="<?php echo $per;?>" name="permonth" placeholder="<?php echo $per;?>" required="">
		</div>
       </div>		
	 </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
      	<input type="text" class="form-control" name="disau" value="0" placeholder="discount" required="">
      </div>
	 </div>
	 </div>

   	</div>
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>Sept</h4></center>
	  </div>
	  <div class="col-md-3">
	  <div class="form-group">
	    <div class="form-line"> 
	    <input type="text" class="form-control" name="sept" value="<?php echo $per;?>" name="permonth" placeholder="<?php echo $per;?>" required="">
	  </div>
	 </div>
	 </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
      	<input type="text" class="form-control" name="diss" value="0" placeholder="discount" required="">
     </div>
	 </div>
	 </div>
	 </div>
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>Oct</h4></center>
	  </div>
	  <div class="col-md-3">
	  <div class="form-group">
	    <div class="form-line"> 
	    <input type="text" class="form-control" name="oct"  value="<?php echo $per;?>" placeholder="<?php echo $per;?>" required="">
	  </div>
	 </div>
	 </div>
	  <div class="col-md-3">
	  <div class="form-group">
	    <div class="form-line"> 
      	<input type="text" class="form-control" name="diso" value="0" placeholder="discount" required="">
     </div>
	 </div>
	 </div>
	 
   	</div>
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>Nov</h4></center>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
	    <input type="text" class="form-control" name="nov"  value="<?php echo $per;?>" placeholder="<?php echo $per;?>" required="">
	    </div>
	  </div>
	 </div>
	 <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
      	 <input type="text" class="form-control" name="disnov" value="0" placeholder="discount" required="">
        </div>
	   </div>
	 </div>
	
   	</div>
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>Dec</h4></center>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
	     <input type="text" class="form-control" name="dec"  value="<?php echo $per;?>" placeholder="<?php echo $per;?>" required="">
	    </div>
	  </div>
	 </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
      	 <input type="text" class="form-control" name="disd" value="0" placeholder="discount" required="">
        </div>
	   </div>
	 </div>
   	</div>
	<hr>
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>Jan</h4></center>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
	     <input type="text" class="form-control" name="jan"  value="<?php echo $per;?>" placeholder="<?php echo $per;?>" required="">
	    </div>
	   </div>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
      	 <input type="text" class="form-control" name="disj" value="0" placeholder="discount" required="">
        </div>
	   </div>
	  </div>
   	</div>
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>Feb</h4></center>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	     <div class="form-line"> 
	      <input type="text" class="form-control" name="feb"  value="<?php echo $per;?>" placeholder="<?php echo $per;?>" required="">
	     </div>
	   </div>
	 </div>
	  <div class="col-md-3">
	    <div class="form-group">
	     <div class="form-line"> 
      	  <input type="text" class="form-control" name="disf" value="0" placeholder="discount" required="">
         </div>
        </div>	 
	 </div>
   	</div>
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>March</h4></center>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
	     <input type="text" class="form-control" name="mar" value="<?php echo $per;?>" placeholder="<?php echo $per;?>" required="">
	    </div>
	   </div>
	 </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
      	 <input type="text" class="form-control" value="0" name="disma" placeholder="discount" required="">
        </div>
	   </div>
	 </div>
   	</div>
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>April</h4></center>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
	     <input type="text" class="form-control" name="apr" value="<?php echo $per;?>" placeholder="<?php echo $per;?>" required="">
	    </div>
	   </div>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
         <input type="text" class="form-control" name="disap" value="0" placeholder="discount" required="">
        </div>
       </div>		
     </div>
   	</div>
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>May</h4></center>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
	     <input type="text" class="form-control" name="may"  value="<?php echo $per;?>" placeholder="<?php echo $per;?>" required="">
	    </div>
	   </div>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
      	 <input type="text" class="form-control" name="dism" value="0" placeholder="discount" required="">
        </div>
	   </div>
	  </div>
   	</div>
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>Term1</h4></center>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
	     <input type="text" class="form-control" name="term1"  value="<?php echo $t1;?>" placeholder="<?php echo $t1;?>" required="">
	    </div>
	   </div>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
      	 <input type="text" class="form-control" name="dist1" value="0" placeholder="discount" required="">
        </div>
	   </div>
	  </div>
   	</div>
	<div class="row clearfix">
      <div class="col-md-3">
       <center><h4>Term 2</h4></center>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
	     <input type="text" class="form-control" name="term2"  value="<?php echo $t2;?>"required="">
	    </div>
	   </div>
	  </div>
	  <div class="col-md-3">
	   <div class="form-group">
	    <div class="form-line"> 
      	 <input type="text" class="form-control" name="dist2" value="0" placeholder="discount" required="">
        </div>
	   </div>
	  </div>
   	</div>
	<div class="form-row">
		<div class="col-lg-4 col-md-6 col-sm-12">
            <div class="form-group">
				<button type="submit" name="submit" value="Submit" class="btn btn-primary">Submit</button>
			</div>
        </div>
	</div>
	</form>
     </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
