<?php
  include('header.php');
  include('connect.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Notice</li>
      </ol>
	<?php if(isset($_GET['notice_id'])){ ?>
    <form name="addnoticeForm" onsubmit="return submitData(event,<?php echo $_GET['notice_id']?>)" id="addnoticeForm">
	<?php }else{ ?>
	<form name="addnoticeForm" onsubmit="return submitData(event)" id="addnoticeForm">
	<?php } ?>
		  <div class="form-group row">
			<label for="receiver" class="col-sm-2 col-form-label">Receiver</label>
			<div class="col-sm-10">
			  <select class="form-control" name="receiver" id="class">
					<option value="">Select Receiver</option>
				</select>
			</div>
		  </div>
		  <div class="form-group row">
			<label for="notice" class="col-sm-2 col-form-label">Notice</label>
			<div class="col-sm-10">
			  <textarea class="form-control"  rows="4" cols="50" id="notice" name="notice" placeholder="Enter Your Notice"></textarea>
			</div>
		  </div>
	  <button type="submit" class="btn btn-primary my-1">Submit</button>
	</form>
	<div class="table-responsive mt-2">
	  <table class="table table-bordered" id="noticeTable" width="100%" cellspacing="0">
		<thead>
		  <tr>
			<th>Sr. No.</th>
			<th>Receiver</th>
			<th>Notice</th>
			<th>Sender</th>
			<th>Date</th>
			<th>Manage</th>
		  </tr>
		</thead>
		<tbody>
		</tbody>
	  </table>
	</div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/notice.js"></script>
</body>

</html>
