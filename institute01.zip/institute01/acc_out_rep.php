<?php
  include('header.php');
?>
<script>
	function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
		
</script>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Blank Page</li>
      </ol>
      <div class="row">
		<div class="col-12"><h3>  Outstanding report  </h3></div>
		</div>
      <form method="POST" action="">
					 <div class="row">     
                            <div class="col-lg-4 col-md-12">
                                <div class="form-group drop-custum">
                                    <select name="value" id="value" class="form-control show-tick" onchange="getvalue(this.value)">
                                        <option value="">-- Select Class --</option>
										<?php
											require_once("connect.php");
											$query =mysqli_query($con,"SELECT * FROM class");
											while($row=mysqli_fetch_array($query))  
												{
										?>
												<option value="<?php echo $row['Class_id']; ?>"><?php echo $row["Class_Name"];?></option>
										<?php
												}
										?>
									</select>
                                </div>
                            </div>
							<div class="col-lg-4 col-md-6 col-sm-12">
                                <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                            <br><br><br><br><br>
							</div>
					 </div>
					</form>
      <br>
      <br>
      <br>
      <br>
	  <div class="row">
		<div class="col-md-4">
			<button id="Somesh" onclick="printDiv('table-responsive')" name="Somesh" class="btn btn-dark">Print</button>
		</div>
	  </div>
      <div class="row">
      <div class="col-md-12">
         <div class="card mb-3">
          
          <div class="card-body">
            <div class="table-responsive">
				<div id="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
    <th>Stud_id</th>
    <th>Name</th>
	<th>Last Receipt</th>
	<th>Outstanding Amount</th>
  </tr>

                </thead>
                <tbody>
                <?php
				include('connect.php');
				$tot=0;
				if(isset($_POST['submit']))
					{
						$std=$_POST['value'];
						$que="SELECT * FROM  outstandingSo WHERE class_id='$std'";
						$res = $con->query($que);
						
						while ($row = $res->fetch_assoc()) {
							echo "<tr>";
							echo "<td>".$row['Stud_id']."</td>";
							echo "<td>".$row['First_name']." ".$row['Middle_name']." ".$row['Last_name']."</td>";
							echo "<td>".$row['Z']."</td>";
							echo "<td>".$row['Outstanding']."</td>";
							$ab=$row['Outstanding'];
							$tot=$tot+$ab;
							echo "</tr>";
						}
					}
				else 
					{
						$que="SELECT * FROM outstandingSo";
						$res = $con->query($que);

						while ($row = $res->fetch_assoc()) {
							echo "<tr>";
							echo "<td>".$row['Stud_id']."</td>";
							echo "<td>".$row['First_name']." ".$row['Middle_name']." ".$row['Last_name']."</td>";
							echo "<td>".$row['Z']."</td>";
							echo "<td>".$row['Outstanding']."</td>";
							$ab=$row['Outstanding'];
							$tot=$tot+$ab;
							echo "</tr>";
						}
					}
			?>

                </tbody>
              </table>
			  </div>
            </div>
          </div>
          <div class="card-footer small text-muted"></div></div>
          </div>
      
    </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
