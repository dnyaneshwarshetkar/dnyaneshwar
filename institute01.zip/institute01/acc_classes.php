<?php
  include('header.php');
  include('connect.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a> 
        </li>
        <li class="breadcrumb-item active">Classes</li>
      </ol>
		<h4>Add Class</h4>
		<form name="AddClass" onsubmit="return submitData()">
		  <div class="form-group row">
			<label for="class_name" class="col-sm-2 control-label">Class Name</label>
			<div class="col-sm-4">
				<input type="text" class="form-control" id="class_name" name="class_name" placeholder="Enter Class Name" required>
			</div>
		  </div>
		  <div class="form-group row">
			<div class="col-sm-10 offset-sm-2">
			  <button type="submit" name="submit" value="submit" class="btn btn-success">Submit</button>
			  <button type="reset" class="btn btn-danger">Reset</button>
			</div>
		  </div>
		</form>
      <div class="row">
      <div class="col-md-12">
            <div class="table-responsive">
              <table class="table table-bordered" id="classTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Sr.No</th>
                    <th>Class</th>
                    <th>Manage</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
        </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  <script src="js/class.js"></script>
</body>

</html>
