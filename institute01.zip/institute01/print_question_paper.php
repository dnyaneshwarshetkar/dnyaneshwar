<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Question Paper</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="container">
		<div id="institueInfo">
		
		</div>
		<div id="questions">
		
		</div>
	</div>
	<script id="instituteExam" type="text/html">
		<h3 class="text-center">Dr. Babasaheb Ambedkar Technological University, Lonere</h3>
		<h4 class="text-center">Autonomous University</h4>
		<address class="text-center">Lonere,Tq.Raigad Dist. Nanded</address>
		<hr/>
		<div class="col-sm-12">
			<i>No of Questions : <b data-content="no_of_questions"></b></i>
			<i>Marks Per Questions:<b data-content="marks_per_question"></b></i>
			<i>Exam Duration:<b data-content="exam_duration"></b></i>
			<i>Exam Type:<b data-content="exam_type"></b></i>
			<i>Negative Type:<b data-content="negative_type"></b></i>
		</div>
		<hr/>
		<div class="col-sm-12">
			<p>Name of Student :</p>
			<p>Class :</p>
		</div>
		<hr>
		
	</script>
	<script id="question" type="text/html">
		<div class="col-sm-12">
			<p><b>Question <span data-content="key"></span></b> :<i data-content="question"></i></p>
			<p><b>A) </b>:<i data-content="optionA"></i></p>
			<p><b>B) </b>:<i data-content="optionB"></i></p>
			<p><b>C) </b>:<i data-content="optionC"></i></p>
			<p><b>D) </b>:<i data-content="optionD"></i></p>
		</div>
	</script>
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- Core plugin JavaScript-->
	<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
	<!-- Page level plugin JavaScript-->
	<script src="vendor/chart.js/Chart.min.js"></script>
	<script src="vendor/datatables/jquery.dataTables.js"></script>
	<script src="vendor/datatables/dataTables.bootstrap4.js"></script>
	<!-- Custom scripts for all pages-->
	<script src="js/sb-admin.min.js"></script>
	<!-- Custom scripts for this page-->
	<script src="js/sb-admin-datatables.min.js"></script>
	<script src="js/sb-admin-charts.min.js"></script>
	<script src="js/jquery.loadTemplate.min.js"></script>
	<script src="js/basic.js"></script>
	<script>
		$(document).ready(function(){
		var params = getAllUrlParams(window.location.href);
		url ="server/get_data.php?printpaper=true&exam_id="+params['exam_id'];
		$.ajax({
		  type: "POST",
		  url: url,
		  data: null,
		  success: function(data,status){
			  data = JSON.parse(data);
			  $.each(data.questions,function(key,value){
				  value['key'] = key+1;
			  })
			  $("#institueInfo").loadTemplate("#instituteExam",data.exam);
			  $("#questions").loadTemplate("#question",data.questions);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
			
		});
	</script>
</body>
</html>