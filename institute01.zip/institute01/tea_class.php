<?php
  include('header.php');
   include('session_teacher.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('teachersidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Blank Page</li>
      </ol>
      <div class="row">

      <div class="col-md-12">
         <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-table"></i>Classwise Attendance</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <div class="body">
                 <form id="form_validation" method="POST">
                <thead>
                  <tr>
                    <th> Student Name</th>
                    <th> Present</th>
                    <th> absent</th>
                  
                  </tr>

                </thead>
                <tbody>
				
                <?php
  include('connect.php');
  $sql1 = "SELECT * FROM student WHERE Class_id='$cid'";
    $result = $con->query($sql1);
    while($row = $result->fetch_assoc()) 
      {
    echo "<tr>";
    echo "<td>".$row['First_name']." ".$row['Middle_name']." ".$row['Last_name']."</td>";
    echo "<td> <a href='present.php?Stud_id=".$row['Stud_id']."'>present</a> </td>";
        echo "<td> <a href='absent.php?Stud_id=".$row['Stud_id']."'>absent</a> </td>";
    echo "</tr>";
      }
  ?>

                </tbody>
              </table>
            </div>
          </div>
          <div class="card-footer small text-muted"></div></div>
          </div>
      
    </div>
  </form>
</div>

        
      </div>
      

 
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
