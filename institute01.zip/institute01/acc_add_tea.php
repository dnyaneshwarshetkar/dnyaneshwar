<?php
  include('header.php');
  require "connect.php";
 ?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <?php if(isset($_GET['teach_id'])){?>
        <li class="breadcrumb-item active">Edit Teacher</li>
		<?php }else{ ?>
		<li class="breadcrumb-item active">Add Teacher</li>
		<?php } ?>
      </ol>
	  <?php if(isset($_GET['teach_id'])){ ?>
      <form name="addTeacherForm" onsubmit="return submitData(event,<?php echo $_GET['teach_id']?>)" id="addTeacherForm">
	  <?php }else{ ?>
	  <form name="addTeacherForm" onsubmit="return submitData(event)" id="addTeacherForm">
	  <?php } ?>
		<div class="form-row">
		  <div class="form-group col-md-4">
				<label for="first_name">First Name</label>
				<input class="form-control" id="first_name" type="text" name="first_name" placeholder="Enter First Name">
		  </div>
		   <div class="form-group col-md-4">
				<label for="middle_name">Middle Name</label>
				<input class="form-control" id="middle_name" type="text" name="middle_name" placeholder="Enter Middle Name">
		   </div>
		   <div class="form-group col-md-4">
				<label for="last_name">Last Name</label>
				<input class="form-control" id="last_name" type="text" name="last_name" placeholder="Enter Last Name">
		   </div>
		</div>
        <div class="form-row">
			<div class="form-group col-md-4">
				<label for="designation">Designation</label>
				<input class="form-control" id="designation" type="text" name="designation" placeholder="Enter Designation">
            </div>
			<div class="form-group col-md-4">
				<label for="mobile">Mobile</label>
				<input type="text" class="form-control" id="mobile" type="text" name="mobile" placeholder="Enter Mobile">
            </div>
			<div class="form-group col-md-4">
				<label for="dob">Date of Birth</label>
				<input class="form-control" id="dob" type="date" name="dob" placeholder="Enter Date of Birth">
            </div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="gender">Gender</label>
				<select class="form-control" name="gender" id="gender">
					<option value="">Select Gender</option>
					<option value="male">MALE</option>
					<option value="female">FEMALE</option>
				</select>
            </div>
			<div class="form-group col-md-4">
				<label for="doj">Date of Joining</label>
				<input class="form-control" id="doj" type="date" name="doj" placeholder="Enter Date of Joining">
            </div>
			<div class="form-group col-md-4">
				<label for="class_id">Class</label>
				<select class="form-control" name="class_id" id="class_id">
					<option value="">Select Class</option>
				</select>
			</div>          
        </div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="address">Address</label>
				<input class="form-control" id="address" type="text" name="address" placeholder="Enter Address">
            </div>
			<div class="form-group col-md-4">
				<label for="email">Email</label>
				<input class="form-control" id="email" type="email" name="email" placeholder="Enter Email">
            </div>
			<div class="form-group col-md-4">
				<label for="password">Password</label>
				<input class="form-control" id="password" type="password" name="password" placeholder="Enter your Password">
			</div>			
        </div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<label for="status">Status</label>
				<select class="form-control custom-select" name="status" id="status">
					<option value="">Select Status</option>
					<option value="1">Active</option>
					<option value="0">Inactive</option>
				</select>
			</div>
		</div>
        <button type="submit" name="Add Teacher" class="btn btn-primary">Add Teacher</button>
		</form>
       </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/teacher.js"></script>
</body>

</html>
