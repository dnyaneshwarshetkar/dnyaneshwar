<?php
  include('header.php');
?>
<body>
	<div class="row">
	<div class="col-sm">
	</div>
	  <div class="col-sm">
		<div class="card text-center border-success text-secondary">
		  <div class="card-header">
			<h4>Instructions</h4>
		  </div>
		  <div class="card-body">
			<h5 class="card-title">Read Instructions Carefully</h5>
			<ul class="list-group list-group-flush">
			  <li class="list-group-item">There are four Choices for any question</li>
			  <li class="list-group-item">Choose Appropriate Answer</li>
			  <li class="list-group-item">Save the Answer</li>
			  <li class="list-group-item">Click on Next Button For Next Question</li>
			  <li class="list-group-item">Click on Previous Button Previous Question</li>
			  <li class="list-group-item">After Completion click on Submit Button</li>
			</ul>
			<div class="mt-2">
				<button onclick="startPaper()" class="btn btn-primary">Start</button>
			</div>
		  </div>
		</div>
	  </div>
	  <div class="col-sm">
	</div>
	</div>
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- Core plugin JavaScript-->
	<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
	<!-- Page level plugin JavaScript-->
	<script src="vendor/chart.js/Chart.min.js"></script>
	<script src="vendor/datatables/jquery.dataTables.js"></script>
	<script src="vendor/datatables/dataTables.bootstrap4.js"></script>
	<!-- Custom scripts for all pages-->
	<script src="js/sb-admin.min.js"></script>
	<!-- Custom scripts for this page-->
	<script src="js/sb-admin-datatables.min.js"></script>
	<script src="js/sb-admin-charts.min.js"></script>
	<script>
	var startPaper = function(){
		var url = document.location.href;
		window.location.href = "stud_question_paper.php?exam_id="+url.split('?')[1].split('=')[1];
	 }
	</script>
</body>
</html>
