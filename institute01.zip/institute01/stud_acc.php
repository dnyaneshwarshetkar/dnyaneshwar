<?php
//   MAX SDFXGCHHJMHG
  include('header.php');
  include('connect.php');
  // session_start();
   if(isset($_GET['stud_id']))
		{
		$stud_id=$_GET['stud_id'];
		$sql1 = "SELECT * FROM account WHERE receipt_id=(SELECT MAX(receipt_id) FROM account WHERE stud_id='$stud_id')";
		$result = $con->query($sql1);	
		$fname = "";
		$lname = "";    
		$data = array();
		if ($result->num_rows==1) 
			{
			while($row = $result->fetch_assoc()) 
				{
				$class_id=$row['class_id'];
				$Jan=$row['jan'];
				$Feb=$row['feb'];
				$March=$row['march'];
				$April=$row['april'];
				$May=$row['may'];
				$June=$row['june'];
				$July=$row['july'];
				$Aug=$row['aug'];
				$Sept=$row['sept'];
				$Octo=$row['octo'];
				$Nov=$row['nov'];
				$Deca=$row['deca'];
				$Term1=$row['term1'];
				$Term2=$row['term2'];
				$Out=$row['outstanding'];
				$Tot=$row['total_outstanding'];
				   
				}  
			}
		}
		
		if(isset($_POST['btnsave']))
		{
		$month=" ";
		$fill_jun=0;
		$fill_jul=0;
		$fill_aug=0;
		$fill_sep=0;
		$fill_oct=0;
		$fill_nov=0;
		$fill_dec=0;
		$fill_jan=0;
		$fill_feb=0;
		$fill_mar=0;
		$fill_apr=0;
		$fill_may=0;
		$fill_t1=0;
		$fill_t2=0;
		$amt=0;
		$notes = $_POST['notes'];
		// 		for each month separately
		
		if(isset($_POST['ch_jun']) &&   $_POST['ch_jun'] == 'Yes')
			{
			$month = $month."-June";
			$fill_jun = $_POST['fil_jun'];
			$amt=$amt+$fill_jun;
		//	$pay_jun = $totaly_jun - $fill_jun;
			}
		if(isset($_POST['ch_jul']) &&   $_POST['ch_jul'] == 'Yes')
			{
			$month = $month."-July";
			$fill_jul = $_POST['fil_jul'];
			$amt=$amt+$fill_jul;
		//	$pay_jul = $totaly_jul - $fill_jul;
			}
		if(isset($_POST['ch_aug']) &&   $_POST['ch_aug'] == 'Yes')
			{
			$month = $month."-August";
			$fill_aug = $_POST['fil_aug'];
			$amt=$amt+$fill_aug;
			//	$pay_aug = $totaly_aug - $fill_aug;
			}
		if(isset($_POST['ch_sept']) &&   $_POST['ch_sept'] == 'Yes')
			{
			$month = $month."-September";
			$fill_sep = $_POST['fil_sept'];
			$amt=$amt+$fill_sep;
			//	$pay_sept = $totaly_sep - $fill_sep;
			}
		if(isset($_POST['ch_octo']) &&   $_POST['ch_octo'] == 'Yes')
			{
			$month = $month."-October";
			$fill_oct = $_POST['fil_octo'];
			$amt=$amt+$fill_oct;
			//	$pay_octo = $totaly_oct - $fill_oct;
			}
		if(isset($_POST['ch_nov']) &&   $_POST['ch_nov'] == 'Yes')
			{
			$month = $month."-November";
			$fill_nov = $_POST['fil_nov'];
			$amt=$amt+$fill_nov;
		//	$pay_nov = $totaly_nov - $fill_nov;
			}
		if(isset($_POST['ch_deca']) &&   $_POST['ch_deca'] == 'Yes')
			{
			$month = $month."-December";
			$fill_dec = $_POST['fil_deca'];
			$amt=$amt+$fill_dec;
		//	$pay_dec = $totaly_dec - $fill_dec;
			}
		if(isset($_POST['ch_jan']) &&   $_POST['ch_jan'] == 'Yes')
			{
			$month = $month."-January";
			$fill_jan = $_POST['fil_jan'];
			$amt=$amt+$fill_jan;
		//	$pay_jan = $totaly_jan - $fill_jan;
			}
		if(isset($_POST['ch_feb']) &&   $_POST['ch_feb'] == 'Yes')
			{
			$month = $month."-February";
			$fill_feb = $_POST['fil_feb'];
			$amt=$amt+$fill_feb;
		//	$pay_feb = $totaly_feb - $fill_feb;
			}
		if(isset($_POST['ch_mar']) &&   $_POST['ch_mar'] == 'Yes')
			{
			$month = $month."-March";
			$fill_mar = $_POST['fil_mar'];
			$amt=$amt+$fill_mar;
			//	$pay_mar = $totaly_mar - $fill_mar;
			}
		if(isset($_POST['ch_apr']) &&   $_POST['ch_apr'] == 'Yes')
			{
			$month = $month."-April";
			$fill_apr = $_POST['fil_apr'];
			$amt=$amt+$fill_apr;
			//	$pay_apr = $totaly_apr - $fill_apr;
			}
		if(isset($_POST['ch_may']) &&   $_POST['ch_may'] == 'Yes')
			{
			$month = $month."-May";
			$fill_may = $_POST['fil_may'];
			$amt=$amt+$fill_may;
			//	$pay_may = $totaly_may - $fill_may;
			}
		if(isset($_POST['ch_t1']) &&   $_POST['ch_t1'] == 'Yes')
			{
			$month = $month."-Term One";
			$fill_t1 = $_POST['fil_t1'];
			$amt=$amt+$fill_t1;
		//	$pay_t1 = $totaly_t1 - $fill_t1;
			}
		if(isset($_POST['ch_t2']) &&   $_POST['ch_t2'] == 'Yes')
			{
			$month = $month."-Term Two";
			$fill_t2 = $_POST['fil_t2'];
			$amt=$amt+$fill_t2;
		//	$pay_t2 = $totaly_t2 - $fill_t2;
			}
			
		// Actual Calculation ....!!!	FOR RECEIPT ONLY   !!....
			$Total_Val = 0;
			$pay_jun=$June - $fill_jun;
			$pay_jul=$July - $fill_jul;
			$pay_aug=$Aug - $fill_aug;
			$pay_sept=$Sept - $fill_sep;
			$pay_octo=$Octo - $fill_oct;
			$pay_nov=$Nov - $fill_nov;
			$pay_dec=$Deca - $fill_dec;
			$pay_jan=$Jan - $fill_jan;
			$pay_feb=$Feb - $fill_feb;
			$pay_mar=$March - $fill_mar;
			$pay_apr=$April - $fill_apr;
			$pay_may=$May - $fill_may;
			$pay_t1=$Term1 - $fill_t1;
			$pay_t2=$Term2 - $fill_t2;
			
			$Total_Val = $pay_jun + $pay_jul + $pay_aug + $pay_sept + $pay_octo + $pay_nov + $pay_dec + $pay_jan + $pay_feb + $pay_mar + $pay_apr +	$pay_may + $pay_t1 + $pay_t2;			
			
			$pay_out = $Out -$Total_Val;
			$dt=date('Y-m-d');		// ADDED INSTEAD OF NOW()
			$sql ="INSERT INTO account(stud_id,date,term1,term2,jan,feb,march,april,may,june,july,aug,sept,octo,nov,deca,outstanding, total_outstanding,class_id,status)
			VALUES ('$stud_id','$dt','$pay_t1','$pay_t2','$pay_jan','$pay_feb','$pay_mar','$pay_apr','$pay_may','$pay_jun','$pay_jul','$pay_aug','$pay_sept','$pay_octo','$pay_nov','$pay_dec','$Total_Val','$Tot','$class_id',1)";
			if($con->query($sql)){
				echo "<script>alert('Added Succesfully');
			       </script>";
				}
			else{
				die('Could not add data'.mysqli_error($con));
				}	
		
			$sql2 = "SELECT MAX(receipt_id) AS S FROM account WHERE stud_id='$stud_id'";
			$result = $con->query($sql2);
			$row = $result->fetch_assoc();
			$rec = $row['S'];
			
			$sql4 = "INSERT INTO receipt(receipt_id,stud_id,month,paid,Date,note)
							VALUES ('$rec','$stud_id','$month','$amt','$dt','$notes')";					
		
	if($con->query($sql4)){
				echo "<script>
						alert('Added Succesfully');
						window.location.href = 'receiptA.php?receipt_id=".$rec."';
					</script>";	
			 }
			 else{
				 
				die('Could not add data'.mysqli_error($con)); 
			 }
		
		}
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Student Account</li>
      </ol>
      <div class="row">
	  <div class=col-12>
	    <h3>Student Account</h3>
		</div>
      </div>
	  <br>
	  <div class="row clearfix">
			<div class= "col-md-4">
				<h4>Outstanding Amount :<?php echo $Out;?> </h4>
			</div>
			<div class= "col-md-4">
				<h4> </h4>
			</div>
			<div class= "col-md-4">
				<h4>Total Amount : <?php echo $Tot; ?> </h4>
			</div>
		</div>
        <br><br><br>
		<form id="form_validation" method="post" action="">
        		<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_jun" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> June </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="jun" id="jun" class="form-control" value="<?php echo $June;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_jun" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_jun" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>					
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_jul" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> July </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="jul" id="jun" class="form-control" value="<?php echo $July;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_jul" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_jul" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_aug" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> Aug </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="aug" id="jun" class="form-control" value="<?php echo $Aug;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_aug" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_aug" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_sept" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning">Sept </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="sept" id="jun" class="form-control" value="<?php echo $Sept;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_sept" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_sept" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_octo" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning">Oct </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="octo" id="jun" class="form-control" value="<?php echo $Octo;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_octo" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_octo" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_nov" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> Nov </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="nov" id="jun" class="form-control" value="<?php echo $Nov;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_nov" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_nov" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_deca" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> Dec </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="deca" id="jun" class="form-control" value="<?php echo $Deca;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_deca" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_deca" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_jan" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> Jan </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="jan" id="jun" class="form-control" value="<?php echo $Jan;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_jan" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_jan" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_feb" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> Feb </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="feb" id="jun" class="form-control" value="<?php echo $Feb;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_feb" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_feb" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_mar" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> March </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="mar" id="jun" class="form-control" value="<?php echo $March;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_mar" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_mar" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_apr" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> April </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="apr" id="jun" class="form-control" value="<?php echo $April;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_apr" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_apr" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>			
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_may" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> May </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="may" id="jun" class="form-control" value="<?php echo $May;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_may" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_may" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_t1" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> Term 1 </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="t1" id="jun" class="form-control" value="<?php echo $Term1;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_t1" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_t1" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>
				<div class="row">
						<div class= "col-md-1">
							<div class="form-line">
								   <input name="ch_t2" value="Yes" type="checkbox" id="basic_checkbox_1" class="filled-in" >
									<label for="basic_checkbox_1"></label>
                            </div>
						</div>
                            <div class="col-lg-2 col-md-2">
                               <button type="button" class="btn btn-warning"> Term 2 </button>
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input  type="text" name="t2" id="jun" class="form-control" value="<?php echo $Term2;?>" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="fil_t2" id="fil_jun" value="0" class="form-control" onkeyup="pika()" required="">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-3 col-md-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="tot_t2" id="tot_jun" class="form-control" value="0" placeholder="" required="">
                                    </div>
                                </div>
                            </div>
						</div>					
                <div class="row ">
							<div class="col-lg-3 col-md-3">
								<div class="form-group">
                                    <div class="form-line">
                                        <input name="notes" type="text" class="form-control" placeholder="Note" required="">
                                    </div>
                                </div>
							</div>
						</div>
       			<div class="row ">                            
                              <div class="col-sm-12">
                              <button name="btnsave" type="submit" class="btn btn-raised g-bg-blush2">Submit</button>
                            </div>
                        </div>						
		</form>		   
     </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
