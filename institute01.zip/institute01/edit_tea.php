<?php
  include('header.php');
  include('connect.php');
  
 
	session_start();
	include "connect.php";
	if(isset($_SESSION['username']))
		{
		$mail=$_SESSION['username'];
		$sql1 = "SELECT * FROM teacher where fname='$mail'";
		$result = $con->query($sql1);
		$fname = "";
		$lname = "";    
		$data = array();
		if ($result->num_rows==1) 
			{
			while($row = $result->fetch_assoc()) 
				{
				$fname=$row["fname"];
				$lname=$row["surname"];
				$tid=$row["Teach_id"];
				}
			}  
		} 
		else{
		header("location: index.php");
		}
  if(isset($_GET['Teach_id']))
  {  
	$stu=$_GET['Teach_id'];
    $sql1 = "SELECT * FROM teacher WHERE Teach_id='$stu'";
    $result = $con->query($sql1);
    $data = array();
    if ($result->num_rows==1) 
    {
      while($row = $result->fetch_assoc()) 
      {  
		$first=$row['fname'];
		$middle=$row['mname'];
		$last=$row['surname'];
		$desi=$row['Designation'];
		$doj=$row['Date_Of_Joining'];
		$class=$row['Class_id'];
	    $add=$row['Address'];
		$gen=$row['Gender'];
		$email=$row['Email'];
		$dob=$row['Date_of_birth'];
        $cont=$row['Mobile_No'];
	  }
	}
	
  } 
  ?>
<?  
 if(isset($_POST['sub']))
  {
	$uname1=$_GET['Teach_id'];
	$first1=$_POST['first'];
    $middle1=$_POST['middle'];
	$last1=$_POST['last'];
    $desig1=$_POST['desig'];
    $phone1=$_POST['phone'];
    $dob1=$_POST['dob'];
	$gen1=$_POST['gen'];
	$doj1=$_POST['doj'];
	$std1=$_POST['std'];
    $addr1=$_POST['addr'];
    $email1=$_POST['email'];
    $sql = "UPDATE teacher SET fname='$first1',mname='$middle1',surname='$last1',Designation='$desig1',Mobile_No='$phone1',Date_of_birth='$dob1',Gender='$gen1',Date_Of_Joining='$doj1',Class_id='$std1',Address='$addr1',Email='$email1' WHERE Teach_id='$uname1'";
      if($con->query($sql)){
        echo "<script>alert('Added Succesfully');
         </script>";
		 header("Refresh:0");
      }
      else{
                die('Could not add data'.mysql_error());
      }
  }
 ?>



<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Blank Page</li>
      </ol>
      <div class="row">
        
      </div>
	  <form method="POST" action="">
      <div class="form-row">
          <div class="col-md-4">
                <label for="exampleInputName">First name</label>
                <input class="form-control" id="exampleInputName" name="first" type="text" value="<?php echo $first;?>" aria-describedby="nameHelp" placeholder="Enter first name">
          </div>
           <div class="col-md-4">
                <label for="exampleInputLastName">Middle name</label>
                <input class="form-control" id="exampleInputLastName" name="middle" type="text" value="<?php echo $middle ;?>" aria-describedby="nameHelp" placeholder="Enter middle name">
           </div>
           <div class="col-md-4">
                <label for="exampleInputLastName">Last name</label>
                <input class="form-control" id="exampleInputLastName" name="last" type="text" value="<?php echo $last;?>" aria-describedby="nameHelp" placeholder="Enter last name">
           </div>
      
      </div>
   <br>

 <div class="form-row">
              <div class="col-md-4">
                <label for="exampleInputName">Designation</label>
                <input class="form-control" id="exampleInputName" type="text" name="desig" value="<?php echo $desi;?>" aria-describedby="nameHelp" placeholder="Designation">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">Phone Number</label>
                <input class="form-control" id="exampleInputLastName" name="phone" type="text" value="<?php echo $cont;?>" aria-describedby="nameHelp" placeholder="Phone no">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">Date Of Birth</label>
                <input class="form-control" id="exampleInputLastName" name="dob" type="date" value="<?php echo $dob ;?>" aria-describedby="nameHelp" placeholder="dob">
              </div>
            </div>
      <br>


 <div class="form-row">
     <div class="col-md-4">
        <label for="exampleInputLastName">Gender</label>
            <select name="gen" class="form-control">
				<option>Select Gender</option>
				<option selected value="<?php echo $gen;?>"> <?php echo $gen;?> Selected</option>
				<option value="">Male</option>
				<option value="">Female</option>             
            </select>
     </div>
       <div class="col-md-4">
          <label for="exampleInputLastName">Date of joining</label>
            <input class="form-control" id="exampleInputLastName" name="doj" type="text" value="<?php echo $doj ;?>" aria-describedby="nameHelp" placeholder="Date of joining">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">class </label>
                    <select name="std" class="form-control show-tick">
					    <?php $sql1 = "SELECT Class_Name AS C FROM class WHERE Class_id='$class'";
							$result = $con->query($sql1);
							$row = $result->fetch_assoc();
							$N = $row['C']; 
						?>
									<option value="">-- Select Class --</option>
									<option selected value="<?php echo $class;?>"> <?php echo $N;?> Selected</option>
										<?php
											require_once("connect.php");
											$query =mysqli_query($con,"SELECT * FROM class");
											while($row=mysqli_fetch_array($query))  
												{
										?>
												<option value="<?php echo $row['Class_id']; ?>"><?php echo $row["Class_Name"];?></option>
										<?php
												}
										?>
							
									</select>
                 </div>
            </div>
      <br>

  
 <div class="form-row">
              <div class="col-md-4">
                <label for="exampleInputName">Address</label>
                <input class="form-control" id="exampleInputName" name="addr" type="text" value="<?php echo $add ;?>" aria-describedby="nameHelp" placeholder="Address">
              </div>
        <div class="col-md-4">
                <label for="exampleInputLastName">Email_id</label>
                <input class="form-control" id="exampleInputLastName" name="email" type="text" value="<?php echo $email ;?>" aria-describedby="nameHelp" placeholder="Email_id">
              </div>
             
            </div>
			
<div class="form-row">
            <div class="col-4">
         <br>
            <input type="submit" name="sub" class="btn btn-primary"/>
        </div>
</div>
</form>
      <br>
       </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
