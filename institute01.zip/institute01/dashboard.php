<?php
  include('header.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
	<div class="content-wrapper">
		<div class="container-fluid">
		  <!-- Breadcrumbs-->
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
				<li class="breadcrumb-item active">Home</li>
			</ol>
			<div class="row">
				<div class="col-sm-3">
					<div class="card  text-center">
					  <img class="card-img-top dashimg" src="images/student.jpg" alt="Student">
					  <div class="card-body">
						<h5 class="card-title">Student</h5>
						<p class="card-text">Add,Edit,View,Delete Student</p>
						<a href="student.php" class="btn btn-primary">Change Student</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="card  text-center">
					  <img class="card-img-top dashimg" src="images/teacher.jpg" alt="Teacher">
					  <div class="card-body">
						<h5 class="card-title">Teacher</h5>
						<p class="card-text">Add,Edit,View,Delete Teacher</p>
						<a href="teacher.php" class="btn btn-primary">Change Teacher</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/fees.jpg" alt="Fees">
					  <div class="card-body">
						<h5 class="card-title">Fees</h5>
						<p class="card-text">Add, View, Edit, Delete Fees</p>
						<a href="fee_structure.php" class="btn btn-primary">Change Fees</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/exam.jpg" alt="Exam">
					  <div class="card-body">
						<h5 class="card-title">Exam</h5>
						<p class="card-text">Add, View, Edit, Delete Exam</p>
						<a href="exam.php" class="btn btn-primary">Change Exam</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3 mt-2">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/attendance.jpg" alt="Attendance">
					  <div class="card-body">
						<h5 class="card-title">Attendance</h5>
						<p class="card-text">Add, View, Edit, Delete Attendnace</p>
						<a href="attendance.php" class="btn btn-primary">Change Attendance</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3 mt-2">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/notice.jpg" alt="Notice">
					  <div class="card-body">
						<h5 class="card-title">Notice</h5>
						<p class="card-text">Add, View, Edit, Delete Notice</p>
						<a href="notice.php" class="btn btn-primary">Change Notice</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3 mt-2">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/homework.jpg" alt="Homework">
					  <div class="card-body">
						<h5 class="card-title">Homework</h5>
						<p class="card-text">Add, View, Edit, Delete Homework</p>
						<a href="homework.php" class="btn btn-primary">Change homework</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3 mt-2">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/timetable.jpg" alt="Time-table">
					  <div class="card-body">
						<h5 class="card-title">Time-Table</h5>
						<p class="card-text">Add, View, Edit, Delete Time-table</p>
						<a href="timetable.php" class="btn btn-primary">Change Time-Table</a>
					  </div>
					</div>
				</div>
			</div>
		</div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
