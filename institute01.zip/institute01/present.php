<?php

	include('connect.php');
	session_start();
	if(isset($_SESSION['username']))
		{
		$mail=$_SESSION['username'];
		$sql1 = "SELECT * FROM teacher where fname='$mail'";
		$result = $con->query($sql1);
		$fname = "";
		$lname = "";     
		$data = array();
		if ($result->num_rows==1) 
			{
			while($row = $result->fetch_assoc()) 
				{
				$fname=$row["fname"];
				$lname=$row["surname"];
				$tid=$row["Teach_id"];
				$cid=$row["Class_id"];
				}
			}  
		} 
	else{
		header("location: index.php");
		}

if($_GET['Stud_id']){
			$Sid=$_GET['Stud_id'];
			$sql="INSERT INTO attend(att_id,datea,Stud_id,teach_id,status) VALUES(NULL,NOW(),'$Sid','$tid','Present')";
			
			if($con->query($sql)){
				echo "<script>  alert('present student');</script>";
			}
			else{
				echo "<script>  alert('Error Occured');</script>";
			}
			 
			header('Location:tea_class.php');	
	}
	?>