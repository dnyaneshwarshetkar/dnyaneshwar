<?php
  include('header.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('studentsidebar.php');
  ?>
	<div class="content-wrapper">
		<div class="container-fluid">
		  <!-- Breadcrumbs-->
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
				<li class="breadcrumb-item active">Home</li>
			</ol>
			<div class="row">
				<div class="col-sm-3">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/fees.jpg" alt="Fees">
					  <div class="card-body">
						<h5 class="card-title">Fees</h5>
						<p class="card-text">View Fees</p>
						<a href="sfee_structure.php" class="btn btn-primary">View Fees</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/exam.jpg" alt="Exam">
					  <div class="card-body">
						<h5 class="card-title">Exam</h5>
						<p class="card-text">Take Exam</p>
						<a href="stud_tests.php" class="btn btn-primary">View Exam</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3 mt-2">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/attendance.jpg" alt="Attendance">
					  <div class="card-body">
						<h5 class="card-title">Attendance</h5>
						<p class="card-text">View Attendnace</p>
						<a href="sattendance.php" class="btn btn-primary">View Attendance</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3 mt-2">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/notice.jpg" alt="Notice">
					  <div class="card-body">
						<h5 class="card-title">Notice</h5>
						<p class="card-text">View Notice</p>
						<a href="snotice.php" class="btn btn-primary">View Notice</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3 mt-2">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/homework.jpg" alt="Homework">
					  <div class="card-body">
						<h5 class="card-title">Homework</h5>
						<p class="card-text">View Homework</p>
						<a href="shomework.php" class="btn btn-primary">View homework</a>
					  </div>
					</div>
				</div>
				<div class="col-sm-3 mt-2">
					<div class="card text-center">
					  <img class="card-img-top dashimg" src="images/timetable.jpg" alt="Time-table">
					  <div class="card-body">
						<h5 class="card-title">Time-Table</h5>
						<p class="card-text">View Time-table</p>
						<a href="stimetable.php" class="btn btn-primary">View Time-Table</a>
					  </div>
					</div>
				</div>
			</div>
		</div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
