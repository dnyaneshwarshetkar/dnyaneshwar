<?php
  date_default_timezone_set('Asia/Kolkata');
  $con=new mysqli("localhost","root","","institute9");
  if($con->connect_error)
    die("Connection failed: " .connect_error);
?>