<?php
  include('header.php');
?>
<body>
	<div class="conatainer">
		<div class="row result">
		</div>
	</div>
	<script id="result" type="text/html">
		<div class="col-sm">
		</div>
		<div class="col-sm">
			<div class="card text-center border-success text-secondary">
			  <div class="card-header">
				<h4>Result</h4>
			  </div>
			  <div class="card-body">
				<h5 class="card-title">Your Result is....</h5>
				<ul class="list-group list-group-flush">
				  <li class="list-group-item">Marked Gained : <span class="font-weight-bold" data-content="marks_gained"></span></li>
				  <li class="list-group-item">Negative Marks : <span class="font-weight-bold" data-content="negative_marks"></span></li>
				  <li class="list-group-item">Total Marks : <span class="font-weight-bold" data-content="total_marks"></span></li>
				  <li class="list-group-item">Correct : <span class="font-weight-bold" data-content="correct"></span></li>
				  <li class="list-group-item">Wrong : <span class="font-weight-bold" data-content="wrong"></span></li>
				  <li class="list-group-item">Attempted : <span class="font-weight-bold" data-content="attempted"></span></li>
				  <li class="list-group-item">Not Attempted : <span class="font-weight-bold" data-content="not_attempted"></span></li>
				  <li class="list-group-item">Passing Marks : <span class="font-weight-bold" data-content="passing_marks"></span></li>
				  <li class="list-group-item">Result : <span class="font-weight-bold" data-content="result"></span></li>
				</ul>
				<div class="mt-2">
					<button onclick="done()" class="btn btn-primary">Done</button>
				</div>
			  </div>
			</div>
		</div>
		<div class="col-sm">
		</div>
	</script>
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- Core plugin JavaScript-->
	<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
	<!-- Page level plugin JavaScript-->
	<script src="vendor/chart.js/Chart.min.js"></script>
	<script src="vendor/datatables/jquery.dataTables.js"></script>
	<script src="vendor/datatables/dataTables.bootstrap4.js"></script>
	<!-- Custom scripts for all pages-->
	<script src="js/sb-admin.min.js"></script>
	<!-- Custom scripts for this page-->
	<script src="js/sb-admin-datatables.min.js"></script>
	<script src="js/sb-admin-charts.min.js"></script>
	<script src="js/jquery.loadTemplate.min.js"></script>
	<script>
		var done = function(){
			window.location.href = "stud_tests.php";
		}
		$(document).ready(function(){
			examResponse = JSON.parse(localStorage.getItem("examResponse"));
			$(".result").loadTemplate("#result",examResponse);
		});
	</script>
</body>
</html>
