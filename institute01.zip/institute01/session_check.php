<?php
	session_start();
	if(!(isset($_SESSION['teacher'])||isset($_SESSION['student']))){
		echo "<script>alert('Session Expired');			window.location.assign('index.html');</script>";
	}
?>