<?php
  include('header.php');
  include('connect.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Add Exam</li>
      </ol>
	  <h2>Add Exam</h2>
		<form method="post" action="" name="exam">
		  <div class="form-group row">
			<label for="examName" class="col-sm-2 control-label">Exam Name</label>
			<div class="col-sm-4">
				<input type="text" class="form-control" id="examName" name="exam_name"placeholder="Enter Exam Name" required>
			</div>
			<label for="examDate" class="col-sm-2 control-label">Exam Date</label>
			<div class="col-sm-4">
			<input type="date" class="form-control" id="examDate" name="exam_date"placeholder="Enter Exam Date" required>
			</div>
		  </div>
		  <div class="form-group row">
			<label for="noOfQuestions" class="col-sm-2 control-label">No of Questions</label>
			<div class="col-sm-4">
			<input type="number" min="1" step="1"class="form-control" id="noOfQuestions" name="no_of_questions" placeholder="No Of Questions" value="0"  onchange="calculateMarks()" required>
			</div>
			<label for="marks_per_question" class="col-sm-2 control-label">Marks per Question</label>
			<div class="col-sm-4">
			<select  class="form-control" id="marksPerQuestion" name="marks_per_question" placeholder="Enter Marks Per Question" onchange="calculateMarks()" value="" required>
				  <option selected>Select Marks Per Question</option>
				  <option value="1">1</option>
				  <option value="2">2</option>
				  <option value="3">3</option>
				  <option value="4">4</option>
				  <option value="5">5</option>
			</select>
			<!--<input type="number" class="form-control" id="marksPerQuestion" name="marks_per_question" placeholder="Enter Marks Per Question" onchange="calculateMarks(this.value)"value="0">-->
			</div>
		  </div>
		  <div class="form-group row">
			<label for="marks" class="col-sm-2 control-label">Marks</label>
			<div class="col-sm-4">
			<input type="number" class="form-control" id="marks" name="marks" placeholder="Enter Marks" value="0">
			</div>
			<label for="passingMarks" class="col-sm-2 control-label">Passing Marks</label>
			<div class="col-sm-4">
			<input type="number" class="form-control" id="passsingMarks" name="passing_marks" placeholder="Enter Passing Marks" value="0" required>
			</div>
		  </div>
		  <div class="form-group row">
			<label for="examType" class="col-sm-2 control-label">Exam Type</label>
			<div class="col-sm-4">
			<select class="form-control" id="examType" name="exam_type" onchange="selectExamType(this.value)" required>
			  <option selected>Select Exam Type</option>
			  <option value="1">Class Level</option>
			  <option value="2">Subject Level</option>
			  <option value="3">Chapter Level</option>
			  <option value="4">Article Level</option>
			</select>
			</div>
			<label for="negativeType" class="col-sm-2 control-label">Negative Marks</label>
			<div class="col-sm-4">
				<select class="form-control" id="negativeType" name="negative_type">
				  <option selected>Select Negative Type</option>
				  <option value="0">No</option>
				  <option value="0.33">One Third</option>
				  <option value="0.25">One Fourth</option>
				  <option value="1">One to One</option>
				</select>
			</div>
		</div>
		<div class="form-group row">
			<label for="examDuration" class="col-sm-2 control-label">Exam Duration</label>
			<div class="col-sm-4">
				<input type="number" class="form-control" id="examDuration" name="exam_duration" placeholder="Enter Exam Duration" required/>
				<small class="form-text text-muted">Duration in minutes</small>
			</div>
		</div>
		<div class="form-group row">
			<!--<label for="class" class="col-sm-1 control-label">Class</label>-->
			<div class="col-sm-2">
				<select class="form-control custom-select" name="class_id" id="class" onchange="getSubject(this.value)">
					<option value="">Select Class</option>
				</select>
			</div>
			<!--<label for="subject" class="col-sm-1 control-label">Subject</label>-->
			<div class="col-sm-2">
			<select class="form-control custom-select" name="subject_id" id="subject" onchange="getChapter(this.value)">
			<option value="">Select Subject</option>
			</select>
			</div>
			<!--<label for="chapter_id" class="col-sm-1 control-label">Chapters</label>-->
			<div class="col-sm-2">
			<select class="form-control custom-select" name="chapter_id" id="chapter" onchange="getArticle(this.value)">
				<option value="">Select Chapter</option>
			</select>
			</div>
			<!--<label for="article_id" class="col-sm-1 control-label">Article</label>-->
			<div class="col-sm-2">
			<select class="form-control custom-select" name="article_id" id="article">
			<option value="">Select Article</option>
			</select>
			</div>
			<div class="col-sm-2">
				<a name="submit" value="search" class="btn btn-info" onclick="getQuestions()">Search</a>
			</div>
		</div>	
		 <div class="form-group row">
			<div class="col-sm-12  table-responsive">
              <table class="table table-bordered" id="questionTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Q. No</th>
				    <th>Select</th>
					<th>Que</th>
					<th>optionA</th>
					<th>optionB</th>
					<th>optionC</th>
					<th>optionD</th>
					<th>correctOpt</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
		  </div>
		</div>
		<div class="form-group row">
			<div class="col-sm-2 offset-sm-2">
			  <button type="submit" name="submit" value="submit" class="btn btn-success">Submit</button>
			  <button type="reset" class="btn btn-danger">Reset</button>
			</div>
		</div>
		</form>
    </div>
</div>
<?php
      include('footer.php');
?>
<script>
var selectList = [];
var selectQuestion = function(x){
	if($.inArray(x,selectList)==-1){
		selectList.push(x);
		console.log(selectList);
	}else{
		selectList = jQuery.grep(selectList, function(value) {
		return value != x;});
		console.log(selectList);
	}
}
var calculateMarks = function(){
	var marks = $("#noOfQuestions").val() * $("#marksPerQuestion").val();
	$("#marks").val(marks);
}
$(document).ready(function(){
    $("form[name='exam']").submit(function(){
		var data = $("form").serialize().split("&");
		var obj={};
		for(var key in data)
		{
			obj[data[key].split("=")[0]] = data[key].split("=")[1];
		}
		if(selectList.length>=1){
			obj.questions = JSON.stringify(selectList);
			var data = JSON.stringify(obj);
			console.log(data);
			var success = function(x){
				window.alert(x);
			}
			var url = "server/addexam.php";
			$.ajax({
			  type: "POST",
			  url: url,
			  data: data,
			  success: success,
			  datatype : "text",
			  contentType: "application/json"
			});
		}else{
			window.alert("No Questions Are Selected");
		}
    });
});
var selectExamType = function(examType){
	if(examType==0){
		$("#class").attr('disabled',true);
		$("#subject").attr('disabled',true);
		$("#chapter").attr('disabled',true);
		$("#article").attr('disabled',true);
	}
	if(examType==1){
		$("#class").attr('disabled',false);
		$("#subject").attr('disabled',true);
		$("#chapter").attr('disabled',true);
		$("#article").attr('disabled',true);
	}
	if(examType==2){
		$("#class").attr('disabled',false);
		$("#subject").attr('disabled',false);
		$("#chapter").attr('disabled',true);
		$("#article").attr('disabled',true);
	}
	if(examType==3){
		$("#class").attr('disabled',false);
		$("#subject").attr('disabled',false);
		$("#chapter").attr('disabled',false);
		$("#article").attr('disabled',true);
	}
	if(examType==4){
		$("#class").attr('disabled',false);
		$("#subject").attr('disabled',false);
		$("#chapter").attr('disabled',false);
		$("#article").attr('disabled',false);
	}
}
selectExamType(0);
</script>
</body>
</html>
