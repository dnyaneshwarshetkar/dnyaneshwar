<?php
  include('header.php');
  include('connect.php');
  include('session_teacher.php');
 
	session_start();
	include "connect.php";
	if(isset($_SESSION['username']))
		{
		$mail=$_SESSION['username'];
		$sql1 = "SELECT * FROM teacher where fname='$mail'";
		$result = $con->query($sql1);
		$fname = "";
		$lname = "";    
		$data = array();
		if ($result->num_rows==1) 
			{
			while($row = $result->fetch_assoc()) 
				{
				$fname=$row["fname"];
				$lname=$row["surname"];
				$tid=$row["Teach_id"];
				}
			}  
		} 
		else{
		header("location: index.php");
		}
  if(isset($_GET['Stud_id']))
  {  
	$Stu=$_GET['Stud_id'];
    $sql1 = "SELECT
  `s`.`Stud_id`         AS `Stud_id`,
  `s`.`UDSIE_no`        AS `UDSIE_no`,
  `s`.`Admission_no`    AS `Admission_no`,
  `s`.`First_name`      AS `First_name`,
  `s`.`Middle_name`     AS `Middle_name`,
  `s`.`Last_name`       AS `Last_name`,
  `s`.`Mother_name`     AS `Mother_name`,
  `s`.`Roll_no`         AS `Roll_no`,
  `s`.`Password`        AS `PASSWORD`,
  `s`.`Class_id`        AS `Class_id`,
  `s`.`Address`         AS `Address`,
  `s`.`Status`          AS `STATUS`,
  `p`.`Father_Name`     AS `Father_Name`,
  `p`.`Contact_no`      AS `Contact_no`,
  `d`.`Adhar_No`        AS `Adhar_No`,
  `d`.`DOB`             AS `DOB`,
  `d`.`DOB_Words`       AS `DOB_Words`,
  `d`.`Gender`          AS `Gender`,
  `d`.`Caste`           AS `Caste`,
  `d`.`Subcaste`        AS `Subcaste`,
  `d`.`Religion`        AS `Religion`,
  `d`.`Handicap_status` AS `Handicap_Status`,
  `d`.`Handicap_info`   AS `Handicap_info`,
  `d`.`Place_Birth`     AS `Place_Birth`
FROM ((`student` `s`
    JOIN `parent` `p`
      ON ((`s`.`Stud_id` = `p`.`Parent_id`)))
   JOIN `details` `d`
     ON ((`s`.`Stud_id` = `d`.`Detail_id`))) WHERE s.Stud_id='$Stu'";
    $result = $con->query($sql1);
    $data = array();
    if ($result->num_rows==1) 
    {
      while($row = $result->fetch_assoc()) 
      {  
		$first=$row['First_name'];
		$middle=$row['Middle_name'];
		$last=$row['Last_name'];
		$mother=$row['Mother_name'];
	    $roll=$row['Roll_no'];
		$add=$row['Address'];
		$class=$row['Class_id'];
		$cont=$row['Contact_no'];
		$adhar=$row['Adhar_No'];
		$dob=$row['DOB'];
		$dobw=$row['DOB_Words'];
		$udsie=$row['UDSIE_no'];
		$addno=$row['Admission_no'];
		$gen=$row['Gender'];
		$caste=$row['Caste'];
		$subcaste=$row['Subcaste'];
		$religion=$row['Religion'];
		$handicap_status=$row['Handicap_Status'];
		$handicap_info=$row['Handicap_info'];
		$place_birth=$row['Place_Birth'];
	  }
	}
	
  } 
 
if(isset($_POST['submit']))
  {
	  // STUD TABLER CONTENT
	$uname1=$_GET['Stud_id'];
	$first1=$_POST['first'];
    $middle1=$_POST['middle'];
	$last1=$_POST['last'];
    $mot1=$_POST['mother'];
	$roll1=$_POST['roll'];
	$add1=$_POST['add'];
	$uds1=$_POST['udsei'];
    $adno1=$_POST['addno'];
	$class1=$_POST['std'];
   // $email1=$_POST['email'];
   
   //	DETAILS TABLE CONTENT
   $dobw1=$_POST['dobinw'];						
    $dob1=$_POST['dob'];
    $gen1=$_POST['gen'];
	$adhar1=$_POST['adhar'];
	$caste1=$_POST['cast'];
	$subcaste1=$_POST['subcas'];
	$religion1=$_POST['reli'];
	$handicap_status1=$_POST['hand_status'];
	$handicap_info1=$_POST['hand_info'];
	$place_birth1=$_POST['Place_Birth'];
		
		   
  /*  $sql = "UPDATE student SET First_name='$first1',Middle_name='$middle1',Last_name='$last1',Mother_name='$mot1',
					Roll_no='$roll1',Address='$add1',UDSIE_no='$uds1',Admission_no='$adno1',Class_id='$class1' WHERE Stud_id='$uname1'";		*/
      
	 $sql = "UPDATE student SET First_name='$first1',Middle_name='$middle1',Last_name='$last1',Mother_name='$mot1',
					Roll_no='$roll1',Address='$add1',UDSIE_no='$uds1',Admission_no='$adno1' WHERE Stud_id='$uname1'";
		//	UPDATE details SET Adhar_No='adhar1',DOB_Words='dobw1',DOB='dob1',Gender='gen1',Caste='cas1',Subcaste='subcaste1',Religion='eligion1',Handicap_Status='handicap_status1',Handicap_info='handicap_info1' WHERE Detail_id='23'
	
	$sql1="UPDATE details SET Adhar_No='$adhar1',DOB_Words='$dobw1',DOB='$dob1',Gender='$gen1',Caste='$cas1',Subcaste='$subcaste1',Religion='$religion1',Handicap_Status='$handicap_status1',Handicap_info='$handicap_info1', WHERE Detail_id='$uname1'";
	  
	  if($con->query($sql)){
        echo "<script>alert('Added Succesfully');
         </script>";
		 header("Refresh:0");
      }
      else{
                die('Could not add data'.mysql_error());

      }
  }
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Blank Page</li>
      </ol>
      <form id="form_validation" method="POST" action="">
      <div class="form-row">
          <div class="col-md-4">
                <label for="exampleInputName">First name</label>
                <input class="form-control" id="exampleInputName" type="text" name="first" aria-describedby="nameHelp" value="<?php echo $first; ?>" placeholder="Enter first name">
          </div>
           <div class="col-md-4">
                <label for="exampleInputLastName">Middle name</label>
                <input class="form-control" id="exampleInputLastName" type="text" name="middle" aria-describedby="nameHelp" value="<?php echo $middle; ?>" placeholder="Enter middle name">
           </div>
           <div class="col-md-4">
                <label for="exampleInputLastName">Last name</label>
                <input class="form-control" id="exampleInputLastName" type="text" name="last" aria-describedby="nameHelp" value="<?php echo $last; ?>" placeholder="Enter last name">
           </div>
      
      </div>
   <br>

 <div class="form-row">
              <div class="col-md-4">
                <label for="exampleInputName">Mother name</label>
                <input class="form-control" id="exampleInputName" type="text" name="mother" aria-describedby="nameHelp" value="<?php echo $mother; ?>" placeholder="Enter mother name">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">Phone Number</label>
                <input class="form-control" id="exampleInputLastName" type="text" name="phone" aria-describedby="nameHelp" value="<?php echo $cont; ?>" placeholder="Enter phone number">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">Date Of Birth</label>
                <input class="form-control" id="exampleInputLastName" type="date" name="dob" aria-describedby="nameHelp" value="<?php echo $dob ; ?>" placeholder="<?php echo $dob ; ?>">
              </div>
            </div>
      <br>


 <div class="form-row">
              <div class="col-md-4">
                <label for="exampleInputName">DOB in word</label>
                <input class="form-control" id="exampleInputName" type="text"  name="dobinw" aria-describedby="nameHelp" value="<?php echo $dobw; ?>" placeholder="Enter DOB in word">
              </div>
        <div class="col-md-4">
                <label for="exampleInputLastName">Gender</label>
                <select  name="gen" class="form-control">
               
                   <option value="">Male</option>
                   <option value="">Female</option>
                             
               </select>
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">Place of Birth</label>
                <input class="form-control" id="exampleInputLastName" type="text" name="pob" aria-describedby="nameHelp" value="<?php echo $place_birth; ?>" placeholder="Enter place of birth">
              </div>
            </div>
      <br>

  
 <div class="form-row">
              <div class="col-md-4">
                <label for="exampleInputName">Religion</label>
                <input class="form-control" id="exampleInputName" type="text" name="reli" aria-describedby="nameHelp" value="<?php echo $religion; ?>" placeholder="Enter religion">
              </div>
        <div class="col-md-4">
                <label for="exampleInputLastName">Caste</label>
                <input class="form-control" id="exampleInputLastName" type="text" name="cast" aria-describedby="nameHelp" value="<?php echo $caste; ?>" placeholder="Enter caste">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">Sub Caste</label>
                <input class="form-control" id="exampleInputLastName" type="text" name="subcas" aria-describedby="nameHelp" value="<?php echo $subcaste; ?>" placeholder="Enter subcaste">
              </div>
            </div>
      <br>

  
 <div class="form-row">
        <div class="col-md-4">
                <label for="exampleInputLastName">Roll no</label>
                <input class="form-control" id="exampleInputLastName" type="text" name="roll" aria-describedby="nameHelp" value="<?php echo $middle; ?>" placeholder="Enter Roll no">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">class</label>
                <select  name="std" class="form-control">
                
                   <option value="">1</option>
                   <option value="">2</option>
                             
            </select>
              </div>
            </div>
      <br>

  
 <div class="form-row">
        <div class="col-md-4">
                <label for="exampleInputLastName">Address</label>
                <input class="form-control" id="exampleInputLastName" type="text" name="add" aria-describedby="nameHelp" value="<?php echo $add; ?>" placeholder="Address">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">Handicap Status</label>
                <input class="form-control" id="exampleInputLastName" type="text" name="hand_status"  aria-describedby="nameHelp" value="<?php echo $handicap_status; ?>" placeholder="Handicap status">
              </div>
            </div>
      <br>
  
 <div class="form-row">
              <div class="col-md-4">
                <label for="exampleInputName">Handicap information</label>
                <input class="form-control" id="exampleInputName" type="text" name="hand_info" aria-describedby="nameHelp" value="<?php echo $handicap_info ; ?>" placeholder="Handicap information">
              </div>
              <div class="col-md-4">
                <label for="exampleInputLastName">UDSIE no</label>
                <input class="form-control" id="exampleInputLastName" type="text" name="udsei" aria-describedby="nameHelp" value="<?php echo $udsie ; ?>" placeholder="Enter UDSIE no">
              </div>
			  <div class="col-md-4">
                <label for="exampleInputName">Adhar card no</label>
                <input class="form-control" id="exampleInputName" type="text" name="adhar" aria-describedby="nameHelp" value="<?php echo $adhar ; ?>" placeholder="Enter Adhar card no">
              </div>
            </div>
      <br>

 <div class="form-row">
              <div class="col-md-4">
                <label for="exampleInputLastName">Admission no</label>
                <input class="form-control" id="exampleInputLastName" type="text" name="addno" aria-describedby="nameHelp" value="<?php echo $addno; ?>" placeholder="Admission no">
              </div>
            </div>
      <br>

 <div class="form-row">
    <div class="col-4">
         <br>
            <input type="submit" name="submit" class="btn btn-primary"/>
        </div>
	</div>
        </form>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
  </div>
</body>

</html>
