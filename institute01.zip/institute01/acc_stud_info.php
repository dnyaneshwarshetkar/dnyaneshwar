<?php
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Student Information</li>
      </ol>
      <div class="row">
      <div class="col-md-12">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Name</th>
					<th>Standard</th>
					<th>Id</th>
					<th>Account</th>
					<th>Discount</th>
					<th>Edit</th>
				</tr>

                </thead>
                <tbody>
                <?php
          include('connect.php');
          if(isset($_POST['submit']))
          {
            $std=$_POST['std'];
                $que="SELECT
  `S`.`Stud_id`     AS `Stud_id`,
  `S`.`Class_id`    AS `Class_id`,
  `S`.`First_name`  AS `First_name`,
  `S`.`Middle_name` AS `Middle_name`,
  `S`.`Last_name`   AS `Last_name`,
  `C`.`Class_Name`  AS `Class_Name`
FROM (`student` `S`
   JOIN `class` `C`
     ON ((`S`.`Class_id` = `C`.`Class_id`))) WHERE S.Class_id='$std'";
                $res = $con->query($que);

                  while ($row = $res->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row['First_name']." ".$row['Last_name']."</td>";
                    echo "<td>".$row['Class_Name']."</td>";
                    echo "<td>".$row['Stud_id']."</td>";
                    echo "<td><a href='stud_acc.php?Stud_id=".$row['Stud_id']."'>Account</a></td>";
                    echo "<td><a href='assign_stud1.php?Stud_id=".$row['Stud_id']."'>Discount</a></td>";
                    echo "<td><a href='edit_stud.php?Stud_id=".$row['Stud_id']."'>Edit</a></td>";
					echo "</tr>";
                }
          }
          else{
                $que="SELECT
  `S`.`Stud_id`     AS `Stud_id`,
  `S`.`Class_id`    AS `Class_id`,
  `S`.`First_name`  AS `First_name`,
  `S`.`Middle_name` AS `Middle_name`,
  `S`.`Last_name`   AS `Last_name`,
  `C`.`Class_Name`  AS `Class_Name`
FROM (`student` `S`
   JOIN `class` `C`
     ON ((`S`.`Class_id` = `C`.`Class_id`)))";
                $res = $con->query($que);

                  while ($row = $res->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row['First_name']." ".$row['Last_name']."</td>";
                    echo "<td>".$row['Class_Name']."</td>";
                    echo "<td>".$row['Stud_id']."</td>";
                    echo "<td><a href='stud_acc.php?Stud_id=".$row['Stud_id']."'>Account</a></td>";
                    echo "<td><a href='assign_stud1.php?Stud_id=".$row['Stud_id']."'>Discount</a></td>";
                    echo "<td><a href='edit_stud.php?Stud_id=".$row['Stud_id']."'>Edit</a></td>";
                    echo "</tr>";
                  }
              }
            ?>

                </tbody>
              </table>
            </div>
    </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
