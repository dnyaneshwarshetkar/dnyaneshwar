<?php
  include('header.php');
?>

<script>
	function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
		
</script>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Blank Page</li>
      </ol>
     <form method="POST" action="">
					<div class="row">
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input name="time1" type="date" class="form-control" placeholder="From Date">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-4 col-md-6 col-sm-12">
                               <div class="form-group">
                                    <div class="form-line">
                                        <input name="time2" type="date" class="form-control" placeholder="To Date">
                                    </div>
                                </div>
                            </div>
							<div class="col-lg-4 col-md-6 col-sm-12">
                                <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                            <br><br><br>
							</div>		
					</div>
					</form>
      <br>
      <br>
      <br>
      <br>
	  <div class="row">
		<div class="col-md-4">
			<button id="Somesh" onclick="printDiv('table-responsive')" name="Somesh" class="btn btn-dark">Print</button>
		</div>
	  </div>
	  
    <div class="row">
    
      <div class="col-md-12">
         <div class="card mb-3">
          
          <div class="card-body">
            <div class="table-responsive">
			  <div id="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
    <th>Receipt No</th>
    <th>Date</th>
    <th>Name</th>
	<th>Standard</th>
	<th>Paid Amount</th>
	<th>Print</th>
                  </tr>

                </thead>
                <tbody>
                <?php
				//		exportCol.php
				include('connect.php');
				$tot=0;
				if(isset($_POST['submit']))
					{
						$std1=$_POST['time1'];
						$std2=$_POST['time2'];
						$que="SELECT
  `R`.`Receipt_id`  AS `Receipt_id`,
  `R`.`Stud_id`     AS `Stud_id`,
  `R`.`Paid`        AS `Paid`,
  `R`.`Date`        AS `Date`,
  `S`.`First_name`  AS `First_name`,
  `S`.`Middle_name` AS `Middle_name`,
  `S`.`Last_name`   AS `Last_name`,
  `S`.`Class_id`    AS `Class_id`,
  `C`.`Class_Name`  AS `Class_Name`
FROM ((`receipt` `R`
    JOIN `student` `S`
      ON ((`R`.`Stud_id` = `S`.`Stud_id`)))
   JOIN `class` `C`
     ON ((`S`.`Class_id` = `C`.`Class_id`))) WHERE (Date BETWEEN '$std1' AND '$std2')";
						$res = $con->query($que);

						while ($row = $res->fetch_assoc())
						{
							echo "<tr>";
							echo "<td>".$row['Receipt_id']."</td>";
							echo "<td>".$row['Date']."</td>";
							echo "<td>".$row['First_name']." ".$row['Last_name']."</td>";
							echo "<td>".$row['Class_Name']."</td>";
							echo "<td>".$row['Paid']."</td>";
							$ab=$row['Paid'];
							$tot=$tot+$ab;
							echo "<td><a href='receiptA.php?Receipt_id=".$row['Receipt_id']."'>Print</a></td>";
							echo "</tr>";
						}
					}
			?>  

                </tbody>
              </table>
			  </div>
			</div>
          </div>
          <div class="card-footer small text-muted"></div></div>
          
      
    </div>
    </div>

 
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
