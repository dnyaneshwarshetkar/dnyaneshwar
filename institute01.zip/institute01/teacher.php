<?php
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Teacher List</li>
      </ol>
      <div class="row">
    <div class="col-md-12">
		<div class="table-responsive">
		  <table class="table table-bordered" id="teacherTable" width="100%" cellspacing="0">
		  <caption>Teacher List</caption>
			<thead>
			  <tr>
				<th>Sr.No</th>
				<th>Teacher Name</th>
				<th>Class</th>
				<th>Mobile</th>
				<th>Password</th>
				<th>Status</th>
				<th>Manage</th>
			  </tr>
			</thead>
			<tbody>
			</tbody>
		  </table>
		</div>
    </div>
    
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/teacher.js"></script>
  </div>
</body>

</html>
