<?php
  include('header.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Add Subject</li>
      </ol>
	  <h2>Add Subject</h2>
		<form name="AddSubject">
			<div class="form-group row">
				<label for="class" class="col-sm-2 control-label">Choose Class</label>
				<div class="col-sm-4">
				<select class="form-control custom-select" name="class_id" id="class" onchange="getSubject(this.value)">
					<option value="">Select Class</option>
				</select>
				</div>
				<label for="subject_name" class="col-sm-2 control-label">Subject Name</label>
				<div class="col-sm-4">
					<input type="text" class="form-control" id="subject_name" name="subject_name" placeholder="Enter Subject Name">
				</div>
		  </div>
		  <div class="form-group row">
			<div class="col-sm-10 offset-sm-2">
			  <button type="submit" name="submit" value="submit" class="btn btn-success">Submit</button>
			  <button type="reset" class="btn btn-danger">Reset</button>
			</div>
		  </div>
		</form>
    </div>
    <?php
      include('footer.php');
    ?>
  </div>
   <script>
  $(document).ready(function(){
    $("form[name='AddSubject']").submit(function(){
		var data = $("form[name='AddSubject']").serialize().split("&");
		var obj={};
		for(var key in data)
		{
			obj[data[key].split("=")[0]] = data[key].split("=")[1];
		}
        var data = JSON.stringify(obj);
		console.log(data);
		var success = function(x){
			console.log(x);
		}
		var url = "server/addsubject.php";
		$.ajax({
		  type: "POST",
		  url: url,
		  data: data,
		  success: success,
		  datatype : "text",
		  contentType: "application/json"
		});
    });
});
  </script>
</body>
</html>
