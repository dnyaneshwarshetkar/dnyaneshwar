<?php
   include('header.php');
   include('session_teacher.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('teachersidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Blank Page</li>
      </ol>
      <div class="row">

      <div class="col-md-12">
         <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-table"></i> Teacher Timetable</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th> Time </th>
                    <th> Class Name </th>
                    </tr>

                </thead>
                <tbody>
               <?php
	include('connect.php');
	
	$sql1 = "SELECT
  `T`.`Time`       AS `Time`,
  `T`.`Class_id`   AS `Class_id`,
  `T`.`Teach_id`   AS `Teach_id`,
  `C`.`Class_Name` AS `Class_name`
FROM (`timetable` `T`
   JOIN `class` `C`
     ON ((`T`.`Class_id` = `C`.`Class_id`))) WHERE T.Teach_id='$tid'";
    $result = $con->query($sql1);
    while($row = $result->fetch_assoc()) 
      {
		echo "<tr>"; 
		echo "<td>".$row['Time']."</td>";
		echo "<td>".$row['Class_name']."</td>";
		echo "</tr>";
      }
  ?>

                </tbody>
              </table>
		</div>
          </div>
          <div class="card-footer small text-muted"></div></div>
          </div>
      
    </div>
        
      </div>
      

 
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
