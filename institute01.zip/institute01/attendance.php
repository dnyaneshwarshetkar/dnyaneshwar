<?php
  include('header.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Attendance</li>
      </ol>
	<?php if(isset($_GET['att_id'])){ ?>
    <form name="attendanceForm" onsubmit="return submitData(event,<?php echo $_GET['att_id']?>)" id="attendanceForm">
	<?php }else{ ?>
	<form name="attendanceForm" onsubmit="return submitData(event)" id="attendanceForm">
	<?php } ?>
		<div class="form-group row">
			<label for="class" class="col-sm-1 col-form-label">Class</label>
			<div class="col-sm-3">
			  <select class="form-control" name="class_id" id="class" onchange="getStudents(this.value)">
					<option value="">Select Class</option>
				</select>
			</div>
			<label for="date" class="col-sm-1 col-form-label">Date</label>
			<div class="col-sm-3">
			  <input type="date" class="form-control" name="date" id="date" readonly>
			</div>
		</div>
	</form>
	<div class="table-responsive mt-2">
	  <table class="table table-bordered" id="attendanceTable" width="100%" cellspacing="0">
		<thead>
		  <tr>
			<th>Sr. No.</th>
			<th>Student Name</th>
			<th>Attendance</th>
		  </tr>
		</thead>
		<tbody>
		</tbody>
	  </table>
	</div>
	</div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/attendance.js"></script>
</body>

</html>
