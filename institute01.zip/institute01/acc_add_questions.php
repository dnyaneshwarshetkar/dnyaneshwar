<?php
  include('header.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Add Question</li>
      </ol>
		<?php if(isset($_GET['question_id'])){ ?>
      <form name="addQuestion" method="post" onsubmit="return submitData(event,<?php echo $_GET['question_id']?>)" id="addQuestion" enctype="multipart/form-data">
	  <?php }else{ ?>
	  <form name="addQuestion" method="post" onsubmit="return submitData(event)" id="addQuestion" enctype="multipart/form-data">
	  <?php } ?>
			<div class="form-group row">
				<label for="class" class="col-sm-1 control-label">Class</label>
				<div class="col-sm-2">
				<select class="form-control custom-select" name="class_id" id="class" onchange="getSubject(this.value)">
					<option value="">Select Class</option>
				</select>
				</div>
				<label for="subject" class="col-sm-1 control-label">Subject</label>
				<div class="col-sm-2">
				<select class="form-control custom-select" name="subject_id" id="subject" onchange="getChapter(this.value)">
			<option value="">Select Subject</option>
			</select>
				</div>
				<label for="chapter_id" class="col-sm-1 control-label">Chapters</label>
				<div class="col-sm-2">
				<select class="form-control custom-select" name="chapter_id" id="chapter" onchange="getArticle(this.value)">
				<option value="">Select Chapter</option>
			</select>
				</div>
				<label for="chapter_id" class="col-sm-1 control-label">Article</label>
				<div class="col-sm-2">
					<select class="form-control custom-select" name="article_id" id="article">
					<option value="">Select Article</option>
					</select>
				</div>
			</div>
			<div class="form-group row">
				<label for="question_type" class="col-sm-2 control-label">Question Type</label>
				<div class="col-sm-4">
					<select class="form-control custom-select" name="question_type" id="question_type" onchange="questionType(this.value)">
					<option value="">Question Type</option>
					<option value="text">Text Only</option>
					<option value="image">Image Only</option>
					<option value="textimage">Text Image Only</option>
					</select>
				</div>
				<label for="option_type" class="col-sm-2 control-label">Option Type</label>
				<div class="col-sm-4">
					<select class="form-control custom-select" name="option_type" id="option_type"onchange="optionType(this.value)">
						<option value="">Option Type</option>
						<option value="text">Text Only</option>
						<option value="image">Image Only</option>
						<option value="textimage">Text Image Only</option>
					</select>
				</div>
			</div>
		  <div class="form-group row">
			<label for="Question" class="col-sm-2 control-label">Question</label>
			<div class="col-sm-4">
				<textarea type="text" class="form-control" id="Question" name="question"placeholder="Enter Question"></textarea>
			</div>
			<label for="questionImage" class="col-sm-2 control-label">Question Image</label>
			<div class="col-sm-2">
				<input type="file" class="form-control" id="questionImage" name="question_image" placeholder="Enter Question"/>
			</div>
			<div class="col-sm-2">
				<img id="qi" class="img-thumbnail qimg"/>
			</div>
		  </div>
		  <div class="form-group row">
			<label for="optionA" class="col-sm-2 control-label">Option A</label>
			<div class="col-sm-4">
			<textarea class="form-control" id="optionA" name="optionA"placeholder="Enter OptionA"></textarea>
			</div>
			<label for="optionAImage" class="col-sm-2 control-label">Option A Image</label>
			<div class="col-sm-2">
			<input type="file" class="form-control" id="optionAImage" name="optionA_image"placeholder="Enter OptionA"/>
			</div>
			<div class="col-sm-2">
				<img id="oai"class="img-thumbnail qimg"/>
			</div>
		  </div>
		  <div class="form-group row">
			<label for="optionB" class="col-sm-2 control-label">Option B</label>
			<div class="col-sm-4">
			<textarea class="form-control" id="optionB" name="optionB"placeholder="Enter Option B"></textarea>
			</div>
			<label for="optionBImage" class="col-sm-2 control-label">Option B Image</label>
			<div class="col-sm-2">
			<input type="file" class="form-control" id="optionBImage" name="optionB_image"placeholder="Enter OptionB"/>
			</div>
			<div class="col-sm-2">
				<img id="obi" class="img-thumbnail qimg"/>
			</div>
		  </div>
		  <div class="form-group row">
			<label for="optionC" class="col-sm-2 control-label">Option C</label>
			<div class="col-sm-4">
			<textarea  class="form-control" id="optionC" name="optionC"placeholder="Enter Option C"></textarea>
			</div>
			<label for="optionCImage" class="col-sm-2 control-label">Option C Image</label>
			<div class="col-sm-2">
			<input type="file" class="form-control" id="optionCImage" name="optionC_image"placeholder="Enter OptionC"/>
			</div>
			<div class="col-sm-2">
				<img id="oci" class="img-thumbnail qimg"/>
			</div>
		  </div>
		  <div class="form-group row">
			<label for="optionD" class="col-sm-2 control-label">Option D</label>
			<div class="col-sm-4">
			<textarea class="form-control" id="optionD" name="optionD"placeholder="Enter Option D"></textarea>
			</div>
			<label for="optionDImage" class="col-sm-2 control-label">Option D Image</label>
			<div class="col-sm-2">
			<input type="file" class="form-control" id="optionDImage" name="optionD_image"placeholder="Enter OptionD"/>
			</div>
			<div class="col-sm-2">
				<img id="odi" class="img-thumbnail qimg"/>
			</div>
		  </div>
		  <div class="form-group row">
			<label for="correctOption" class="col-sm-2 control-label">Correct Option</label>
			<div class="col-sm-10">
			<select class="form-control custom-select" name="correct_option">
			  <option selected>Select Option</option>
			  <option value="optionA">optionA</option>
			  <option value="optionB">optionB</option>
			  <option value="optionC">optionC</option>
			  <option value="optionD">optionD</option>
			</select>
			</div>
		  </div>
		  <div class="form-group row">
			<label for="reason" class="col-sm-2 control-label">Reason</label>
			<div class="col-sm-10">
			<textarea type="text" class="form-control" id="reason" name="reason" Placeholder="Enter Reason"></textarea>
			</div>
		  </div>
		  <div class="form-group row">
			<div class="col-sm-10 offset-sm-2">
			  <button type="submit" name="submit" value="submit" class="btn btn-success">Submit</button>
			  <button type="reset" class="btn btn-danger">Reset</button>
			</div>
		  </div>
		</form>
    </div>
	</div>
    <?php
      include('footer.php');
    ?>
   <script src="js/addquestion.js">
  </script>
</body>
</html>
