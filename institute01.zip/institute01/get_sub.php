<?php
require_once("connect.php");
if(!empty($_POST["sub_id"])) 
{
$query =mysqli_query($con,"SELECT * FROM subject WHERE Class_id=".$_POST['sub_id']);
?>
<option value="">Select Subject</option>
<?php
while($row=mysqli_fetch_array($query))  
{
?>
<option value="<?php echo $row['Subject_id']; ?>"><?php echo $row["Subject_Name"];?></option>
<?php
}
}
?>
