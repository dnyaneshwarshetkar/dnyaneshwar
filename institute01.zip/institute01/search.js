var getClass = function(){
	var url = "server/get_data.php?class=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(classList){
				classList = JSON.parse(classList);
			    var mySelect = $('#class');
				$.each(classList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['class_id']).html(value['class_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getClass();
var getSubject = function(class_id){
var url  = "server/get_data.php?subject=true&class_id="+class_id;
	$.ajax({
	  type: "GET",
	  url: url,
	  data: null,
	  success: function(subjectList){
			  subjectList = JSON.parse(subjectList);
			  $('#subject').find('option').not(':first').remove()
			  var mySelect = $('#subject');
				$.each(subjectList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['subject_id']).html(value['subject_name']));
				});
		  },
	  datatype : "application/json",
	  contentType: "application/json"
	});
};
var getChapter = function(subject_id){
	var url  = "server/get_data.php?chapter=true&subject_id="+subject_id;
	$.ajax({
	  type: "GET",
	  url: url,
	  data: null,
	  success: function(chapterList){
			  chapterList = JSON.parse(chapterList);
			  $('#chapter').find('option').not(':first').remove()
			  var mySelect = $('#chapter');
				$.each(chapterList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['chapter_id']).html(value['chapter_name']));
				});
		  },
	  datatype : "application/json",
	  contentType: "application/json"
	});

}
var getArticle = function(chapter_id){
	var url = "server/get_data.php?article=true&chapter_id="+chapter_id;
	$.ajax({
	  type: "GET",
	  url: url,
	  data: null,
	  success: function(articleList){
			  articleList = JSON.parse(articleList);
			  $('#article').find('option').not(':first').remove()
			  var mySelect = $('#article');
				$.each(articleList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['article_id']).html(value['article_name']));
				});
		  },
	  datatype : "application/json",
	  contentType: "application/json"
	});
};
var getQuestions = function(){
	console.log($("#examType").val());
	if($("#examType").val()==1){
		var url = "server/get_data.php?question=true&class_id="+$("#class").val();
	}
	if($("#examType").val()==2){
		var url = "server/get_data.php?question=true&subject_id="+$("#subject").val();
	}
	if($("#examType").val()==3){
		var url = "server/get_data.php?question=true&chapter_id="+$("#chapter").val();
	}
	if($("#examType").val()==4){
		var url = "server/get_data.php?question=true&article_id="+$("#article").val();
	}
	$('#questionTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "question_id"
		}, {
			data : "question_id",
		}, {
			data : "question"
		}, {
			data : "optionA"
		},
		{
			data : "optionB"
		},
		{
			data : "optionC"
		},{
			data : "optionD"
		},{
			data : "correct_option"
		}],
		'columnDefs': [{
		   'targets': 1,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   return '<input type="checkbox" name="id[]" value="' + $('<div/>').text(data).html() + '" onclick="selectQuestion(this.value)">';
		   }
		}]
	});
};