<?php
  include('header.php');
?>
<body>
	<div class="container">
	<div class="row">
		<div class="col-sm-9">
			<p>SSC Examination On English</p>
			<p>Class : 10th Subject : Grammer</p>
			<p>Chapter : Tense Article : A</p>
			<hr>
		</div>
		<div class="col-sm-3">
			<p>Spoke Eng </p>
			<p>Leader of English</p>
			<p>Achive Your Goals</p>
			<hr>
		</div>
	</div>
	 <div class="row">
	  <div class="col-sm-9 questionList">
	  </div>
	  <div class="col-sm-3">
		<div class="statusTemplate"></div>
		<p>
			<button class="btn btn-success" data-content="key" data-value="key" onclick="goOn(this.value)">1</button><b>solved</b>
		</p>
		<p>
			<button class="btn btn-success" data-content="key" data-value="key" onclick="goOn(this.value)">2</button><b>unsolved</b>
		</p>
		<div id="countDown">
			01 : 30
		</div>
	  </div>
	</div>
	<script type="text/html" id="status">
		<button class="btn btn-success" data-content="key" data-value="key" onclick="goOn(this.value)"></button>
	</script>
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
    <script src="js/sb-admin-charts.min.js"></script>
	<script src="js/jquery.loadTemplate.min.js"></script>
	 <script src="js/basic.js"></script>
	 <script src="search.js"></script>
</body>
</html>