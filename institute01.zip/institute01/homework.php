<?php
  include('header.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Home Work</li>
      </ol>
	<?php if(isset($_GET['home_id'])){ ?>
    <form name="addhomeworkForm" onsubmit="return submitData(event,<?php echo $_GET['home_id']?>)" id="addhomeworkForm">
	<?php }else{ ?>
	<form name="addhomeworkForm" onsubmit="return submitData(event)" id="addhomeworkForm">
	<?php } ?>
		<div class="form-group row">
			<label for="class" class="col-sm-2 col-form-label">Class</label>
			<div class="col-sm-10">
			  <select class="form-control" name="class_id" id="class" onchange="getSubject(this.value)">
					<option value="">Select Class</option>
				</select>
			</div>
		</div>
		<div class="form-group row">
			<label for="subject" class="col-sm-2 col-form-label">Subject</label>
			<div class="col-sm-10">
			  <select class="form-control" name="subject_id" id="subject">
					<option value="">Select Subject</option>
				</select>
			</div>
		</div>
		<div class="form-group row">
			<label for="date" class="col-sm-2 col-form-label">Date</label>
			<div class="col-sm-10">
			  <input type="date" class="form-control" name="date" id="date">
			</div>
		</div>
		  <div class="form-group row">
			<label for="homework" class="col-sm-2 col-form-label">Home Work</label>
			<div class="col-sm-10">
			  <textarea class="form-control"  rows="4" cols="50" id="homework" name="homework" placeholder="Enter Home Work"></textarea>
			</div>
		  </div>
	  <button type="submit" class="btn btn-primary my-1">Submit</button>
	</form>
	<div class="table-responsive mt-2">
	  <table class="table table-bordered" id="homeworkTable" width="100%" cellspacing="0">
		<thead>
		  <tr>
			<th>Sr. No.</th>
			<th>Teacher</th>
			<th>Class</th>
			<th>Subject</th>
			<th>Homework</th>
			<th>Date</th>
			<th>Manage</th>
		  </tr>
		</thead>
		<tbody>
		</tbody>
	  </table>
	</div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/homework.js"></script>
</body>

</html>
