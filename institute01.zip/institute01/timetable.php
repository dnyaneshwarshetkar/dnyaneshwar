<?php
  include('header.php');
  include('connect.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Time Table</li>
      </ol>
	<?php if(isset($_GET['time_id'])){ ?>
      <form class="form-inline"name="addtimetableForm" onsubmit="return submitData(event,<?php echo $_GET['time_id']?>)" id="addtimetableForm">
	  <?php }else{ ?>
	  <form class="form-inline" name="addtimetableForm" onsubmit="return submitData(event)" id="addtimetableForm">
	  <?php } ?>
	  <div class="form-group">
		<label for="time">Time Slot</label>
		<select name="time" id="time" class="form-control mx-sm-3">
			<option value="">Timeslot</option>
			<option value="08:45-09:45">08:45-09:45</option>
			<option value="09:45-10:25">09:45-10:25</option>
			<option value="10:25-11:05">10:25-11:05</option>
			<option value="11:05-11:30" disabled>11:05-11:30</option>
			<option value="11:30-12:10">11:30-12:10</option>
			<option value="12:10-12:50">12:10-12:50</option>
			<option value="12:50-01:30">12:50-01:30</option>
			<option value="01:30-01:40" disabled>01:30-01:40</option>
			<option value="01:40-02:25">01:40-02:25</option>
			<option value="02:25-03:05">02:25-03:05</option>
		</select>
	  </div>
	  <div class="form-group">
		<label for="class">Class</label>
		<select class="form-control mx-sm-3" name="class_id" id="class" onchange="getSubject(this.value)">
			<option value="">Select Class</option>
		</select>
	  </div>
	  <div class="form-group">
		<label for="subject">Subject</label>
		<select class="form-control mx-sm-3" name="subject_id" id="subject">
				<option value="">Select Subject</option>
		</select>
	  </div>
	  <div class="form-group">
		<label for="teacher">Teacher</label>
		<select class="form-control mx-sm-3" name="teach_id" id="teacher">
				<option value="">Select Teacher</option>
		</select>
	  </div>
	  <button type="submit" class="btn btn-primary my-1">Submit</button>
	</form>
	<div class="table-responsive mt-2">
	  <table class="table table-bordered" id="timeTable" width="100%" cellspacing="0">
		<thead>
		  <tr>
			<th></th>
			<th>Timeslot</th>
			<th>Class</th>
			<th>Subject Name</th>
			<th>Teacher Name</th>
			<th>Manage</th>
		  </tr>
		</thead>
		<tbody>
		</tbody>
	  </table>
	</div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/timetable.js"></script>
</body>

</html>
