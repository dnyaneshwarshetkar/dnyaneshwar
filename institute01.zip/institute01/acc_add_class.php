<?php
  include('header.php');
?>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Add Class</li>
      </ol>
	  <h2>Add Class</h2>
		<form name="AddClass" method="post">
		  <div class="form-group row">
			<label for="class_name" class="col-sm-2 control-label">Class Name</label>
			<div class="col-sm-4">
				<input type="text" class="form-control" id="class_name" name="class_name" placeholder="Enter Class Name" required>
			</div>
		  </div>
		  <div class="form-group row">
			<div class="col-sm-10 offset-sm-2">
			  <button type="submit" name="submit" value="submit" class="btn btn-success">Submit</button>
			  <button type="reset" class="btn btn-danger">Reset</button>
			</div>
		  </div>
		</form>
    </div>
	</div>
<?php
      include('footer.php');
?>
   <script>
  $(document).ready(function(){
    $("form[name='AddClass']").submit(function(){
		var data = $("form").serialize().split("&");
		var obj={};
		for(var key in data)
		{
			obj[data[key].split("=")[0]] = data[key].split("=")[1];
		}
        var data = JSON.stringify(obj);
		var url = "server/addclass.php";
		$.ajax({
		  type: "POST",
		  url: url,
		  data: data,
		  datatype : "application/json",
		  contentType: "application/json",
		  success: function(xyz,status){
			 console.log("HELLO");
			xyz = JSON.parse(xyz);
			alert(xyz.message+" "+status);
		},
		});
    });
});
</script>
</body>
</html>
