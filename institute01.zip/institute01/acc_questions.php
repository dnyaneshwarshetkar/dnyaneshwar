<?php
  include('header.php');
  include('connect.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Questions</li>
      </ol>
            <div class="table-responsive">
              <table class="table table-bordered" id="questionTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
					<th>Sr.No.</th>
                    <th>Class</th>
                    <th>Subject</th>
                    <th>Chapter</th>
					<th>Article</th>
					<th>Question</th>
					<th>Status</th>
					<th>Manage</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
    </div>
	</div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
	<script src="js/question.js"></script>
</body>

</html>
