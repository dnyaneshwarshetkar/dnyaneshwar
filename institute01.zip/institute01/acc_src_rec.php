<?php
  include('header.php');
?>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php
    include('sidebar.php');
  ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Receipts</li>
      </ol>
    <form method="POST" action="">
	  <div class="row">
        <div class="col-4">
        <label for="exampleInputLastName">Class</label>
            <select name="std" class="form-control">
				<option value="">Select Class</option>
				<?php
				  require_once("connect.php");
				  $query =mysqli_query($con,"SELECT * FROM class");
				  while($row=mysqli_fetch_array($query))  
					{
				?>
				<option value="<?php echo $row['Class_id']; ?>"><?php echo $row["Class_Name"];?></option>
				<?php
					}
				?>
			</select>
        </div>
         <div class="col-4">
         <br>
            <input type="submit" name="submit" class="btn btn-primary"/>
        </div>
      </div>
	  </form>
      <div class="row">
      <div class="col-md-12">
         <div class="card mb-3">
          
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
         <tr>
    <th>Receipt No</th>
    <th>Date</th>
    <th>Name</th>
	<th>Standard</th>
	<th>Print</th>
	<th>Cancel</th>
  </tr>

                </thead>
                <tbody>
                  <?php 
				include('connect.php');
				if(isset($_POST['submit']))
					{ 
						$std=$_POST['std'];
						$que="SELECT
  `S`.`First_name`  AS `First_name`,
  `S`.`Middle_name` AS `Middle_name`,
  `S`.`Last_name`   AS `Last_name`,
  `C`.`Class_Name`  AS `Class_name`,
  `C`.`Class_id`    AS `Class_id`,
  `A`.`Datea`       AS `Datea`,
  `A`.`Receipt_id`  AS `Receipt_id`,
  `A`.`Status`      AS `Status`
FROM ((`student` `S`
    JOIN `class` `C`
      ON ((`S`.`Class_id` = `C`.`Class_id`)))
   JOIN `account` `A`
     ON ((`S`.`Stud_id` = `A`.`Stud_id`))) WHERE S.Class_id='$std' AND A.Status='Active'";
						$res = $con->query($que);

						while ($row = $res->fetch_assoc()) {
							echo "<tr>";
							echo "<td>".$row['Receipt_id']."</td>";
							echo "<td>".$row['Datea']."</td>";
							echo "<td>".$row['First_name']." ".$row['Last_name']."</td>";
							echo "<td>".$row['Class_name']."</td>";
							echo "<td><a href='receiptA.php?Receipt_id=".$row['Receipt_id']."'>Print</a></td>";
							echo "<td><a href='cancel.php?Receipt_id=".$row['Receipt_id']."'>Cancel</a></td>";
							echo "</tr>";
						}
					} 
				else 
					{
						$que="SELECT
  `S`.`First_name`  AS `First_name`,
  `S`.`Middle_name` AS `Middle_name`,
  `S`.`Last_name`   AS `Last_name`,
  `C`.`Class_Name`  AS `Class_name`,
  `C`.`Class_id`    AS `Class_id`,
  `A`.`Datea`       AS `Datea`,
  `A`.`Receipt_id`  AS `Receipt_id`,
  `A`.`Status`      AS `Status`
FROM ((`student` `S`
    JOIN `class` `C`
      ON ((`S`.`Class_id` = `C`.`Class_id`)))
   JOIN `account` `A`
     ON ((`S`.`Stud_id` = `A`.`Stud_id`))) WHERE A.Status='Active'";
						$res = $con->query($que);

						while ($row = $res->fetch_assoc()) {
							echo "<tr>";
							echo "<td>".$row['Receipt_id']."</td>";
							echo "<td>".$row['Datea']."</td>";
							echo "<td>".$row['First_name']." ".$row['Last_name']."</td>";
							echo "<td>".$row['Class_name']."</td>";
							echo "<td><a href='receiptA.php?Receipt_id=".$row['Receipt_id']."'>Print</a></td>";
							echo "<td><a href='cancel.php?Receipt_id=".$row['Receipt_id']."'>Cancel</a></td>";
							echo "</tr>";
						} 
					}		
			?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="card-footer small text-muted"></div></div>
          </div>
    </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php
      include('footer.php');
    ?>
  </div>
</body>

</html>
