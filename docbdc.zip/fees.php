<?php include("header.php") ?>
  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="admin.php">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">Fees List</li>

      </ol>
	  
		<div class="btn-group btn-group-sm mb-2" role="group">
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#feesModal">Add Fees</button>
			
		</div>
          <div class="table-responsive">

            <table class="table table-bordered" id="feesTable" width="100%" cellspacing="0">

              <thead>

                <tr>

                  <th>Sr.No</th>

                  <th>Fees Name</th>
				  
				  <th>Amount</th>

                  <th>CGST</th>

                  <th>SGST</th>
				   
				  <th>Total Amount</th>

				  <th>Status</th>
				  
				  <th>Manage</th>

                </tr>

              </thead>

              <tbody>
			  
              </tbody>

            </table>

          </div>
		<!--modal Starts for Medicine-->
		<div class="modal" tabindex="-1" role="dialog" id="feesModal">
		  <div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<form  name="feesForm" id="feesForm" onsubmit="return addFees(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Add Fees</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-6">
					  <label for="fees_name">Fees Name</label>
					  <input type="text" class="form-control" id="fees_name" name="fees_name" placeholder="Enter Fees Name" required />
					</div>
					<div class="form-group col-sm-6">
					  <label for="description">Description</label>
					  <input type="text" class="form-control" id="description" name="description" placeholder="Enter Description"/>
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-6">
					  <label for="amount">Amount</label>
					 <input type="number" class="form-control" id="amount" name="amount" placeholder="Enter Amount" onchange="totalAmount()" required />
					</div>
					<div class="form-group col-sm-6">
					  <label for="total_amount">Total Amount</label>
					  <input type="number" class="form-control" id="total_amount" name="total_amount" placeholder="Enter Total Amount" readonly required />
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-6">
					  <label for="cgst">CGST</label>
					 <input type="number" class="form-control" id="cgst" name="cgst" placeholder="Enter CGST"   onchange="totalAmount()" step="0.01" min="0" max="9" required  aria-describedby="cgstHelpBlock"/>
					 <small id="cgstHelpBlock" class="form-text text-muted">
						  in %
					</small>
					</div>
					<div class="form-group col-sm-6">
					  <label for="cgst_amount">CGST Amount</label>
					  <input type="number" class="form-control" id="cgst_amount" name="cgst_amount" placeholder="Enter CGST Amount" readonly required />
					</div>
				  </div> 
				  <div class="form-row">
					<div class="form-group col-sm-6">
					  <label for="sgst">SGST</label>
					  <input type="number" class="form-control" id="sgst" name="sgst" placeholder="Enter SGST"   onchange="totalAmount()" step="0.01" min="0" max="9" required aria-describedby="sgstHelpBlock"/>
					 <small id="sgstHelpBlock" class="form-text text-muted">
						  in %
					</small>
					</div>
					<div class="form-group col-sm-6">
					  <label for="sgst_amount">SGST Amount</label>
					  <input type="number" class="form-control" id="sgst_amount" name="sgst_amount" placeholder="Enter SGST Amount" readonly required />
					</div>
				  </div>
				</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
    </div>
</div>
<?php include("footer.php"); ?>
<script src="js/fees.js"></script>
</body>

</html>