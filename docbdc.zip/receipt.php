<?php include("header.php") ?>
  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="admin.php">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">Receipt List</li>

      </ol>
	  
		<div class="btn-group btn-group-sm mb-2" role="group">
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#receiptModal">Add Receipt</button>
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#receiptItemModal">Add Receipt Item</button>
		
			
		</div>
          <div class="table-responsive">

            <table class="table table-bordered" id="reciptItemTable" width="100%" cellspacing="0">

              <thead>

                <tr>

                  <th>Sr.No</th>

                  <th>Receipt Item</th>

				  <th>Status</th>
				  
				  <th>Manage</th>

                </tr>

              </thead>

              <tbody>
			  
              </tbody>

            </table>

          </div>
		<!--modal Starts for Medicine-->
		<div class="modal" tabindex="-1" role="dialog" id="receiptModal">
		  <div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<form  name="receiptForm" id="receiptForm" onsubmit="return addReceipt(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Add Receipt</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_name">Patient Name</label>
					  <input type="text" class="form-control" id="patient_name" name="patient_name" placeholder="Enter Patient Name" required />
					</div>
				  </div>
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="address">Address</label>
					  <textarea class="form-control" id="address" name="address" placeholder="Enter Address"></textarea>
					</div>
				  </div>
				   <div class="form-row">
				   <div class="form-group col-sm-6">
					  <label for="admission_date">Admission Date</label>
					  <input type="date" class="form-control" id="admission_date" name="admission_date"/>
					</div>
					<div class="form-group col-sm-6">
					  <label for="discharge_date">Discharge Date</label>
					  <input type="date" class="form-control" id="discharge_date" name="discharge_date"/>
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_name">Patient Name</label>
					  <input type="text" class="form-control" id="patient_name" name="patient_name" placeholder="Enter Patient Name" required />
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_name">Patient Name</label>
					  <input type="text" class="form-control" id="patient_name" name="patient_name" placeholder="Enter Patient Name" required />
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_name">Patient Name</label>
					  <input type="text" class="form-control" id="patient_name" name="patient_name" placeholder="Enter Patient Name" required />
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_name">Patient Name</label>
					  <input type="text" class="form-control" id="patient_name" name="patient_name" placeholder="Enter Patient Name" required />
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_name">Patient Name</label>
					  <input type="text" class="form-control" id="patient_name" name="patient_name" placeholder="Enter Patient Name" required />
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_name">Patient Name</label>
					  <input type="text" class="form-control" id="patient_name" name="patient_name" placeholder="Enter Patient Name" required />
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_name">Patient Name</label>
					  <input type="text" class="form-control" id="patient_name" name="patient_name" placeholder="Enter Patient Name" required />
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_name">Patient Name</label>
					  <input type="text" class="form-control" id="patient_name" name="patient_name" placeholder="Enter Patient Name" required />
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_name">Patient Name</label>
					  <input type="text" class="form-control" id="patient_name" name="patient_name" placeholder="Enter Patient Name" required />
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_name">Patient Name</label>
					  <input type="text" class="form-control" id="patient_name" name="patient_name" placeholder="Enter Patient Name" required />
					</div>
				  </div>
				</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
		<!--modal Starts for Medicine-->
		<div class="modal" tabindex="-1" role="dialog" id="receiptItemModal">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form  name="receiptItemForm" id="receiptItemForm" onsubmit="return addReceiptItem(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Add Receipt Item</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="receipt_item_name">Receipt Item Name</label>
					  <input type="text" class="form-control" id="receipt_item_name" name="receipt_item_name" placeholder="Enter Recipt Item Name" required />
					</div>
				  </div>
				</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
    </div>
</div>
<?php include("footer.php"); ?>
<script src="js/receipt.js"></script>
</body>

</html>