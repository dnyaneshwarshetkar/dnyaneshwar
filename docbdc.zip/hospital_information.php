<?php include("header.php");?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="admin.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Hospital Information</li>
      </ol>
		<form name="addForm" onsubmit="return submitData(event)"  id="addForm" enctype="multipart/form-data">
		  <div class="form-row">
			<div class="form-group col-sm-6">
			  <label for="hospital_name">Hospital Name</label>
			  <input type="text" class="form-control" id="hospital_name" name="hospital_name" placeholder="Enter Hospital Information" required>
			</div>
			<div class="form-group col-sm-6">
			  <label for="director">Director</label>
			  <input type="text" class="form-control" id="director" name="director" placeholder="Enter Director" required>
			</div>
		  </div>
		  <div class="form-row">
			<div class="form-group col-sm-3">
			  <label for="logo1">Logo 1</label>
			  <input type="file" class="form-control" id="logo1" name="logo1" placeholder="Choose Logo1">
			</div>
			<div class="col-sm-3">
				<img id="logo1" class="img-thumbnail profimg" src="images/exam.jpg"/>
			</div>
			<div class="form-group col-md-3">
			  <label for="logo2">Logo 2</label>
			  <input type="file" class="form-control" id="logo2" name="logo2" placeholder="Choose Logo2">
			</div>
			<div class="col-sm-3">
				<img id="logo2" class="img-thumbnail profimg" src="images/exam.jpg"/>
			</div>
		  </div>
		<div class="form-row">
			<div class="form-group col-sm-6">
			  <label for="address">Address</label>
			  <textarea type="text" class="form-control" id="address" name="address" placeholder="Enter Address"></textarea>
			</div>
			<div class="form-group col-sm-6">
				<label for="tq">Tq.</label>
				<input type="text" class="form-control" name="tq" id="tq" placeholder="Enter Tq."/>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-sm-6">
			  <label for="district">District</label>
			  <input type="text" class="form-control" name="district" id="district" placeholder="Enter District"/>
			</div>
			<div class="form-group col-md-6">
			  <label for="state">State</label>
			  <input type="text" class="form-control" name="state" id="state" placeholder="Enter State"/>
			</div>
		  </div>
		  <button type="submit" class="btn btn-primary">Submit</button>
	  </form>
    </div>
	 </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
	<?php include("footer.php"); ?>
	<script src="js/hospital_information.js"></script>
</body>

</html>
