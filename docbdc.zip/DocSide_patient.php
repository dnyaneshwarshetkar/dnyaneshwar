<?php

  session_start();

  require "connect.php";

  if(isset($_SESSION['username']))

  {

    $uname=$_SESSION['username'];

    $sql1 = "SELECT * FROM doctor where Doctor_id='$uname'";

    $result = $con->query($sql1);

    $fname = "";

    $lname = "";    

      $data = array();

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $fname=$row["fname"];

        $lname=$row["lname"];

        }

    }  

  } 

  else{

    header("location: index.php");

    }   

?>

<!DOCTYPE html>

<html lang="en">



<head>

  <meta charset="utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta name="description" content="">

  <meta name="author" content="">

  <title> Dashboard | HMIS </title>

  <!-- Bootstrap core CSS-->

  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template-->

  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->

  <link href="css/sb-admin.css" rel="stylesheet">

</head>



<body class="fixed-nav sticky-footer bg-dark" id="page-top">

  <!-- Navigation-->

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">

    <a class="navbar-brand" href="index.html"><?php echo $fname." ".$lname; ?></a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">

      <span class="navbar-toggler-icon"></span>

    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">

      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">

          <a class="nav-link" href="admin.php">

            <i class="fa fa-fw fa-dashboard"></i>

            <span class="nav-link-text">Dashboard</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">

          <a class="nav-link" href="bed.php">

            <i class="fa fa-fw fa-table"></i>

            <span class="nav-link-text">Bed Allotment</span>

          </a>

        </li>

            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">

          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseMulti" data-parent="#exampleAccordion">

            <i class="fa fa-fw fa-sitemap"></i>

            <span class="nav-link-text">Registration</span>

          </a>

          <ul class="sidenav-second-level collapse" id="collapseMulti">

            <li>

              <a href="addDoc.php">New Docter</a>

            </li>

            <li>

              <a href="addNurse.php">New Nurse</a>

            </li>

            <li>

              <a href="#">New Compounder</a>

            </li>

          </ul>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="profile.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Profile</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="password.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Change Password</span>

          </a>

        </li>

      </ul>

      <ul class="navbar-nav sidenav-toggler">

        <li class="nav-item">

          <a class="nav-link text-center" id="sidenavToggler">

            <i class="fa fa-fw fa-angle-left"></i>

          </a>

        </li>

      </ul>

      <ul class="navbar-nav ml-auto">

        <li class="nav-item">

          <form class="form-inline my-2 my-lg-0 mr-lg-2">

            <div class="input-group">

              <input class="form-control" type="text" placeholder="Search for...">

              <span class="input-group-btn">

                <button class="btn btn-primary" type="button">

                  <i class="fa fa-search"></i>

                </button>

              </span>

            </div>

          </form>

        </li>

        <li class="nav-item">

          <a class="nav-link" href="logout.php">

            <i class="fa fa-fw fa-sign-out"></i>Logout</a>

        </li>

      </ul>

    </div>

  </nav>

  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="index.html">Dashboard</a>

        </li>

        <li class="breadcrumb-item active"> Doctor Homepage </li>

      </ol>

	  <br>

	  <!-- Test Part-->

		<div class="row">

        <div class="col-xl-3 col-sm-6 mb-3">

          <div class="card text-white bg-primary o-hidden h-100">

            <div class="card-body">

              <div class="card-body-icon">

                <i class="fa fa-fw fa-comments"></i>

              </div>

              <div class="mr-5"><b>X-Ray Test</b></div>

            </div>

            <a class="card-footer text-white clearfix small z-1" href="#">

              <span class="float-left">Send For X-Ray Test</span>

              <span class="float-right">

                <i class="fa fa-angle-right"></i>

              </span>

            </a>

          </div>

        </div>

        <div class="col-xl-3 col-sm-6 mb-3">

          <div class="card text-white bg-warning o-hidden h-100">

            <div class="card-body">

              <div class="card-body-icon">

                <i class="fa fa-fw fa-list"></i>

              </div>

              <div class="mr-5"><b>Urine Test </b></div>

            </div>

            <a class="card-footer text-white clearfix small z-1" href="#">

              <span class="float-left">Send For Urine Test</span>

              <span class="float-right">

                <i class="fa fa-angle-right"></i>

              </span>

            </a>

          </div>

        </div>

        <div class="col-xl-3 col-sm-6 mb-3">

          <div class="card text-white bg-success o-hidden h-100">

            <div class="card-body">

              <div class="card-body-icon">

                <i class="fa fa-fw fa-shopping-cart"></i>

              </div>

              <div class="mr-5"><b>Sonography</b></div>

            </div>

            <a class="card-footer text-white clearfix small z-1" href="#">

              <span class="float-left">Send For Sonography</span>

              <span class="float-right">

                <i class="fa fa-angle-right"></i>

              </span>

            </a>

          </div>

        </div>

        <div class="col-xl-3 col-sm-6 mb-3">

          <div class="card text-white bg-danger o-hidden h-100">

            <div class="card-body">

              <div class="card-body-icon">

                <i class="fa fa-fw fa-support"></i>

              </div>

              <div class="mr-5"><b>Blood Test</b></div>

            </div>

            <a class="card-footer text-white clearfix small z-1" href="#">

              <span class="float-left">Send For Blood Test</span>

              <span class="float-right">

                <i class="fa fa-angle-right"></i>

              </span>

            </a>

          </div>

        </div>

      </div>

	  

	  <!-- end- Test Part-->

	  

	  

      <div class="row">

        <div class="col-12">

          <h3>Patient ID = 111</h3>

     
		  <br>

		  <form>

			<div class="form-group">

            <div class="form-row">

              <div class="col-md-4">

                <label for="exampleInputName">First name</label>

                <input class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name">

              </div>

			  <div class="col-md-4">

                <label for="exampleInputLastName">Middle name</label>

                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter middle name">

              </div>

              <div class="col-md-4">

                <label for="exampleInputLastName">Last name</label>

                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter last name">

              </div>

            </div>

			<br>

			<div class="form-row">

			  <div class="col-md-3">

                <label for="exampleInputName">Date of Birth</label>

                <input class="form-control" id="exampleInputName" type="date" aria-describedby="nameHelp" placeholder="Enter Date">

              </div>

			  <div class="col-md-3">

                <label for="exampleInputName">Gender</label>

                <select class="form-control" id="exampleInputName" aria-describedby="nameHelp">

					<option value="Male">Male</option>

					<option value="Female">Female</option>

				</select>

              </div>

			  <div class="col-md-3">

                <label for="exampleInputName">Age</label>

                <input class="form-control" id="exampleInputName" type="number" aria-describedby="nameHelp" placeholder="Enter Date">

              </div>

			  <div class="col-md-3">

                <label for="exampleInputName">Maritial Status</label>

                <select class="form-control" id="exampleInputName" aria-describedby="nameHelp">

					<option value="Married">Married</option>

					<option value="Unmarried">Unmarried</option>

				</select>

              </div>

            </div>

			<br>

			<div class="form-row">

			  <div class="col-md-4">

				<label for="exampleInputName">Contact No.</label>

                <input class="form-control" id="exampleInputName" type="number" aria-describedby="nameHelp" placeholder="Enter Number">

              </div>

			  <div class="col-md-8">

				<label for="exampleInputName">Address</label>

                <input class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter Address">

              </div>

			</div>

          </div>

		  <br><br>

		  <div class="form-row">

			<div class="col-md-6">

				<label for="exampleInputName">Allot Doctor</label>

                <input class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter Doctor">

              </div>

		  </div>

		  

		  <br><br>

        </form>

		  

		  

		  

			

		

		

		</div>

      </div><!-- row-->

	  

		  

		  <br><br>

		<h3> Basic Info & Symptons</h3>

	  <div class="form-row">



		<div class="col-md-3">

			<label for="exampleInputName">Height</label>

            <input class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="Height in cm">

		</div>

		<div class="col-md-3">

			<label for="exampleInputName">Weight</label>

            <input class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="Weight in kg">				

		</div>

		<div class="col-md-3">

			<label for="exampleInputName">Temprature</label>

            <input class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="Temparature in Fh">			

		</div>

		<div class="col-md-3">

			<label for="exampleInputName">Blood Pressure</label>

            <input class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="BP in mmHg">  			

		</div>

	  </div>

        <br>

        <div class="form-row">



		<div class="col-md-6">

			<label for="exampleInputName">Symtoms</label>

            <select class="form-control" id="exampleInputName" aria-describedby="nameHelp" multiple>

				<option value="a">a</option>

				<option value="b">b</option>

				<option value="c">c</option>

				<option value="d">d</option>

				<option value="e">e</option>

				<option value="f">f</option>

			</select>

		</div>

		<div class="col-md-4">

						

		</div>

		<div class="col-md-2">

			

			

		</div>

	  </div>

        <br>

                <a class="btn btn-primary" href="#">Add</a>



	  <br><br>

	  <h3> Prescription </h3>

	  <div class="form-row">



		<div class="col-md-6">

			<label for="exampleInputName">Prescription</label>

			<input class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Add">

		</div>

		<div class="col-md-4">

						

		</div>

		<div class="col-md-2">

			

			

		</div>

	  </div>

        <br>

                <a class="btn btn-primary" href="#">Add</a>



	  <br><br>

	  <h3> Medication </h3>

	  <div class="form-row">



		<div class="col-md-6">

			<label for="exampleInputName">Name</label>

			<input class="form-control" id="exampleInputName" type="name" aria-describedby="nameHelp" placeholder="Medicine Name">

		</div>

		

		<div class="col-md-4">

			<label for="exampleInputName">Dosage</label>

			<select class="form-control" id="exampleInputName" aria-describedby="nameHelp">

				<option value="c">once a day</option>

				<option value="a">twice a day</option>

				<option value="b">thrice a day</option>

				<option value="d">once in two day</option>

				<option value="e">once a week</option>

				<option value="f">as per told</option>

			</select>

		</div>

		<div class="col-md-2">

			<label for="exampleInputName">Quantity</label>

			<input class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="Medicine Quantity">

		</div>

	  </div>    <br>

                <a class="btn btn-primary" href="#">Add</a>



	  <br><br><br><br><br><br>

    </div>

    <!-- /.container-fluid-->

    <!-- /.content-wrapper-->

	

		  

		  <br><br>

		  

		  <br><br>

    <footer class="sticky-footer">

      <div class="container">

        <div class="text-center">

              <small>Copyright © <a href="http://nishthaventures.com/"> nishthaventures.com  2018 </a> </small>

        </div>

      </div>

    </footer>

    <!-- Scroll to Top Button-->

    <a class="scroll-to-top rounded" href="#page-top">

      <i class="fa fa-angle-up"></i>

    </a>

    <!-- Bootstrap core JavaScript-->

    <script src="vendor/jquery/jquery.min.js"></script>

    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->

    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->

    <script src="js/sb-admin.min.js"></script>

  </div>

</body>



</html>

