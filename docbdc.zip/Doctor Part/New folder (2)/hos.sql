-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2017 at 12:03 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hos`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `acc_id` int(30) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `specification` varchar(20) NOT NULL,
  `exp` int(10) NOT NULL,
  `Degree` varchar(20) NOT NULL,
  `dob` date DEFAULT NULL,
  `Contact_No` bigint(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `salary` int(20) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`acc_id`, `fname`, `lname`, `specification`, `exp`, `Degree`, `dob`, `Contact_No`, `password`, `salary`, `status`) VALUES
(200, 'a', 'a', 'cashier', 0, 'lkj', '2017-11-01', 9856321470, 'asdfgh', 0, 'active'),
(201, 'sca', 'sca', 'Receptinist', 0, 'gfd', NULL, 95632, '', 0, 'active\r\n'),
(202, 'pikachu', 'yhu', 'Cashier', 7, 'mnhj', NULL, 985632, '', 0, 'active'),
(203, 'fvy', 'hgv', 'Cashier', 2, 'ghj', NULL, 6565, '', 0, 'active'),
(204, 'pqr', 'sjjd', 'Accountant', 1, 'bcom', NULL, 123456, '', 0, 'active'),
(205, '', '', 'Cashier', 0, '', NULL, 0, '', 0, 'active'),
(206, 'ereree', 'jsjsj', 'Cashier', 11, 'dmndjnd', NULL, 0, '', 0, 'active'),
(207, 'gygj', 'hjhjjh', 'Receptinist', 12, 'nhnn', NULL, 23443, '', 0, 'active'),
(208, '', '', 'Cashier', 0, '', NULL, 0, '', 0, 'active'),
(209, 'dsjndj', 'nnndm,n,', 'Nurse', 12000, 'bsc', NULL, 32, '', 0, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `acc_stock`
--

CREATE TABLE `acc_stock` (
  `emp_id` int(20) NOT NULL,
  `name` text NOT NULL,
  `assets` varchar(50) NOT NULL,
  `price` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acc_stock`
--

INSERT INTO `acc_stock` (`emp_id`, `name`, `assets`, `price`) VALUES
(1, 'jj', 'mkl', 12),
(2, 'gjgjj', 'asset', 55),
(3, '', 'medicines', 0),
(4, 'rrr', 'injection', 20);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_id` varchar(30) NOT NULL,
  `Pass` varchar(30) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `dob` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_id`, `Pass`, `fname`, `lname`, `dob`) VALUES
('admin', 'admin', 'Umakant', 'Manke', '1995-05-03');

-- --------------------------------------------------------

--
-- Table structure for table `allot`
--

CREATE TABLE `allot` (
  `Patient_id` int(20) NOT NULL,
  `bed_id` int(20) NOT NULL,
  `allot_time` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `allot`
--

INSERT INTO `allot` (`Patient_id`, `bed_id`, `allot_time`, `status`) VALUES
(103, 1001, '0000-00-00 00:00:00.000', ''),
(103, 1001, '0000-00-00 00:00:00.000', ''),
(108, 1001, '0000-00-00 00:00:00.000', ''),
(109, 1002, '2017-12-02 01:27:20.000', ''),
(110, 1002, '2017-12-02 05:59:33.000', ''),
(108, 1001, '2017-12-02 06:00:49.000', 'Occupied'),
(108, 1001, '2017-12-02 06:15:16.000', 'Occupied'),
(105, 1003, '2017-12-02 06:16:53.000', 'Occupied');

-- --------------------------------------------------------

--
-- Table structure for table `bed`
--

CREATE TABLE `bed` (
  `bed_id` int(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `bed_type` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bed`
--

INSERT INTO `bed` (`bed_id`, `status`, `bed_type`) VALUES
(1001, 'Ocupied108', 'Normal'),
(1002, '', 'Normal'),
(1003, 'Ocupied105', 'Normal'),
(1004, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `blood_bank`
--

CREATE TABLE `blood_bank` (
  `name` text NOT NULL,
  `age` int(10) NOT NULL,
  `gender` text NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood_bank`
--

INSERT INTO `blood_bank` (`name`, `age`, `gender`, `blood_group`, `status`) VALUES
('rygv', 52, 'gyhn', 'A+', 'active'),
('ftgybh', 30, 'assx', 'B-', 'active'),
('wdwd', 19, 'male', 'A+', 'active'),
('Abcdefg', 45, 'female', 'A+', 'active'),
('pikachu', 22, 'male', 'B+', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `consulted`
--

CREATE TABLE `consulted` (
  `doctor_id` int(11) NOT NULL,
  `docname` int(11) NOT NULL,
  `specilization` int(11) NOT NULL,
  `patient_name` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `consulting`
--

CREATE TABLE `consulting` (
  `doctor_id` int(20) NOT NULL,
  `doc_name` text NOT NULL,
  `specialisation` text NOT NULL,
  `patient_name` text NOT NULL,
  `fees` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `consulting`
--

INSERT INTO `consulting` (`doctor_id`, `doc_name`, `specialisation`, `patient_name`, `fees`) VALUES
(1, 'pqer', 'cardio', 'ssssss', 1200),
(2, 'pqsr', 'card', 'ssss', 1220),
(3, 'jhgf', 'neuro', 'hhgjh', 1223),
(4, 'jhgf', 'neuro', 'hhgjh', 1224);

-- --------------------------------------------------------

--
-- Table structure for table `cost`
--

CREATE TABLE `cost` (
  `test` varchar(30) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cost`
--

INSERT INTO `cost` (`test`, `price`) VALUES
('blood', 100),
('Urine', 70),
('X-ray', 150),
('Sonography', 200);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `Doctor_id` int(30) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `img` blob NOT NULL,
  `email` varchar(20) NOT NULL,
  `specification` varchar(30) NOT NULL,
  `exp` int(5) NOT NULL,
  `Degree` varchar(30) NOT NULL,
  `dob` date DEFAULT NULL,
  `Contact_No` bigint(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `salary` float NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`Doctor_id`, `fname`, `lname`, `img`, `email`, `specification`, `exp`, `Degree`, `dob`, `Contact_No`, `password`, `salary`, `status`) VALUES
(1, 'Vipul', 'Sarang', '', '', 'Child', 2, 'B.A.M.S.', NULL, 123626, '', 0, ''),
(701, 'Somesh', 'Arewar', '', '', 'Cardiologist', 0, 'M.S.', '1995-03-08', 9011047390, 'pqr', 0, ''),
(702, 'jcb', 'jls', '', '', 'bmn', 2, 'mmb', NULL, 852, '', 0, ''),
(703, 'VipulS', 'Sarang', '', '', 'Child', 2, 'bams', NULL, 75698231, 'abc', 0, ''),
(704, 'ZZ', 'ZZ', '', '', 'ZZ', 2, 'ZZ', NULL, 852369, '', 0, ''),
(705, 'pika', 'pika', '', '', 'bone', 5, 'mbbs', NULL, 985632569, 'abc', 0, ''),
(706, 'jj', 'jj', '', '', 'mjh', 7, 'mjk', NULL, 852, '', 0, ''),
(707, 'IKJUpIi', 'jkmk', '', '', 'ijm', 6, 'gvhb', NULL, 85236, '', 0, 'active'),
(708, 'asd', 'asdadc', 0x73696c686f75657474652d323430323939315f3936305f3732302e706e67, 'dasd@zscj.com', 'bone', 2, 'ms', NULL, 12321232, '', 0, 'active'),
(709, 'dsa', 'sa', 0x646576696365735f62616e6e65722e706e67, 'sasd@df.com', 'mjk', 1, 'sac', NULL, 45632, '', 0, 'active'),
(710, 'saxs', 'saca', 0x3733393931362d617765736f6d652d6261636b67726f756e642d696d616765732e6a7067, 'asd@kjm.com', 'gh', 25, 'vhbn', NULL, 8645132, '', 0, 'active'),
(711, 'fgh', 'hgf', 0x3733393931362d617765736f6d652d6261636b67726f756e642d696d616765732e6a7067, 'csdv@m.com', 'ikm', 2, 'mbbs', NULL, 90909, '', 0, 'active'),
(712, 'asq', 'qsa', 0x62616e6e65722d313335333834375f3936305f3732302e6a7067, 'dfz@h.com', 'dfb', 2, 'n  km', NULL, 78965, '', 0, 'active'),
(713, 'asq', 'qsa', 0x62616e6e65722d313335333834375f3936305f3732302e6a7067, 'dfz@h.com', 'dfb', 2, 'n  km', NULL, 78965, '', 0, 'active'),
(714, 'cbvn', 'gvhb', 0x686f6d652d6f66666963652d3333363337335f3936305f3732302e6a7067, 'mk@hj.com', 'vgbh', 0, 'hb ', NULL, 789098778, '', 0, 'active'),
(715, 'cbvn', 'gvhb', 0x686f6d652d6f66666963652d3333363337335f3936305f3732302e6a7067, 'mk@hj.com', 'vgbh', 0, 'hb ', NULL, 789098778, '', 0, 'active'),
(716, 'gwjgdhj', 'jjjsj', 0x62616e6e65722d313335333834375f3936305f3732302e6a7067, 'mshjwwj@gmail.com', 'ms', 0, 'dsjhdjs', NULL, 787878, '', 0, 'active'),
(717, 'gwjgdhj', 'jjjsj', 0x62616e6e65722d313335333834375f3936305f3732302e6a7067, 'mshjwwj@gmail.com', 'ms', 0, 'dsjhdjs', NULL, 787878, '', 0, 'active'),
(718, 'gwjgdhj', 'jjjsj', '', 'mshjwwj@gmail.com', 'ms', 0, 'dsjhdjs', NULL, 787878, '', 0, 'active'),
(719, 'yfgjgjeh', 'ehghg', '', 'Admin@gmial.com', 'ad', 12, 'mbbs', NULL, 12345678, '', 0, 'active'),
(720, 'yfgjgjeh', 'ehghg', 0x62696e6172792d323338303432325f3936305f3732302e6a7067, 'Admin@gmial.com', 'ad', 12, 'mbbs', NULL, 12345678, '', 0, 'active'),
(721, 'vghygjh', 'jhjh', 0x62696e6172792d323338303432325f3936305f3732302e6a7067, 'Admin@gmial.com', 'hgjh', 1, 'ghgh', NULL, 2221, '', 0, 'active'),
(722, 'vghygjh', 'jhjh', 0x62696e6172792d323338303432325f3936305f3732302e6a7067, 'Admin@gmial.com', 'hgjh', 1, 'ghgh', NULL, 2221, '', 0, 'active'),
(723, 'vghygjh', 'jhjh', 0x62696e6172792d323338303432325f3936305f3732302e6a7067, 'Admin@gmial.com', 'hgjh', 1, 'ghgh', NULL, 2221, '', 0, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `medical`
--

CREATE TABLE `medical` (
  `Medicine_id` int(20) NOT NULL,
  `Medicine_name` text NOT NULL,
  `No_unit` int(10) DEFAULT NULL,
  `Req_unit` int(10) DEFAULT NULL,
  `Price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medical`
--

INSERT INTO `medical` (`Medicine_id`, `Medicine_name`, `No_unit`, `Req_unit`, `Price`) VALUES
(1, 'Crocin', 6, 50, 20),
(2, 'vicks action 500', 10, 0, 0),
(3, 'zendu balm', 3, 20, 25),
(4, 'Dicold Total', 10, 0, 30);

-- --------------------------------------------------------

--
-- Table structure for table `medication`
--

CREATE TABLE `medication` (
  `Patient_id` int(20) NOT NULL,
  `Medicine_Name` text NOT NULL,
  `Medicine_Dosage` varchar(20) NOT NULL,
  `quantity` int(20) NOT NULL,
  `Doctor_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medication`
--

INSERT INTO `medication` (`Patient_id`, `Medicine_Name`, `Medicine_Dosage`, `quantity`, `Doctor_id`) VALUES
(108, 'vicks action 500', 'thrice a day', 2, 701),
(108, '', '', 0, 701),
(108, 'Crocin', 'twice a week', 50, 701),
(108, 'Crocin', 'twice a week', 50, 701),
(108, '', 'once a day', 0, 701),
(108, '', 'once a day', 0, 701),
(108, '', 'once a day', 0, 701),
(108, '', 'once a day', 0, 701),
(108, '', 'once a day', 0, 701),
(108, '', 'once a day', 0, 701),
(108, '', 'once a day', 0, 701),
(108, '', 'once a day', 0, 701),
(108, '', 'once a day', 0, 701),
(112, '', 'once a day', 0, 703),
(112, '', 'once a day', 0, 703),
(112, '', 'once a day', 0, 703),
(112, '', 'once a day', 0, 703),
(107, 'Dicold Total', 'once in two day', 11, 701);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `Patient_id` int(20) NOT NULL,
  `fname` text NOT NULL,
  `mname` text NOT NULL,
  `lname` text NOT NULL,
  `dob` date DEFAULT NULL,
  `gender` text NOT NULL,
  `age` int(5) NOT NULL,
  `Marial_status` text NOT NULL,
  `Height` int(10) DEFAULT NULL,
  `Weight` int(10) DEFAULT NULL,
  `Temp` int(20) DEFAULT NULL,
  `BP` int(20) DEFAULT NULL,
  `Sym` varchar(30) DEFAULT NULL,
  `Address` varchar(40) NOT NULL,
  `Contact` bigint(20) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'wait',
  `Doctor_id` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`Patient_id`, `fname`, `mname`, `lname`, `dob`, `gender`, `age`, `Marial_status`, `Height`, `Weight`, `Temp`, `BP`, `Sym`, `Address`, `Contact`, `status`, `Doctor_id`) VALUES
(100, 'a', 'ba', 'n', '2017-11-02', 'm', 55, 'm', 0, 0, NULL, NULL, 'cold', 'nnn', 956, 'wait', 701),
(101, 'b', 'b', 'b', '2017-11-02', 'm', 4, 'm', 152, 52, 101, 155, '0', 'n', 856, 'wait', 1),
(102, 'a', 'a', 'a', '2017-11-14', 'm', 4, 'm', 0, 0, NULL, NULL, 'pashh, jbxa,axbj', '5', 5, 'wait', 701),
(103, 'DD', 'DD', 'DD', '2017-11-08', 'male', 52, 'married', NULL, NULL, NULL, NULL, NULL, 'Nande', 852, 'wait', 701),
(104, 'DD', 'DD', 'DD', '2017-11-08', 'male', 52, 'married', NULL, NULL, NULL, NULL, NULL, 'Nande', 852, 'wait', 701),
(105, 'abc', 'abc', 'anc', '2222-02-02', 'Male', 22, 'Unmarried', NULL, NULL, NULL, NULL, NULL, 'mkonj', 9856, 'wait', 701),
(106, 'xyz', 'abc', 'pqr', '1990-12-17', 'Female', 17, 'Unmarried', NULL, NULL, NULL, NULL, NULL, 'Nanded', 98265, 'wait', 701),
(107, 'pi', 'ka', 'chu', '2017-11-08', 'Male', 1, 'Unmarried', NULL, NULL, NULL, NULL, NULL, 'Nanded 431602', 9011041930, 'wait', 701),
(108, 'harry ', 'james', 'potter', '1990-03-10', 'Male', 27, 'Married', 175, 85, 56, 122, 'c', 'Pivet Road UK', 789652, '', 701),
(109, 'harry ', 'james', 'potter', '1989-12-29', 'Male', 28, 'Married', 0, 0, 0, 0, '', 'Pivet Road UK', 526341, '', 701),
(110, 'ALbus', 'Persival', 'Dumbuldore', '1880-12-12', 'Male', 127, 'Unmarried', 0, 0, 0, 0, '', 'Grafindore Village', 45682, '', 701),
(111, 'Ron', 'Briam', 'Weasley', '1980-02-05', 'Male', 37, 'Married', 0, 0, 0, 0, '', 'Pivet Road UK', 8523641, '', 703),
(112, 'Ron', 'Briam', 'Weasley', '1980-02-05', 'Male', 37, 'Married', 0, 0, 0, 0, '', 'Pivet Road UK', 8523641, '', 703);

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `pres` text NOT NULL,
  `Patient_id` int(20) NOT NULL,
  `Doctor_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`pres`, `Patient_id`, `Doctor_id`) VALUES
('sdfghj', 105, 701),
('sdfghj', 105, 701),
('sdfghj', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('abcd', 105, 701),
('kin cd', 107, 701),
('oasndln', 107, 701),
('xsax', 105, 701),
('ascasc', 105, 701),
('pomsdk', 105, 701),
('picassck', 108, 701),
('gfcfgvgh', 100, 701);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `test` text NOT NULL,
  `Patient_id` int(20) NOT NULL,
  `req_time` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `res_time` timestamp(3) NOT NULL DEFAULT '0000-00-00 00:00:00.000',
  `test_result` varchar(30) NOT NULL,
  `price` float NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'wait'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`test`, `Patient_id`, `req_time`, `res_time`, `test_result`, `price`, `status`) VALUES
('Blood', 0, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Blood', 100, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Blood', 0, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Blood', 0, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Blood', 0, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Blood', 0, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Blood', 103, '0000-00-00 00:00:00.000', '2017-12-02 06:35:31.000', 'Harry Potter must die', 100, 'done'),
('Blood', 108, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Xray', 106, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Urine', 106, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Sonography', 106, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Blood', 106, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Xray', 100, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 150, ''),
('Urine', 100, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 70, ''),
('Sonography', 100, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 200, ''),
('Blood', 100, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', '', 100, ''),
('Blood', 105, '0000-00-00 00:00:00.000', '0000-00-00 00:00:00.000', 'ascsadc', 100, 'done'),
('Urine', 103, '0000-00-00 00:00:00.000', '2017-12-02 06:35:31.000', 'Harry Potter must die', 70, 'done'),
('Xray', 103, '0000-00-00 00:00:00.000', '2017-12-02 06:35:31.000', 'Harry Potter must die', 150, 'done'),
('Blood', 106, '2017-12-02 06:24:09.000', '0000-00-00 00:00:00.000', '2017-12-02 11:54:09', 100, 'wait'),
('Blood', 107, '2017-12-02 06:25:49.000', '2017-12-02 06:28:05.000', 'done it ', 100, 'done');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `Room_id` varchar(30) NOT NULL,
  `Patient_id` int(20) NOT NULL,
  `Floor_no` int(5) NOT NULL,
  `Room_No` int(5) NOT NULL,
  `Room_Type` varchar(10) NOT NULL,
  `Room_Des` text NOT NULL,
  `Status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(30) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `position` varchar(30) NOT NULL,
  `exp` int(5) NOT NULL,
  `Degree` varchar(20) NOT NULL,
  `dob` date DEFAULT NULL,
  `Contact_No` int(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `salary` float NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fname`, `lname`, `position`, `exp`, `Degree`, `dob`, `Contact_No`, `password`, `salary`, `status`) VALUES
(100, 'abca', 'tbca', 'nurse', 2, 'bnm', '2017-11-05', 0, 'abc', 0, ''),
(101, 'adsw', 'sac', 'Nurse', 1, 'lkl', NULL, 98, '', 0, ''),
(102, 'tyu', 'uyt', '', 1, 'mnb', NULL, 78965, '', 0, ''),
(103, 'asa', 'asd', 'Worker', 3, 'fs', NULL, 523, '', 0, ''),
(104, 'scaC', 'asdcaz', 'Nurse', 2, 'lkjhgf', NULL, 321456, '', 0, ''),
(106, 'aqws', 'aswq', 'Lab-Assist', 123, 'plm', NULL, 745, '', 0, ''),
(107, 'asdf', 'sdfg', 'Lab-Assist', 8, 'ikju', NULL, 856, '', 0, 'active'),
(108, 'zz', 'JHB', 'Nurse', 5, 'gvb', NULL, 656, '', 0, 'inactive'),
(109, 'gv', 'aca', 'Pharmacist', 2, '', NULL, 0, '', 0, 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`acc_id`);

--
-- Indexes for table `acc_stock`
--
ALTER TABLE `acc_stock`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_id`);

--
-- Indexes for table `allot`
--
ALTER TABLE `allot`
  ADD KEY `Patient_id` (`Patient_id`),
  ADD KEY `bed_id` (`bed_id`);

--
-- Indexes for table `bed`
--
ALTER TABLE `bed`
  ADD PRIMARY KEY (`bed_id`);

--
-- Indexes for table `consulting`
--
ALTER TABLE `consulting`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`Doctor_id`);

--
-- Indexes for table `medical`
--
ALTER TABLE `medical`
  ADD PRIMARY KEY (`Medicine_id`);

--
-- Indexes for table `medication`
--
ALTER TABLE `medication`
  ADD KEY `Patient_id` (`Patient_id`),
  ADD KEY `Doctor_id` (`Doctor_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`Patient_id`),
  ADD KEY `Doctor_id` (`Doctor_id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD KEY `Patient_id` (`Patient_id`,`Doctor_id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD KEY `Patient_id` (`Patient_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`Room_id`),
  ADD KEY `Patient_id` (`Patient_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `acc_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=210;

--
-- AUTO_INCREMENT for table `acc_stock`
--
ALTER TABLE `acc_stock`
  MODIFY `emp_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bed`
--
ALTER TABLE `bed`
  MODIFY `bed_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1005;

--
-- AUTO_INCREMENT for table `consulting`
--
ALTER TABLE `consulting`
  MODIFY `doctor_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `Doctor_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=724;

--
-- AUTO_INCREMENT for table `medical`
--
ALTER TABLE `medical`
  MODIFY `Medicine_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `Patient_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `allot`
--
ALTER TABLE `allot`
  ADD CONSTRAINT `allot_ibfk_1` FOREIGN KEY (`Patient_id`) REFERENCES `patient` (`Patient_id`),
  ADD CONSTRAINT `allot_ibfk_2` FOREIGN KEY (`bed_id`) REFERENCES `bed` (`bed_id`);

--
-- Constraints for table `medication`
--
ALTER TABLE `medication`
  ADD CONSTRAINT `medication_ibfk_1` FOREIGN KEY (`Patient_id`) REFERENCES `patient` (`Patient_id`),
  ADD CONSTRAINT `medication_ibfk_2` FOREIGN KEY (`Doctor_id`) REFERENCES `doctor` (`Doctor_id`);

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `patient_ibfk_1` FOREIGN KEY (`Doctor_id`) REFERENCES `doctor` (`Doctor_id`);

--
-- Constraints for table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `prescription_ibfk_1` FOREIGN KEY (`Patient_id`) REFERENCES `patient` (`Patient_id`);

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_ibfk_1` FOREIGN KEY (`Patient_id`) REFERENCES `patient` (`Patient_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
