<?php
  session_start();
  require "connect.php";
  if(isset($_SESSION['username']))
  {
    $uname=$_SESSION['username'];
    $sql1 = "SELECT * FROM doctor where Doctor_id='$uname'";
    $result = $con->query($sql1);
    $fname = "";
    $lname = "";    
      $data = array();
    if ($result->num_rows==1) 
    {
      while($row = $result->fetch_assoc()) 
      {
        $fname=$row["fname"];
        $lname=$row["lname"];
        }
    }  
  } 
  else{
    header("location: index.php");
    } 
    ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>SB Admin - Start Bootstrap Template</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
   <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="doctor.php"><?php echo $fname." ".$lname; ?></a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="doctor.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="doc_bed.php">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">Bed Allotment</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="doc_patient_list.php">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">Patient</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="operation.php">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">Operation Theater</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="blood_bank.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Blood Bank</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="blood_add.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Blood Donate</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="doc_payroll.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Payroll</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="doc_profile.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Profile</span>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <form class="form-inline my-2 my-lg-0 mr-lg-2">
            <div class="input-group">
              <input class="form-control" type="text" placeholder="Search for...">
              <span class="input-group-btn">
                <button class="btn btn-primary" type="button">
                  <i class="fa fa-search"></i>
                </button>
              </span>
            </div>
          </form>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="doctor.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Blank Page</li>
      </ol>
      <div class="row">
       <div class="col-md-8">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-table"></i> Donor List Table</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>Donor Name</th>
                    <th>Gender</th>
                    <th>age</th>
                    <th>Blood Group</th>
                  </tr>
                </thead>
                <tbody>
                 <?php
                  $que="SELECT * FROM blood_bank";
                  $res = $con->query($que);

                    while ($row = $res->fetch_assoc()) {
                      echo "<tr>";
                      echo "<td>".$row['name']."</td>";
                      echo "<td>".$row['gender']."</td>";
                      echo "<td>".$row['age']."</td>";
                      echo "<td>".$row['blood_group']."</td>";
                      echo "</tr>";
                    }
                  
                ?>             
                </tbody>
              </table>
            </div>
          </div>
          <div class="card-footer small text-muted"></div>
        </div>
       </div>
       <div class="col-md-4">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-table"></i> Blood Bag List Table</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>Blood Group</th>
                    <th>No of Bags</th>
                  </tr>
                </thead>
                <tbody>
                 <?php
                 //SELECT COUNT(CustomerID), Country FROM Customers GROUP BY Country ORDER BY COUNT(CustomerID) DESC;

                  $que="SELECT count('blood_group') AS Z ,blood_group FROM blood_bank WHERE status='active' GROUP BY blood_group  ORDER BY blood_group";
                  $res = $con->query($que);

                    while ($row = $res->fetch_assoc()) {
                      echo "<tr>";
                      echo "<td>".$row['blood_group']."</td>";
                      echo "<td>".$row['Z']."</td>";
                      echo "</tr>";
                    }
                  
                ?>             
                </tbody>
              </table>
            </div>
          </div>
          <div class="card-footer small text-muted"></div>
        </div>
       </div>
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © HMIS 2017</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
  </div>
</body>

</html>
