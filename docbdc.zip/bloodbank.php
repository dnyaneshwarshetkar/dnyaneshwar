<?php include("header.php") ?>
  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="admin.php">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">Blood Bank List</li>

      </ol>
	  
		<div class="btn-group btn-group-sm mb-2" role="group">
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#bloodbankModal">Add Blood Bank</button>
		
			
		</div>
          <div class="table-responsive">

            <table class="table table-bordered" id="bloodbankTable" width="100%" cellspacing="0">

              <thead>

                <tr>

                  <th>Sr.No</th>

                  <th>Name</th>
				  
				  <th>Age</th>

                  <th>Gender</th>

                  <th>Blood Group</th>

				  <th>Status</th>
				  
				  <th>Manage</th>

                </tr>

              </thead>

              <tbody>
			  
              </tbody>

            </table>

          </div>
		<!--modal Starts for Medicine-->
		<div class="modal" tabindex="-1" role="dialog" id="bloodbankModal">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form  name="bloodbankForm" id="bloodbankForm" onsubmit="return submitData(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Add Blood Bank</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-6">
					  <label for="name">Donor Name</label>
					  <input type="text" class="form-control" id="name" name="name" placeholder="Enter Donor Name" required />
					</div>
					<div class="form-group col-sm-6">
					  <label for="blood_group">Blood Group</label>
					   <select name="blood_group" class="form-control" id="blood_group">
							<option value="">Select Blood Group</option>
							<option value="a+">A+</option>
							<option value="a-">A-</option>
							<option value="b+">B+</option>
							<option value="b-">B-</option>
							<option value="o+">O+</option>
							<option value="o-">O-</option>
							<option value="ab+">AB+</option>
							<option value="ab-">AB-</option>
						</select>
					</div>
				  </div>
				   <div class="form-row">
				   <div class="form-group col-sm-6">
					  <label for="age">Age</label>
					  <input type="text" class="form-control" id="age" name="age" placeholder="Enter Age"/>
					</div>
					<div class="form-group col-sm-6">
					   <label for="gender">Gender</label>
					   <div class="form-check">
						<input type="radio" name="gender" id="male" value="male">
						<label for="male">Male</label>
						<input type="radio" name="gender" id="female" value="female">
						<label for="female">Female</label>
					   </div>
					</div>
				  </div>
				</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
    </div>
</div>
<?php include("footer.php"); ?>
<script src="js/bloodbank.js"></script>
</body>

</html>