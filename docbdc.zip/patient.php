<?php include("header.php") ?>
  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="admin.php">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">Patient List</li>

      </ol>

		 <!--<div class="btn-group btn-group-sm mb-2" role="group">
		
				<button class="btn btn-secondary" data-toggle="modal" data-target="#roomModal"  data-backdrop="static" >Add Patient</button>
			
		  </div>-->
          <div class="table-responsive">

            <table class="table table-bordered" id="patientTable" width="100%" cellspacing="0">

              <thead>

                <tr>

                  <th>Sr.No</th>

                  <th>Patient Name</th>
				  
				  <th>Doctor Name</th>

                  <th>Gender</th>

                  <th>Age</th>

                  <th>Marital Status</th>

                  <th>Address</th>

                  <th>Mobile</th>
				  
				  <th>Status</th>
				  
				  <th>Manage</th>

                </tr>

              </thead>

              <tbody>
			  
              </tbody>

            </table>

          </div>
		  <!--modal for Allocate Bed-->
		<div class="modal" tabindex="-1" role="dialog" id="prescriptionModal">
		  <div role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Prescription</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
			      <h6 class="text-center"></h6>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="clinical_notes">Clinical Notes</label>
					  <textarea class="form-control" id="clinical_notes" name="clinical_notes" placeholder="Enter Clinical Notes" required></textarea>
					</div>
				  </div>
				  <div class="table-responsive">

						<table class="table table-bordered table-condensed" id="prescriptionTable" width="100%" cellspacing="0">

						  <thead>

							<tr>

							  <th>Sr</th>

							  <th>Type</th>
							  
							  <th>Drug</th>

							  <th>Dose</th>

							  <th>Freq</th>

							  <th>Days</th>

							  <th>Quan</th>

							  <th>Instruct</th>
							  
							  <th>Add</th>

							</tr>
							<form  name="prescriptionForm" id="prescriptionForm" onsubmit="return addPrescription(event)">
							<tr>

							  <th>#</th>

							  <th>
								  <select name="medicine_type" class="form-control" id="medicine_type" required />
										<option value="">Select Type</option>
										<option value="syrup">SYRUP</option>
										<option value="drops">DROPS</option>
										<option value="capsule">CAPSULE</option>
								   </select>
							  </th>
							  
							  <th> <input type="text" name="drug_name"  class="form-control typeahead" autocomplete="off" id="drug_name" required /></th>

							  <th> <input type="text" name="dose"  class="form-control" id="dose" required /></th>

							  <th><select name="frequency" class="form-control" id="frequency" required />
										<option value="">Select Type</option>
										<option value="1-0-0">1-0-0</option>
										<option value="0-1-0">0-1-0</option>
										<option value="0-0-1">0-0-1</option>
										<option value="1-1-0">1-1-0</option>
										<option value="1-0-1">1-0-1</option>
										<option value="0-1-1">0-1-1</option>
										<option value="0-0-1">1-1-1</option>
								   </select>
							 </th>

							  <th><input type="number" name="days"  class="form-control" id="days" required /></th>

							  <th> <input type="number" name="quantity"  class="form-control" id="quantity" required /></th>

							  <th> <input type="text" name="instructions"  class="form-control" id="instructions" required /></th>
							  
							  <th><button type="submit" class="btn btn-success">+</button></th>

							</tr>
			                </form>
						  </thead>
						  <tbody class="selectedMedicines">
						  </tbody>
						</table>

					  </div>
					  <h5>Prescription History</h5>
					  <div class="table-responsive">

						<table class="table table-bordered table-condensed" id="prescriptionHistoryTable" width="100%" cellspacing="0">

						  <thead>

							<tr>

							  <th>Sr</th>

							  <th>Doctor Name</th>
							  
							  <th>Date</th>
							  
							  <th>Date Modified</th>
							  
							  <th>Manage</th>

							</tr>
						  </thead>
						  <tbody>
						  </tbody>
						</table>
					  </div>
					  
					  
			  </div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success" onclick="submitPrescription()">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			</div>
		  </div>
		</div>
		
		 <!--modal for Allocate Bed-->
		<div class="modal" tabindex="-1" role="dialog" id="billModal">
		  <div role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Bill</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
			      <h6 class="text-center"></h6>
				  
				  <!-- Nav tabs -->
					<ul class="nav nav-tabs">
					  <li class="nav-item">
						<a class="nav-link active" data-toggle="tab" href="#bill">Bill</a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#pay_bill" id="payBillTab">Pay Bill</a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#discount" id="discountTab">Discount</a>
					  </li>
					</ul>

					<!-- Tab panes -->
					<div class="tab-content">
					  <div class="tab-pane active container" id="bill">
						<form name="addBillForm" onsubmit="return submitBill(event)" id="addBillForm">
							<div class="form-row">
								<div class="form-group col-sm-5">
								  <label for="bill_date">Bill Date</label>
								  <input type="date" class="form-control" id="bill_date" name="bill_date" placeholder="Enter Bill Date" required />
								</div>
								<div class="form-group col-sm-5">
								  <label for="fees_name">Fees Name</label>
								  <input type="text" class="form-control typeaheadFees" id="fees_name" name="fees_name" placeholder="Enter Fees Name" autocomplete="off" required />
								</div>
								<div class="form-group col-sm-2">
								 <label for="add">Add</label>
								 <button type="button" class="btn btn-success form-control" onclick="addFees()">Add</button>
								</div>
							  </div>
							  <div class="table-responsive">

								<table class="table table-bordered" id="feesTable" width="100%" cellspacing="0">

								  <thead>

									<tr>

									  <th>Sr.No</th>

									  <th>Fees Name</th>
									  
									  <th>Amount</th>

									  <th>CGST</th>

									  <th>SGST</th>
									  
									  <th>CGST Amount</th>

									  <th>SGST Amount</th>
									   
									  <th>Total Amount</th>
									  
									   <th>Manage</th>

									</tr>

								  </thead>

								  <tbody class="selectedFees">
								  
								  </tbody>
								  
								  <tfoot>

									<tr>

									  <th>#</th>

									  <th>Sub Total</th>
									  
									  <th id="sub_total"></th>

									  <th>#</th>
									  
									  <th>#</th>
									  
									  <th>#</th>

									  <th>Grand Total</th>
									   
									  <th id="grand_total"></th>
									  
									   <th>#</th>

									</tr>

								  </tfoot>

								</table>
							  </div>
							  <button type="submit" class="btn btn-success">Submit</button>
							  <button type="reset" class="btn btn-danger">Reset</button>
					    </form>
					  </div>
					  <div class="tab-pane container" id="pay_bill">
							  <form  name="payBillForm" id="payBillForm" onsubmit="return credit(event)">
								  <div class="form-row">
									<div class="form-group col-sm-12">
									  <label for="account_id">Select Account</label>
									  <select class="form-control" id="account_id" name="account_id" required>
										<option value="">Select Account</option>
									  </select>
									</div>
								</div>
								 <div class="form-row">
									<div class="form-group col-sm-12">
									  <label for="credit_amount">Payable Amount</label>
									  <input type="text" class="form-control" id="credit_amount" name="credit_amount" placeholder="Enter Credit Amount"/>
									</div>
								  </div>
								  
								  <div class="form-row">
									<div class="form-group col-sm-12">
									  <label for="remark">Remark</label>
									  <input type="text" class="form-control" id="remark" name="remark" placeholder="Enter Remark"/>
									</div>
								  </div>
									<button type="submit" class="btn btn-success">Submit</button>
									<button type="reset" class="btn btn-danger">Reset</button>
							   </form>
						</div>
						<div class="tab-pane container" id="discount">
							<form  name="discountForm" id="discountForm" onsubmit="return submitDiscount(event)">
								<div class="form-row">
									<div class="form-group col-sm-12">
									  <label for="discount">Discount</label>
									  <input type="text" class="form-control" id="discount" name="discount" placeholder="Enter Discount" onchange="setPayable()" required />
									</div>
								  </div>
								  <div class="form-row">
									<div class="form-group col-sm-12">
									  <label for="discount_description">Discount Description</label>
									  <textarea class="form-control" id="discount_description" name="discount_description" placeholder="Enter Discount Description"></textarea>
									</div>
								  </div>
								  <div class="form-row">
									<div class="form-group col-sm-12">
									  <label for="grand_total">Grand Total</label>
									  <input type="text" class="form-control" id="grand_total" name="grand_total" placeholder="Enter Grand Total" readonly required />
									</div>
								  </div>
								 <div class="form-row">
									<div class="form-group col-sm-12">
									  <label for="payable_amount">Payable Amount</label>
									  <input type="text" class="form-control" id="payable_amount" name="payable_amount" placeholder="Enter Payable Amount" readonly required />
									</div>
								  </div>
									<button type="submit" class="btn btn-success">Submit</button>
									<button type="reset" class="btn btn-danger">Reset</button>
							</form>
						</div>
					  </div>
				   <h5>Bill History</h5>
					  <div class="table-responsive">

						<table class="table table-bordered table-condensed" id="billHistoryTable" width="100%" cellspacing="0">

						  <thead>

							<tr>

							  <th>Sr</th>

							  <th>Bill Date</th>
							  
							  <th>Sub Total</th>
							  
							  <th>Grand Total</th>
							  
							  <th>Manage</th>

							</tr>
						  </thead>
						  <tbody>
						  </tbody>
						</table>
					  </div>
				  
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			</div>
		  </div>
		</div>
		
          <div id="preceipt" class="container">
		  </div>
		  
		  <div id="pbill" class="container">
		  </div>
    </div>
</div>
<?php include("footer.php"); ?>
<script src="js/patient.js"></script>

<script type="text/html" id="fees">
	<tr>

		  <td data-content="sr_no">Sr</td>

		  <td data-content="fees_name">Fees Name</td>
		  
		  <td data-content="amount">Amount</td>

		  <td data-content="cgst">CGST</td>

		  <td data-content="sgst">SGST</td>
		  
		   <td data-content="cgst_amount">SGST</td>
		   
		   <td data-content="sgst_amount">SGST</td>

		  <td data-content="total_amount">Total Amount</td>
		  
		  <td><button type="button" class="btn btn-danger" data-value="sr_no" onclick="removeFees(this.value)">-</button></td>

	</tr>
</script>

<script type="text/html" id="feesReceipt">
    <div class="row">
	<div class="col-6">
	<h5>Deshmukh Hospital,<small class="text-muted">Itwara Bazar,Nanded-431604</small></h5>
	</div>
	<div class="col-6">Name :<span data-content="first_name"></span>&nbsp;<span data-content="middle_name"></span>&nbsp;<span data-content="last_name"></span> </div>
	<div class="col-12">
	<div class="table-responsive">
		<table class="table table-bordered">
			<thead>
				<tr>

					  <th>Sr</th>

					  <th>Fees Name</th>
					  
					  <th>Amount</th>

					  <th>CGST</th>

					  <th>SGST</th>

					  <th>Total Amount</th>
					  
				</tr>
			</thead>
			<tbody id="allfeesList">
			</tbody>
			<tfoot>
				<tr>
					<th>#</th>
					<th>Sub Total</th>
					<th data-content="sub_total"></th>
					<th>#</th>
					<th>Grand Total</th>
					<th data-content="grand_total"></th>
				</tr>
			</tfoot>
		</table>
	</div>
	</div>
	</div>
</script>
<script type="text/html" id="feesList">
	<tr>
		   <td data-content="sr_no"></td>

		  <td data-content="fees_name"></td>
		  
		  <td data-content="amount"></td>

		  <td data-content="cgst_amount"></td>

		  <td data-content="sgst_amount"></td>

		  <td data-content="total_amount"></td>
</script>

<script type="text/html" id="medicine">
	<tr>

		  <td data-content="sr_no">Sr</td>

		  <td data-content="medicine_type">Type</td>
		  
		  <td data-content="drug_name">Drug</td>

		  <td data-content="dose">Dose</td>

		  <td data-content="frequency">Freq</td>

		  <td data-content="days">Days</td>

		  <td data-content="quantity">Quan</td>

		  <td data-content="instructions">Instruct</td>
		  
		  <td><button type="button" class="btn btn-danger" data-value="sr_no" onclick="removePrescription(this.value)">-</button></td>

	</tr>
</script>
<script type="text/html" id="medicineList">
	<tr>
		<td data-content="sr_no"></td>

		  <td data-content="medicine_type"></td>
		  
		  <td data-content="drug_name"></td>

		  <td data-content="dose"></td>

		  <td data-content="frequency"></td>

		  <td data-content="days"></td>

		  <td data-content="quantity"></td>

		  <td data-content="instructions"></td>
	</tr>
</script>
<script type="text/html" id="prescriptionReceipt">
    <div class="row">
	<div class="col-6">
	<h5>Deshmukh Hospital,<small class="text-muted">Itwara Bazar,Nanded-431604</small></h5>
	</div>
	<div class="col-6">
	<h5><span data-content="first_name"></span>&nbsp;<span data-content="middle_name"></span>&nbsp;<span data-content="last_name"></span>&nbsp; ,<small class="text-muted">MD,Nanded-431604</small></h5>
	</div>
	<div class="col-6">Name :<span data-content="pfirst_name"></span>&nbsp;<span data-content="pmiddle_name"></span>&nbsp;<span data-content="plast_name"></span> </div>
	<div class="col-6">Address : <span data-content="address"></div>
	<div class="col-6">Weight : <span data-content="weight"></div>
	<div class="col-6">Age : <span data-content="age"></span></div>
	<div class="col-6">Sex : <span data-content="gender"></span></div>
	<div class="col-6">Date : <span data-content="date"></span></div>
	<div class="col-12">Clinical Notes : <span data-content="clinical_notes"></span></div>
	<div class="col-12">
	<div class="table-responsive">
		<table class="table table-bordered">
			<thead>
				<tr>

					  <th>Sr</th>

					  <th>Type</th>
					  
					  <th>Drug</th>

					  <th>Dose</th>

					  <th>Freq</th>

					  <th>Days</th>

					  <th>Quan</th>

					  <th>Instruct</th>
					  
				</tr>
			</thead>
			<tbody id="allPrescriptionList">
			</tbody>
		</table>
	</div>
	</div>
	</div>
</script>

</body>

</html>