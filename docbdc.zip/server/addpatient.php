<?php
include('../connect.php');
session_start();
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
 if($_GET['table']=='patient'){
$doctor_id = trim($decoded["doctor_id"]);
$user_id = $_SESSION['user']["user_id"];//who added the patient
$first_name = $decoded["first_name"];
$middle_name = $decoded["middle_name"];
$last_name = $decoded["last_name"];
$dob = $decoded["dob"];
$appointment_slot = $decoded["appointment_slot"];
$gender = $decoded["gender"];
$age = $decoded["age"];
$marital_status = $decoded["marital_status"];
$height = $decoded["height"];
$weight = $decoded["weight"];
$temperature = $decoded["temperature"];
$blood_pressure = $decoded["blood_pressure"];
$symptoms  = $decoded["symptoms"];
$address  = $decoded["address"];
$mobile  = $decoded["mobile"];
$checked  = $decoded["checked"];
if(isset($_GET['patient_id'])){
	$patient_id = $_GET['patient_id'];
	$sql = "update patient set doctor_id='$doctor_id',user_id='$user_id',first_name='$first_name',middle_name='$middle_name',last_name='$last_name',dob='$dob',appointment_slot='$appointment_slot',gender='$gender',age='$age',marital_status='$marital_status',height='$height',weight='$weight',temperature='$temperature',blood_pressure='$blood_pressure',symptoms='$symptoms',address='$address',mobile='$mobile',checked='$checked' where patient_id=$patient_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Patient Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Patient Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  patient(doctor_id,user_id,first_name,middle_name,last_name,dob,appointment_slot,gender,age,marital_status,height,weight,temperature,blood_pressure,symptoms,address,mobile,checked)values('$doctor_id','$user_id','$first_name','$middle_name','$last_name','$dob','$appointment_slot','$gender','$age','$marital_status','$height','$weight','$temperature','$blood_pressure','$symptoms','$address','$mobile','$checked')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Patient Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Patient Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}
 if($_GET['table']=='prescription'){
$doctor_id = $_SESSION["user"]['user_id'];
$patient_id = $decoded["patient_id"];
$prescription = json_encode($decoded['prescription']);
$clinical_notes = json_encode($decoded['clinical_notes']);
if(isset($_GET['prescription_id'])){
	$prescription_id = $_GET['prescription_id'];
	$sql = "update prescription set doctor_id='$doctor_id',patient_id='$patient_id',prescription='$prescription',clinical_notes ='$clinical_notes' where prescription_id=$prescription_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Prescription Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Prescription Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  prescription(doctor_id,patient_id,prescription,clinical_notes)values('$doctor_id','$patient_id','$prescription','$clinical_notes')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Prescription Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Prescription Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}

if($_GET['table']=='bill'){
$customer_id = $decoded["customer_id"];
$fees = json_encode($decoded["fees"]);
$bill_type = $decoded["bill_type"];
$bill_date = $decoded["bill_date"];
$sub_total = $decoded["sub_total"];
$grand_total = $decoded["grand_total"];
$discount = $decoded["discount"];
$discount_description = $decoded["discount_description"];
$payable_amount = $decoded["payable_amount"];
if(isset($_GET['bill_id'])){
	$bill_id = $_GET['bill_id'];
	$sql = "update bill set customer_id='$customer_id',fees='$fees',bill_type='$bill_type',bill_date ='$bill_date',sub_total='$sub_total',grand_total='$grand_total',discount='$discount',discount_description='$discount_description',payable_amount='$payable_amount' where bill_id=$bill_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Bill Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Bill Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  bill(customer_id,fees,bill_type,bill_date,sub_total,grand_total,discount,discount_description,payable_amount)values('$customer_id','$fees','$bill_type','$bill_date','$sub_total','$grand_total','$discount','$discount_description','$payable_amount')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Bill Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Bill Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}

if($_GET['table']=='transaction'){
$bill_invoice_id = $decoded["bill_invoice_id"];
$account_id = $decoded["account_id"];
$credit = $decoded["credit"];
$remark = $decoded["remark"];
$transaction_against = $decoded["transaction_against"];
if(isset($_GET['transaction_id'])){
	$transaction_id = $_GET['transaction_id'];
	$sql = "update transaction set bill_invoice_id='$bill_invoice_id',account_id='$account_id',credit='$credit',remark ='$remark',transaction_against='$transaction_against' where transaction_id=$transaction_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Transaction Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Transaction Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  transaction(bill_invoice_id,account_id,credit,remark,transaction_against)values('$bill_invoice_id','$account_id','$credit','$remark','$transaction_against')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Transaction Done Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Transaction  Not Done ".mysqli_error($con);
		echo json_encode($response);
	}
}
}
 ?>
