<?php
	session_start();
	if(!isset($_SESSION['user'])){
		echo "<script>alert('Session Expired');window.location.assign('index.php');</script>";
	}else{
		$user = $_SESSION['user'];
	}
?>