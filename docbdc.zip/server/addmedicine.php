<?php
include('../connect.php');
session_start();
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
//adding Medicine
 if($_GET['table']=='medicine'){
$medicine_name = $decoded["medicine_name"];
$medicine_description = $decoded["medicine_description"];
$cgst = $decoded["cgst"];
$sgst = $decoded["sgst"];
if(isset($_GET['medicine_id'])){
	$medicine_id = $_GET['medicine_id'];
	$sql = "update medicine set medicine_name='$medicine_name',medicine_description='$medicine_description',cgst='$cgst',sgst='$sgst' where medicine_id=$medicine_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Medicine Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Medicine Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  medicine(medicine_name,medicine_description,cgst,sgst)values('$medicine_name','$medicine_description','$cgst','$sgst')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Medicine Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Medicine Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}
//adding Medicine Stock
 if($_GET['table']=='medicine_stock'){
$medicine_id = $decoded['medicine_id'];
$quantity = $decoded["quantity"];
$price = $decoded["price"];
$selling_price = $decoded["selling_price"];
if(isset($_GET['medicine_stock_id'])){
	$medicine_stock_id = $_GET['medicine_stock_id'];
	$sql = "update medicine set medicine_id='$medicine_id',quantity='$quantity',price='$price',selling_price='$selling_price' where medicine_stock_id=$medicine_stock_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Medicine Stock Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Medicine Stock Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  medicine_stock(medicine_id,quantity,price,selling_price)values('$medicine_id','$quantity','$price','$selling_price')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Medicine Stock Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Medicine Stock Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}
 ?>
