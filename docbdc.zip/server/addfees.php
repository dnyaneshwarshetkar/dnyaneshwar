<?php
include('../connect.php');
session_start();
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
//adding Medicine
 if($_GET['table']=='fees'){
$fees_name = $decoded["fees_name"];
$amount = $decoded["amount"];
$cgst = $decoded["cgst"];
$sgst = $decoded["sgst"];
$cgst_amount = $decoded["cgst_amount"];
$sgst_amount = $decoded["sgst_amount"];
$total_amount = $decoded["total_amount"];
$description = $decoded["description"];
if(isset($_GET['fees_id'])){
	$fees_id = $_GET['fees_id'];
	$sql = "update fees set fees_name='$fees_name',amount='$amount',cgst='$cgst',sgst='$sgst',cgst_amount='$cgst_amount',sgst_amount='$sgst_amount',total_amount='$total_amount',description='$description' where fees_id=$fees_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Fees Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Fees Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  fees(fees_name,amount,cgst,sgst,cgst_amount,sgst_amount,total_amount,description)values('$fees_name','$amount','$cgst','$sgst','$cgst_amount','$sgst_amount','$total_amount','$description')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Fees Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Fees Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}
