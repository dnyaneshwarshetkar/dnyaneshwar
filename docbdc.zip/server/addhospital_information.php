<?php
include('../connect.php');
session_start();
//Attempt to decode the incoming RAW post data from JSON.
//print_r($_POST);
//print_r($_FILES);
$decoded = $_POST;
 if($_GET['table']=='hospital_information'){
$hospital_name =$decoded["hospital_name"];
$director = $decoded["director"];
$target_file = "";
if($_FILES['logo1']){
$target_dir = "../uploads/hospital/";
$file_name = time().basename($_FILES["logo1"]["name"]);
$target_file = $target_dir.$file_name;
$path = "uploads/hospital/".$file_name;
$source_file = $_FILES['logo1']['tmp_name'];
move_uploaded_file($source_file,$target_file);
}
$logo1  = $path;
$target_file1 = "";
if($_FILES['logo2']){
$target_dir = "../uploads/hospital/";
$file_name1 = time().basename($_FILES["logo2"]["name"]);
$target_file1= $target_dir.$file_name1;
$path1 = "uploads/hospital/".$file_name1;
$source_file1 = $_FILES['logo2']['tmp_name'];
move_uploaded_file($source_file1,$target_file1);
}
$logo2  = $path;
$tq = $decoded["tq"];
$district = $decoded["district"];
$state = $decoded["state"];
if(isset($_GET['hospital_information_id'])){
	$hospital_information_id = $_GET['hospital_information_id'];
	$sql = "update hospital_information set hospital_name='$hospital_name',director='$director',logo1='$logo1',logo2='$logo2',tq='$tq',district='$district',state='$state' where hospital_information_id=$hospital_information_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Hospital Information Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Hospital Information Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  hospital_information(hospital_name,director,logo1,logo2,tq,district,state)values('$hospital_name','$director','$logo1','$logo2','$tq','$district','$state')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Hospital Information Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Hospital Information Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}else{
	
}
 ?>
