<?php
include('../connect.php');
session_start();
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
//adding Medicine
 if($_GET['table']=='account'){
$account_name = $decoded["account_name"];
$account_number = $decoded["account_number"];
$account_description = $decoded["account_description"];
if(isset($_GET['account_id'])){
	$account_id = $_GET['account_id'];
	$sql = "update account set account_name='$account_name',account_number='$account_number',account_description='$account_description' where account_id=$account_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Account Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Account Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  account(account_name,account_number,account_description)values('$account_name','$account_number','$account_description')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Account Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Account Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}
