<?php

session_start();

  require "connect.php";

  if(isset($_SESSION['username']))

  {

    $uname=$_SESSION['username'];

    $sql1 = "SELECT * FROM account where acc_id='$uname'";

    $result = $con->query($sql1);

    $fname = "";

    $lname = "";    

      $data = array();

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $fname=$row["fname"];

        $lname=$row["lname"];

        }

    }  

  } 

  else{

    header("location: index.php");

  }

 ?> 

<!DOCTYPE html>

<html lang="en">



<head>

  <meta charset="utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta name="description" content="">

  <meta name="author" content="">

  <title>Information | HMIS</title>

  <!-- Bootstrap core CSS-->

  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template-->

  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->

  <link href="css/sb-admin.css" rel="stylesheet">

</head>



<body class="fixed-nav sticky-footer bg-dark" id="page-top">

  <!-- Navigation-->

 <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">

    <a class="navbar-brand" href="accountant.php"><?php echo $fname." ".$lname; ?></a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">

      <span class="navbar-toggler-icon"></span>

    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">

      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">

          <a class="nav-link" href="accountant.php">

            <i class="fa fa-fw fa-dashboard"></i>

            <span class="nav-link-text">Dashboard</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="acc_invoice.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Invoice</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="acc_consulting.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Consultion</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="acc_stock.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Stocks</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="acc_payroll.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Payroll</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="acc_profile.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Profile</span>

          </a>

        </li>        

      </ul>

      <ul class="navbar-nav sidenav-toggler">

        <li class="nav-item">

          <a class="nav-link text-center" id="sidenavToggler">

            <i class="fa fa-fw fa-angle-left"></i>

          </a>

        </li>

      </ul>

      <ul class="navbar-nav ml-auto">

        <li class="nav-item">

          <form class="form-inline my-2 my-lg-0 mr-lg-2">

            <div class="input-group">

              <input class="form-control" type="text" placeholder="Search for...">

              <span class="input-group-btn">

                

              <button class="btn btn-primary" type="button">

                  <i class="fa fa-search"></i>

                </button>

              </span>

            </div>

          </form>

        </li>

        <li class="nav-item">

          <a class="nav-link" href="logout.php">

            <i class="fa fa-fw fa-sign-out"></i>Logout</a>

        </li>

      </ul>

    </div>

  </nav>

  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="index.html">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">Admin Homepage</li>

      </ol>

      <div class="row">

        <div class="col-12">

          

        </div>

      </div>

    <!-- Test Part-->

    <div class="row">

       <div class="col-xl-3 col-sm-6 mb-3">

          <div class="card text-white bg-danger o-hidden h-100">

            <div class="card-body">

              <div class="card-body-icon">

                <i class="fa fa-handshake-o"></i>

              </div>

              <div class="" ><b> </b></div>

            </div>

              <a class="card-footer text-white clearfix small z-1" href="acc_consulting.php">

              <span class="float-left">Consulting</span>

              <span class="float-right">

                <i class="fa fa-angle-right"></i>

              </span>

            </a>

         

          </div>

        </div>

        <div class="col-xl-3 col-sm-6 mb-3">

          <div class="card text-white bg-secondary o-hidden h-100">

            <div class="card-body">

              <div class="card-body-icon">

                <i class="fa fa-fw fa-ambulance "></i>

              </div>

              <?php

                  $sql3 = "SELECT COUNT(patient_id) FROM patient";

                  $result = $con->query($sql3);

                  $rows = mysqli_fetch_row($result);

                  

               ?>

              <div class="mr-5"><b><?php echo $rows[0]; ?></b></div>

            </div>

            <a class="card-footer text-white clearfix small z-1" href="#">

              <span class="float-left">Patient</span>

              <span class="float-right">

                <i class="fa fa-angle-right"></i>

              </span>

            </a>

          </div>

        </div>

    </div>

    <!-- Test Part -->

    <br><br>

    </div>

    <!-- /.container-fluid-->

    <!-- /.content-wrapper-->

    <footer class="sticky-footer">

      <div class="container">

        <div class="text-center">
<small>Copyright © <a href="http://nishthaventures.com/"> nishthaventures.com  2018 </a> </small>

        </div>

      </div>

    </footer>

    <!-- Scroll to Top Button-->

    <a class="scroll-to-top rounded" href="#page-top">

      <i class="fa fa-angle-up"></i>

    </a>

    <!-- Bootstrap core JavaScript-->

    <script src="vendor/jquery/jquery.min.js"></script>

    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->

    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->

    <script src="js/sb-admin.min.js"></script>

  </div>

</body>



</html>

