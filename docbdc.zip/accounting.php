<?php include("header.php") ?>
  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="admin.php">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">Accounts List</li>

      </ol>
	  
		<div class="btn-group btn-group-sm mb-2" role="group">
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#accountModal">Add Account</button>
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#creditModal">Credit</button>
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#debitModal">Debit</button>
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#transferModal">Transfer</button>
			
			<button class="btn btn-secondary">Accounts</button>
			
			<button class="btn btn-secondary">Transactions</button>
			
		</div>
          <div class="table-responsive">

            <table class="table table-bordered" id="accountTable" width="100%" cellspacing="0">

              <thead>

                <tr>

                  <th>Sr.No</th>

                  <th>Account Name</th>
				  
				  <th>Account Number</th>

                  <th>Description</th>

				  <th>Status</th>
				  
				  <th>Manage</th>

                </tr>

              </thead>

              <tbody>
			  
              </tbody>

            </table>

          </div>
		<!--modal Starts for Medicine-->
		<div class="modal" tabindex="-1" role="dialog" id="accountModal">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form  name="accountForm" id="accountForm" onsubmit="return addAccount(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Add Account</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="account_name">Account Name</label>
					  <input type="text" class="form-control" id="account_name" name="account_name" placeholder="Enter Account Name" required />
					</div>
				</div>
				 <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="account_number">Account Number</label>
					  <input type="text" class="form-control" id="account_number" name="account_number" placeholder="Enter Account Number"/>
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="account_description">Description</label>
					  <textarea class="form-control" id="account_description" name="account_description" placeholder="Enter Description"></textarea>
					</div>
				  </div>
				</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
		<!--modal for Credit-->
		<div class="modal" tabindex="-1" role="dialog" id="creditModal">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form  name="creditForm" id="creditForm" onsubmit="return credit(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Credit</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="account_name">Select Account</label>
					  <input type="text" class="form-control" id="account_name" name="account_name" placeholder="Enter Account Name" required />
					</div>
				</div>
				 <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="credit_amount">Credit Amount</label>
					  <input type="text" class="form-control" id="credit_amount" name="credit_amount" placeholder="Enter Credit Amount"/>
					</div>
				  </div>
				  
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="remark">Remark</label>
					  <input type="text" class="form-control" id="remark" name="remark" placeholder="Enter Remark"/>
					</div>
				  </div>
				  
				</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
		<!--modal for debit-->
		<div class="modal" tabindex="-1" role="dialog" id="debitModal">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form  name="creditForm" id="creditForm" onsubmit="return debit(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Debit</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="account_name">Select Account</label>
					  <input type="text" class="form-control" id="account_name" name="account_name" placeholder="Enter Account Name" required />
					</div>
				</div>
				 <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="debit_amount">Debit Amount</label>
					  <input type="text" class="form-control" id="debit_amount" name="debit_amount" placeholder="Enter Debit Amount"/>
					</div>
				  </div>
				  
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="remark">Remark</label>
					  <input type="text" class="form-control" id="remark" name="remark" placeholder="Enter Remark"/>
					</div>
				  </div>
			
				</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
		<!--modal for debit-->
		<div class="modal" tabindex="-1" role="dialog" id="transferModal">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form  name="transferForm" id="transferForm" onsubmit="return transfer(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Transfer</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				 <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="account_name">Select Account</label>
					  <input type="text" class="form-control" id="account_name" name="account_name" placeholder="Enter Account Name" required />
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="account_name">Select Account</label>
					  <input type="text" class="form-control" id="account_name" name="account_name" placeholder="Enter Account Name" required />
					</div>
				</div>
				 <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="transfer_amount">Transfer Amount</label>
					  <input type="text" class="form-control" id="transfer_amount" name="transfer_amount" placeholder="Enter Transfer Amount"/>
					</div>
				  </div>
				  
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="remark">Remark</label>
					  <input type="text" class="form-control" id="remark" name="remark" placeholder="Enter Remark"/>
					</div>
				  </div>
				</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
		
    </div>
</div>
<?php include("footer.php"); ?>
<script src="js/accounting.js"></script>
</body>

</html>