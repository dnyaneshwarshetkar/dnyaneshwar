<?php

  session_start();

  require "connect.php";

  if(isset($_SESSION['username']))

  {

    $uname=$_SESSION['username'];

    $sql1 = "SELECT * FROM users where user_id='$uname'";

    $result = $con->query($sql1);

    $fname = "";

    $lname = "";    

      $data = array();

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $fname=$row["first"];

        $mname=$row["middle"];

        $lname=$row["last"];

        $dob=$row["dob"];

        $gen=$row["gender"];

        $cont=$row["Contact"];

        }

    }  

  } 

  else{

    header("location: index.php");

    }



     if (isset($_POST['add'])) {

      $date=$_POST['date'];

      $doc=$_POST['doc'];

      $tim=$_POST['tim'];



    $sql3 = "INSERT INTO patient(Patient_id,user_id,first,middle,last,dob,create_date,apt_time,gender,age,Marial_status,Height,Weight,Temp,BP,Sym,Address,Contact,Doctor_id) VALUES (NULL,'$uname','$fname','$mname','$lname','$dob','$date','$tim','$gen','','','','','','','','','$cont','$doc')";

     if($con->query($sql3)){

        echo "<script>alert('Inserted Succesfully');</script>";

      }

      else{

                die('Could not add data'.mysql_error());

      }

  }

?>

<!DOCTYPE html>

<html lang="en">



<head>

  <meta charset="utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta name="description" content="">

  <meta name="author" content="">

  <title>HMIS|</title>

  <!-- Bootstrap core CSS-->

  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template-->

  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->

  <link href="css/sb-admin.css" rel="stylesheet">

</head>



<body class="fixed-nav sticky-footer bg-dark" id="page-top">

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">

    <a class="navbar-brand" href="patient_dash.html"><?php echo $fname." ".$lname; ?></a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">

      <span class="navbar-toggler-icon"></span>

    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">

      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">

          <a class="nav-link" href="patient_dash.php">

            <i class="fa fa-fw fa-dashboard"></i>

            <span class="nav-link-text">Dashboard</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">

          <a class="nav-link" href="pat_appoint.php">

            <i class="fa fa-fw fa-table"></i>

            <span class="nav-link-text">Appointment</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">

          <a class="nav-link" href="pat_doctor.php">

            <i class="fa fa-fw fa-table"></i>

            <span class="nav-link-text">Doctor</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="pat_history.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">History</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="pat_invoice.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Invoive</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="pat_profile.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Profile</span>

          </a>

        </li>

      </ul>

      <ul class="navbar-nav sidenav-toggler">

        <li class="nav-item">

          <a class="nav-link text-center" id="sidenavToggler">

            <i class="fa fa-fw fa-angle-left"></i>

          </a>

        </li>

      </ul>

      <ul class="navbar-nav ml-auto">

        <li class="nav-item">

          <form class="form-inline my-2 my-lg-0 mr-lg-2">

            <div class="input-group">

              <input class="form-control" type="text" placeholder="Search for...">

              <span class="input-group-btn">

                <button class="btn btn-primary" type="button">

                  <i class="fa fa-search"></i>

                </button>

              </span>

            </div>

          </form>

        </li>

        <li class="nav-item">

          <a class="nav-link" href="logout.php">

            <i class="fa fa-fw fa-sign-out"></i>Logout</a>

        </li>

      </ul>

    </div>

  </nav>

  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="index.html">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">User</li>

      </ol>

      

	  <div class="form-group">

            <div class="form-row">

              <div class="col-md-8">

                <div class="col-md-10">

                  <h3> New Appointment </h3>            

    <form method="post" action="">

        <div class="form-group">

        <br>

            <div class="form-row">

                <label for="exampleInputName">Date</label>

                <input  name="date" class="form-control" id="exampleInputName" type="date" aria-describedby="nameHelp" placeholder="Doctor Name">

            </div><br>

            <div class="form-row">

                <label for="exampleInputName">Appointment Time</label>

                <select name="tim" class="form-control" id="exampleInputName" aria-describedby="nameHelp">

                      <option value="06:00 AM - 06:59 AM">06:00 AM - 06:59 AM</option>

                      <option value="07:00 AM - 07:59 AM">07:00 AM - 07:59 AM</option>

                      <option value="08:00 AM - 08:59 AM">08:00 AM - 08:59 AM</option>

                      <option value="09:00 AM - 09:59 AM">09:00 AM - 09:59 AM</option>

                      <option value="10:00 AM - 10:59 AM">10:00 AM - 10:59 AM</option>

                      <option value="11:00 AM - 11:59 AM">11:00 AM - 11:59 AM</option>

                      <option value="00:00 PM - 00:59 PM">00:00 PM - 00:59 PM</option>

                      <option value="01:00 PM - 01:59 PM">01:00 PM - 01:59 PM</option>

                      <option value="02:00 PM - 02:59 PM">02:00 PM - 02:59 PM</option>

                      <option value="03:00 PM - 03:59 PM">03:00 PM - 03:59 PM</option>

                      <option value="04:00 PM - 04:59 PM">04:00 PM - 04:59 PM</option>

                      <option value="05:00 PM - 05:59 PM">05:00 PM - 05:59 PM</option>

                      <option value="06:00 PM - 06:59 PM">06:00 PM - 06:59 PM</option>

                      <option value="07:00 PM - 07:59 PM">07:00 PM - 07:59 PM</option>

                      <option value="08:00 PM - 08:59 PM">08:00 PM - 08:59 PM</option>

                      <option value="09:00 PM - 09:59 PM">09:00 PM - 09:59 PM</option>

                </select>

            </div><br>

            <div class="form-row">

                <label for="exampleInputName">Doctor Name</label>

                <input name="doc" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Doctor Name">

            </div><br>

            <div class="form-row">

                 <input type="submit" name="add" value="Done" class="btn btn-primary"/>

            </div>



        </div>

    </form>

        </div>

            </div>

              <div class="col-md-4">

                <div class="card mb-3">

            <div class="card-header">

              <i class="fa fa-bell-o"></i> Appointment Queue</div>

            <div class="list-group list-group-flush small">

              <?php



              $que="SELECT * FROM users INNER JOIN patient ON users.user_id=patient.user_id INNER JOIN doctor ON patient.Doctor_id=doctor.Doctor_id ORDER BY create_date DESC";

                $res = $con->query($que);



                  while ($row = $res->fetch_assoc()) {

                  	echo '<a class="list-group-item list-group-item-action" href="#">

                <div class="media">

                  <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/45x45" alt="">

                  <div class="media-body">';

                  	echo '<strong>'.$row["fname"].' '.$row["lname"].'</strong>  waiting for you.';

                    echo '<br>Your patient id is <strong>'.$row["Patient_id"].'</strong>.';

                    echo '<br>Date : <strong>'.$row["create_date"].'</strong>';

                    echo '<br>Time : <strong>'.$row["apt_time"].'</strong>';

                    echo '</div>

                </div>

              </a>';

                  }

              ?>

              </div>

              </div>

            </div>

			<br><br>

			<div class="form-row">

              <div class="col-md-6">

				

			  </div>

			</div>

	  </div>



    </div>

    <!-- /.container-fluid-->

    <!-- /.content-wrapper-->

    <footer class="sticky-footer">

      <div class="container">

        <div class="text-center">

      <small>Copyright © <a href="http://nishthaventures.com/"> nishthaventures.com  2018 </a> </small>
        </div>

      </div>

    </footer>

    <!-- Scroll to Top Button-->

    <a class="scroll-to-top rounded" href="#page-top">

      <i class="fa fa-angle-up"></i>

    </a>

    <!-- Bootstrap core JavaScript-->

    <script src="vendor/jquery/jquery.min.js"></script>

    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->

    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->

    <script src="js/sb-admin.min.js"></script>

  </div>

</body>



</html>

