var submitData = function(event,blood_bank_id){
	event.preventDefault();
	if(!!blood_bank_id){
		var url = "server/addbloodbank.php?table=blood_bank&blood_bank_id="+blood_bank_id;
	}else{
		var url = "server/addbloodbank.php?table=blood_bank";
	}
	var x = $('#bloodbankForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  $('#bloodbankForm')[0].reset();
			  $('form#bloodbankForm h5').text("Add Blood Bank");
			  bloodbank.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
var addReceiptItem = function(event,receipt_item_id){
	event.preventDefault();
	if(!!receipt_item_id){
		var url = "server/addreceiptitem.php?table=receipt_item&receipt_item_id="+receipt_item_id;
	}else{
		var url = "server/addreceiptitem.php?table=receipt_item";
	}
	var x = $('#receiptItemForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  $('#receiptItemForm')[0].reset();
			  $('form#receiptItemForm h5').text("Add Receipt Item");
			  receiptitem.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(function(){
	receiptitem = $('#reciptItemTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?receipt_item=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "receipt_item_id"
		}, {
			data : "receipt_item_name"
		},{
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "receipt_item_id"
		}],
		'columnDefs': [{
		   'targets': 3,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0)" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '" onclick="editReceiptItem(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button>'+status+'</div>';
		   }
		}]
	});
	$('#receiptItemModal').on('hidden.bs.modal', function (e) {
		  $('#receiptItemForm')[0].reset();
		  $('form#receiptItemForm h5').text("Add Receipt Item");
	});
});
var editReceiptItem = function(receipt_item_id){
	$('form#receiptItemForm').attr('onsubmit','addReceiptItem(event,'+receipt_item_id+')');
	$('form#receiptItemForm h5').text("Edit Receipt Item");
	$.get("server/get_data.php?receipt_item=true&receipt_item_id="+receipt_item_id, function(data, status){
		data =JSON.parse(data);
		$.each(data, function(key, value){
				$('form#receiptItemForm [name=' + key + ']').val(value);
		});
	});
	$("#receiptItemModal").modal();
}
var changeStatus = function(receipt_item_id,status){
	var data = JSON.stringify({table:"receipt_item",receipt_item_id : receipt_item_id,status:status});
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}