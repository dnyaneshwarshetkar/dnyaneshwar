var getMedicine = function(){
	var url = "server/get_data.php?medicine=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(medicineList){
				medicineList = JSON.parse(medicineList);
			    var mySelect = $('#medicine_id');
				$.each(medicineList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['medicine_id']).html(value['medicine_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getMedicine();

var addMedicine = function(event,medicine_id){
	event.preventDefault();
	if(!!medicine_id){
		var url = "server/addmedicine.php?table=medicine&medicine_id="+medicine_id;
	}else{
		var url = "server/addmedicine.php?table=medicine";
	}
	var x = $('#medicineForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  $('#medicineForm')[0].reset();
			  medicine.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}

var addMedicineStock = function(event,medicine_stock_id){
	event.preventDefault();
	if(!!medicine_stock_id){
		var url = "server/addmedicine.php?table=medicine_stock&medicine_stock_id="+medicine_stock_id;
	}else{
		var url = "server/addmedicine.php?table=medicine_stock";
	}
	var x = $('#medicineStockForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  $('#medicineStockForm')[0].reset();
			  medicine.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(function(){
	
	var params = getAllUrlParams(window.location.href);
	//making medicine global object
	medicine = $('#medicineTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?medicine=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "medicine_id"
		}, {
			data : "medicine_name"
		}, {
			data : "quantity"
		},{
			data : "price"
		}, {
			data : "selling_price"
		},{
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "medicine_id"
		}],
		'columnDefs': [{
		   'targets': 6,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0)" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '" onclick="editMedicine(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button>'+status+'</div>';
		   }
		}]
	});
	
});
var editMedicine = function(medicine_id){
	$('form#medicineForm').attr('onsubmit','addMedicine(event,'+medicine_id+')');
	$('form#medicineForm h5').text("Edit Medicine");
	$.get("server/get_data.php?medicine=true&medicine_id="+medicine_id, function(data, status){
		data =JSON.parse(data);
		$.each(data, function(key, value){
				$('form#medicineForm [name=' + key + ']').val(value);
				
		});
	});
	$("#medicineModal").modal();
}
var changeStatus = function(medicine_id,status){
	var data = JSON.stringify({table:"medicine",medicine_id : medicine_id,status:status});
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}