var submitData = function(event,hospital_information_id){
	event.preventDefault();
	if(!!hospital_information_id){
		var url = "server/addhospital_information.php?table=hospital_information&hospital_information_id="+hospital_information_id;
	}else{
		var url = "server/addhospital_information.php?table=hospital_information";
	}
	var x = document.getElementById('addForm');
	formData = new FormData(x);
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
		  },
		   processData: false,
           contentType: false,
		});
}
var editHospital = function(hospital_information_id){
	$.get("server/get_data.php?hospital_information=true&hospital_information_id="+hospital_information_id, function(data, status){
		$.each(JSON.parse(data), function(key, value){
					$('form#addForm [name=' + key + ']').val(value);
			});
	});
}