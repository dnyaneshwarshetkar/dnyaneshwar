var addFees = function(event,fees_id){
	event.preventDefault();
	if(!!fees_id){
		var url = "server/addfees.php?table=fees&fees_id="+fees_id;
	}else{
		var url = "server/addfees.php?table=fees";
	}
	var x = $('#feesForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  $('#feesForm')[0].reset();
			  fees.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}

$(document).ready(function(){
	//making medicine global object
	fees = $('#feesTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?fees=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "fees_id"
		}, {
			data : "fees_name"
		}, {
			data : "amount"
		},{
			data : "cgst"
		}, {
			data : "sgst"
		},{
			data : "total_amount"
		},{
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "fees_id"
		}],
		'columnDefs': [{
		   'targets': 7,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0)" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '" onclick="editFees(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button>'+status+'</div>';
		   }
		}]
	});
	
});
var editFees = function(fees_id){
	$('form#feesForm').attr('onsubmit','addFees(event,'+fees_id+')');
	$('form#feesForm h5').text("Edit Fees");
	$.get("server/get_data.php?fees=true&fees_id="+fees_id, function(data, status){
		data =JSON.parse(data);
		$.each(data, function(key, value){
				$('form#feesForm [name=' + key + ']').val(value);
				
		});
	});
	$("#feesModal").modal();
}
var totalAmount = function(){
	if(!!$("#cgst").val()){
		var cgst = $("#cgst").val();
		cgst = cgst/100;
	}else{
		var cgst = 0.00;
	}
	if(!!$("#sgst").val()){
		var sgst = $("#sgst").val();
		sgst = sgst/100
	}else{
		var sgst = 0.00;
	}
	if(!!$("#amount").val()){
		var amount = $("#amount").val();
	}else{
		var amount = 0.00;
	}
	var cgst_amount = amount*cgst;
	var sgst_amount = amount*sgst;
	var total_amount = amount*(1 + cgst + sgst);
	$("#cgst_amount").val(cgst_amount);
	$("#sgst_amount").val(sgst_amount);
	$("#total_amount").val(total_amount);
}
var changeStatus = function(fees_id,status){
	var data = JSON.stringify({table:"fees",fees_id : fees_id,status:status});
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}