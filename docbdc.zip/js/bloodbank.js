var submitData = function(event,blood_bank_id){
	event.preventDefault();
	if(!!blood_bank_id){
		var url = "server/addbloodbank.php?table=blood_bank&blood_bank_id="+blood_bank_id;
	}else{
		var url = "server/addbloodbank.php?table=blood_bank";
	}
	var x = $('#bloodbankForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  $('#bloodbankForm')[0].reset();
			  $('form#bloodbankForm h5').text("Add Blood Bank");
			  bloodbank.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(function(){
	bloodbank = $('#bloodbankTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?blood_bank=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "blood_bank_id"
		}, {
			data : "name"
		}, {
			data : "age"
		},{
			data : "gender"
		}, {
			data : "blood_group"
		},{
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "blood_bank_id"
		}],
		'columnDefs': [{
		   'targets': 6,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0)" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '" onclick="editBloodBank(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button>'+status+'</div>';
		   }
		}]
	});
	$('#bloodbankModal').on('hidden.bs.modal', function (e) {
		  $('#bloodbankForm')[0].reset();
		  $('form#bloodbankForm h5').text("Add Blood Bank");
	});
});
var editBloodBank = function(blood_bank_id){
	$('form#bloodbankForm').attr('onsubmit','submitData(event,'+blood_bank_id+')');
	$('form#bloodbankForm h5').text("Edit Blood Bank");
	$.get("server/get_data.php?blood_bank=true&blood_bank_id="+blood_bank_id, function(data, status){
		data =JSON.parse(data);
		$.each(data, function(key, value){
			if(key=='gender'){
				if(value=='male'){
					 $('form#bloodbankForm #male').attr('checked','true');
				}
				if(value=='female'){
					 $('form#bloodbankForm #female').attr('checked','true');
				}
				
			}else{
				$('form#bloodbankForm [name=' + key + ']').val(value);
			}
		});
	});
	$("#bloodbankModal").modal();
}
var changeStatus = function(blood_bank_id,status){
	var data = JSON.stringify({table:"blood_bank",blood_bank_id : blood_bank_id,status:status});
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}