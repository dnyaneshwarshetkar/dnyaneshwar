var submitData = function(event,user_id){
	event.preventDefault();
	if(!!user_id){
		var url = "server/adduser.php?table=users&user_id="+user_id;
	}else{
		var url = "server/adduser.php?table=users";
	}
	var x = $('#addUserForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(function(){
	editUser(1);
});
var editUser = function(user_id){
	$.get("server/get_data.php?users=true&user_id="+user_id, function(data, status){
		$.each(JSON.parse(data), function(key, value){
				if(key=='gender'){
					if(value=='male'){
						 $('form [name="gender"][value="male"]').prop('checked', true);
					}
					if(value=='female'){
					 $('form [name="gender"][value="female"]').prop('checked', true);
					}
				}else{
					$('form [name=' + key + ']').val(value);
				}
				
				
			});
	});
}