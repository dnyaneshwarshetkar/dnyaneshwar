var addAccount = function(event,account_id){
	event.preventDefault();
	if(!!account_id){
		var url = "server/addaccount.php?table=account&account_id="+account_id;
	}else{
		var url = "server/addaccount.php?table=account";
	}
	var x = $('#accountForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  $('#accountForm')[0].reset();
			  $('form#accountForm').attr('onsubmit','addAccount(event)');
			  fees.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}

$(document).ready(function(){
	//making medicine global object
	account = $('#accountTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?account=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "account_id"
		}, {
			data : "account_name"
		}, {
			data : "account_number"
		},{
			data : "account_description"
		}, {
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "account_id"
		}],
		'columnDefs': [{
		   'targets': 5,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0)" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '" onclick="editAccount(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button>'+status+'</div>';
		   }
		}]
	});
	$('#accountModal').on('hidden.bs.modal', function (e) {
		$('#accountForm')[0].reset();
	    $('form#accountForm h5').text("Add Account");
    })
});
var editAccount = function(account_id){
	$('form#accountForm').attr('onsubmit','addAccount(event,'+account_id+')');
	$('form#accountForm h5').text("Edit Account");
	$.get("server/get_data.php?account=true&account_id="+account_id, function(data, status){
		data =JSON.parse(data);
		$.each(data, function(key, value){
				$('form#accountForm [name=' + key + ']').val(value);
				
		});
	});
	$("#accountModal").modal();
}
var changeStatus = function(account_id,status){
	var data = JSON.stringify({table:"account",account_id : account_id,status:status});
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}