var getMedicine = function(){
	var url = "server/get_data.php?medicine=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(medicineList){
			   $(".typeahead").typeahead({
				  displayText: function(item){
					  return item.medicine_name;
				  },
				  source: JSON.parse(medicineList),
				  autoSelect: false
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getMedicine();
var getAccount = function(){
	var url = "server/get_data.php?account=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(accountList){
			  accountList = JSON.parse(accountList);
			    var mySelect = $('#account_id');
				$.each(accountList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['account_id']).html(value['account_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getAccount();
var getFees = function(){
	var url = "server/get_data.php?fees=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(feesList){
			   $(".typeaheadFees").typeahead({
				  displayText: function(item){
					  return item.fees_name;
				  },
				  source: JSON.parse(feesList),
				  autoSelect: false,
				  afterSelect : function(data){
					  selectedFee = JSON.parse(JSON.stringify(data));
				  }
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getFees();


var submitData = function(event,patient_id){
	event.preventDefault();
	if(!!patient_id){
		var url = "server/addpatient.php?table=patient&patient_id="+patient_id;
	}else{
		var url = "server/addpatient.php?table=teacher";
	}
	var x = $('#addTeacherForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(function(){
	var params = getAllUrlParams(window.location.href);
	if(!!params['patient_id']){
		editPatient(params['patient_id']);
	}
	patient = $('#patientTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?patient=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "patient_id"
		}, {
			data : "first_name",render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		}, {
			data : "dfirst_name",render :function(data, type, row, meta){
				return data+" "+row['dmiddle_name']+" "+row['dlast_name'];
			}
		},{
			data : "gender"
		}, {
			data : "age"
		},{
			data : "marital_status",width:"10%","render":function(data, type, full, meta){
				if(data==0){
					return '<span>Married</span>';
				}else{
					return '<span>Unmarried</span>';
				}
			}
		},{
			data : "address"
		},{
			data : "mobile"
		},{
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "patient_id"
		}],
		'columnDefs': [{
		   'targets': 9,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0)" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '" onclick="editData(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button><button value="' + $('<div/>').text(data).html() + '"  class="btn btn-success btn-sm prescription"  title="Prescription">Prescription</button><button type="button" value="' + $('<div/>').text(data).html() + '" class="btn btn-success btn-sm bill"  title="Bill">Bill</button>'+status+'</div>';
		   }
		}]
	});
	
	 $('#patientTable tbody').on( 'click', 'button.prescription', function () {
        var data = patient.row( $(this).parents('tr') ).data();
		prescription(data);
    });
	
	$('#patientTable tbody').on( 'click', 'button.bill', function () {
        var data = patient.row( $(this).parents('tr') ).data();
		bill(data);
    });
	
});
var editData = function(patient_id){
	window.location.href = "addpatient.php?patient_id="+patient_id;
}
var selectedMedicines = [];
var prescriptionPatient ={};
var billPatient ={};
var selectedFees = [];
var selectedFee = {};
var prescription = function(patientDetails){
	prescriptionPatient = patientDetails;
	$("#prescriptionModal h6").text(patientDetails['first_name']+" "+patientDetails['middle_name']+" "+patientDetails['last_name']);
	
	prescriptionList = $('#prescriptionHistoryTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?prescription=true&data=true&patient_id="+patientDetails.patient_id,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "prescription_id"
		}, {
			data : "first_name",render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		}, {
			data : "date"
		},{
			data : "date_modified"
		},{
			data : "prescription_id"
		}],
		'columnDefs': [{
		   'targets': 4,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   		   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '"  class="btn btn-success btn-sm print" title="Print ">Print</button></div>';
		   }
		}]
	});
	$('#prescriptionHistoryTable tbody').on( 'click', 'button.print', function () {
        var data = prescriptionList.row( $(this).parents('tr') ).data();
		$("#preceipt").loadTemplate("#prescriptionReceipt",data);
		$("#allPrescriptionList").loadTemplate("#medicineList",JSON.parse(data.prescription));
		window.print();
    });
	
	$("#prescriptionModal").modal();
}

var bill = function(patientDetails){
	billPatient = patientDetails;
	$("#billModal h6").text(patientDetails['first_name']+" "+patientDetails['middle_name']+" "+patientDetails['last_name']);
	
	billList = $('#billHistoryTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?bill=true&data=true&bill_type=patient&customer_id="+patientDetails.patient_id,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "bill_id"
		},  {
			data : "bill_date"
		},{
			data : "sub_total"
		},{
			data : "grand_total"
		},{
			data : "bill_id"
		}],
		'columnDefs': [{
		   'targets': 4,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   		   return '<div class="btn-group btn-group-sm"><button type="button"  value="' + $('<div/>').text(data).html() + '"  class="btn btn-success btn-sm payBill" title="Pay Bill">PayBill</button><button type="button" value="' + $('<div/>').text(data).html() + '"  class="btn btn-success btn-sm printBill" title="Print " >Print Bill</button><button type="button"  value="' + $('<div/>').text(data).html() + '"  class="btn btn-success btn-sm discount" title="Discount">Discount</button><button type="button"  value="' + $('<div/>').text(data).html() + '"  class="btn btn-success btn-sm printReceipt" title="Print Receipt">Print Receipt</button></div>';
		   }
		}]
	});
	
	$('#billHistoryTable tbody').on( 'click', 'button.payBill', function () {
        var data = billList.row( $(this).parents('tr') ).data();
		payBill(data);
    });
	$('#billHistoryTable tbody').on( 'click', 'button.printBill', function () {
		var data = billList.row( $(this).parents('tr') ).data();
		$("#pbill").loadTemplate("#feesReceipt",data);
		$.ajax({
		  type: "POST",
		  url: "server/get_data.php?fees=true&data=true&feesList="+data.fees,
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  $("#allfeesList").loadTemplate("#feesList",data);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
		setTimeout(function(){window.print()},200)
    });
	$('#billHistoryTable tbody').on( 'click', 'button.discount', function () {
        var data = billList.row( $(this).parents('tr') ).data();
		discount(data);
    });
	
	$("#billModal").modal();
}
var sub_total = 0;
var grand_total = 0;

var addFees = function(){
	selectedFees.push(selectedFee);
	sub_total = 0;
	grand_total = 0;
	$.each(selectedFees,function(key,value){
		value['sr_no'] = key+1;
		sub_total += Number(value['amount']);
		grand_total += Number(value['total_amount']);
	});
	showfeesList(selectedFees,sub_total,grand_total);
}
var showfeesList = function(list,sub,grand){
	$(".selectedFees").loadTemplate("#fees",list);
	$("#sub_total").text(sub);
	$("#grand_total").text(grand);
}
var removeFees = function(sr_no){
	selectedFees = $.grep(selectedFees,function(value,key){
		if(value['sr_no']!=sr_no){
			return true;
		}else{
			return false;
		}
	});
	sub_total = 0;
	grand_total = 0;
	$.each(selectedFees,function(key,value){
		value['sr_no'] = key+1;
		sub_total += Number(value['amount']);
		grand_total += Number(value['total_amount']);
	});
	showfeesList(selectedFees,sub_total,grand_total);
}
var addPrescription = function(event){
	event.preventDefault();
	formData = new FormData(document.getElementById("prescriptionForm"));
	var object = {};
	formData.forEach(function(value, key){
		object[key] = value;
	});
	document.getElementById("prescriptionForm").reset();
	selectedMedicines.push(object);
	$.each(selectedMedicines,function(key,value){
		value['sr_no'] = key+1;
	});
	showList(selectedMedicines);
}
var showList = function(list){
	$(".selectedMedicines").loadTemplate("#medicine",list);
}
var removePrescription = function(sr_no){
	console.log(sr_no);
	selectedMedicines = $.grep(selectedMedicines,function(value,key){
		if(value['sr_no']!=sr_no){
			return true;
		}else{
			return false;
		}
	});
	$.each(selectedMedicines,function(key,value){
		value['sr_no'] = key+1;
	});
	showList(selectedMedicines);
}
var changeStatus = function(patient_id,status){
	var data = JSON.stringify({table:"patient",patient_id : patient_id,status:status});
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
var submitPrescription = function(prescription_id){
	if(!!prescription_id){
		var url = "server/addpatient.php?table=prescription&prescription_id="+prescription_id;
	}else{
		var url = "server/addpatient.php?table=prescription";
	}
	prescriptionPatient.clinical_notes  = $("#clinical_notes").val();
	prescriptionPatient.prescription = selectedMedicines;
	formData = JSON.stringify(prescriptionPatient);
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  prescriptionList.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
var payBillDetails = {};
var payBill = function(paybillDetails){
	payBillDetails = JSON.parse(JSON.stringify(paybillDetails));
	$("#payBillForm #credit_amount").val(payBillDetails.payable_amount);
	$("#payBillTab").tab("show");
}
var credit = function(event){
	event.preventDefault();
	var formData = {};
	console.log(payBillDetails);
	formData.bill_invoice_id = payBillDetails.bill_id;
	formData.account_id = $("#payBillForm #account_id").val();
	console.log(formData.account_id);
	formData.credit = $("#payBillForm #credit_amount").val();
	formData.transaction_against = "bill";
	formData.remark = $("#payBillForm #remark").val();
	formData = JSON.stringify(formData);
	$.ajax({
		  type: "POST",
		  url:"server/addpatient.php?table=transaction",
		  data: formData,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message);
			  billList.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
var discount = function(paybillDetails){
	payBillDetails = JSON.parse(JSON.stringify(paybillDetails));
	$("#discountForm #discount").val(payBillDetails.discount);
	$("#discountForm #discount_description").val(payBillDetails.discount_description);
	$("#discountForm #grand_total").val(payBillDetails.grand_total);
	$("#discountForm #payable_amount").val(payBillDetails.payable_amount);
	$("#discountTab").tab("show");
}
var setPayable = function(){
	var grand_total = $("#discountForm #grand_total").val();
	var discount = $("#discountForm #discount").val();
}
var submitDiscount = function(event){
	event.preventDefault();
	var formData = {};
	formData.discount = $("#discountForm #discount").val();
	formData.discount_description =$("#discountForm #discount_description").val();
	formData.payable_amount =$("#discountForm #payable_amount").val();
	formData = JSON.stringify(formData);
	$.ajax({
		  type: "POST",
		  url:"server/addpatient.php?table=bill&discount=true&bill_id="+payBillDetails.bill_id,
		  data: formData,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message);
			  billList.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
var receipt = function(billDetails){
	$("#receipt").tab("show");
}
var submitBill = function(event,bill_id){
	event.preventDefault();
	if(!!bill_id){
		var url = "server/addpatient.php?table=bill&bill_id="+bill_id;
	}else{
		var url = "server/addpatient.php?table=bill";
	}
	var formData = {};
	formData.customer_id = billPatient.patient_id;
	formData.bill_type = "patient";
	formData.fees = [];
	formData.sub_total = sub_total;
	formData.grand_total = grand_total;
	$.each(selectedFees,function(key,value){
		formData.fees.push(value['fees_id']);
	});
	formData.bill_date = $("#bill_date").val();
	formData.discount = 0.00;
	formData.discount_description = "Discount is not Applicable";
	formData.payable_amount = grand_total;
	formData = JSON.stringify(formData);
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message);
			  billList.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
