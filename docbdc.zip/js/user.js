$(document).ready(function(){
	var user = $('#userTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?users=all&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "user_id"
		}, {
			data : "first_name",render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		},{
			data : "user_type"
		}, {
			data : "gender"
		},{
			data : "dob"
		},{
			data : "email"
		},{
			data : "mobile"
		},{
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "user_id"
		}],
		'columnDefs': [{
		   'targets': 8,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0)" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '" onclick="editData(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button>'+status+'</div>';
		   }
		}]
	});
	
});
var editData = function(user_id){
	window.location.href = "adduser.php?user_id="+user_id;
}
var changeStatus = function(user_id,status){
	var data = JSON.stringify({table:"users",user_id : user_id,status:status});
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}