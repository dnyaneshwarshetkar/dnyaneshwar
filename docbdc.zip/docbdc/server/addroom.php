<?php
include('../connect.php');
session_start();
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
//adding Medicine
 if($_GET['table']=='room'){
$room_name = $decoded["room_name"];
$room_type_id = $decoded["room_type_id"];
$bed_price = $decoded["bed_price"];
$bed_cgst = $decoded["bed_cgst"];
$bed_sgst = $decoded["bed_sgst"];
$room_description = $decoded["room_description"];
if(isset($_GET['room_id'])){
	$room_id = $_GET['room_id'];
	$sql = "update room set room_name='$room_name',room_type_id='$room_type_id',bed_price='$bed_price',bed_cgst='$bed_cgst',bed_sgst='$bed_sgst',room_description='$room_description' where room_id=$room_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Room Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Room Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  room(room_name,room_type_id,bed_price,bed_cgst,bed_sgst,room_description)values('$room_name','$room_type_id','$bed_price','$bed_sgst','$bed_sgst','$room_description')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Room Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Room Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}
//adding BED
 if($_GET['table']=='bed'){
$bed_name = $decoded['bed_name'];
$room_id = $decoded["room_id"];
$bed_description = $decoded["bed_description"];
if(isset($_GET['bed_id'])){
	$bed_id = $_GET['bed_id'];
	$sql = "update bed set bed_name='$bed_name',room_id='$room_id',bed_description='$bed_description' where bed_id=$bed_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Bed Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Bed Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  bed(bed_name,room_id,bed_description)values('$bed_name','$room_id','$bed_description')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Bed Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Bed Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}

 if($_GET['table']=='bed_patient'){
$patient_id = $decoded['patient_id'];
$room_id = $decoded["room_id"];
$bed_id = $decoded["bed_id"];
$allocated_date = $decoded["allocated_date"];
$release_date = $decoded["release_date"];
if(isset($_GET['bed_patient_id'])){
	$bed_patient_id = $_GET['bed_patient_id'];
	$sql = "update bed_patient set room_id='$room_id',bed_id='$bed_id',patient_id='$patient_id',allocated_date='$allocated_date',release_date='$release_date' where bed_patient_id=$bed_patient_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Allocated Bed Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Allocated Bed Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  bed_patient(room_id,bed_id,patient_id,allocated_date,release_date)values('$room_id','$bed_id','$patient_id','$allocated_date','$release_date')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Allocated Bed Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Allocated Bed Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}

 ?>
