<?php
include('../connect.php');
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
if(isset($decoded['table'])){
	$table = $decoded['table'];
}else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Name of Table is Wrong".mysqli_error($con);
		echo json_encode($response);
}
if(isset($decoded['patient_id'])){
	$column_id ='patient_id';
	$id = $decoded['patient_id'];
}
if(isset($decoded['user_id'])){
	$column_id ='user_id';
	$id = $decoded['user_id'];
}
if(isset($decoded['medicine_id'])){
	$column_id ='medicine_id';
	$id = $decoded['medicine_id'];
}
if(isset($decoded['room_id'])){
	$column_id ='room_id';
	$id = $decoded['room_id'];
}
if(isset($decoded['bed_id'])){
	$column_id ='bed_id';
	$id = $decoded['bed_id'];
}
$status = $decoded['status'];
$sql = "update $table set status = $status where $column_id=$id";
if($con->query($sql)){
	$response = array();
	$response['status'] ="SUCCESS";
	$response['message'] ="The Status is changed".mysqli_error($con);
	echo json_encode($response);
}