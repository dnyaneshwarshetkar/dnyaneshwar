<?php
include('../connect.php');
session_start();
//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}
 
//Make sure that the content type of the POST request has been set to application/json
$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
if(strcasecmp($contentType, 'application/json') != 0){
    throw new Exception('Content type must be: application/json');
}
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
 
//Attempt to decode the incoming RAW post data from JSON.
$decoded = json_decode($content, true);
if(!is_array($decoded)){
    echo 'Received content contained invalid JSON!';
}
 if($_GET['table']=='patient'){
$doctor_id = trim($decoded["doctor_id"]);
$user_id = $_SESSION['user']["user_id"];//who added the patient
$first_name = $decoded["first_name"];
$middle_name = $decoded["middle_name"];
$last_name = $decoded["last_name"];
$dob = $decoded["dob"];
$appointment_slot = $decoded["appointment_slot"];
$gender = $decoded["gender"];
$age = $decoded["age"];
$marital_status = $decoded["marital_status"];
$height = $decoded["height"];
$weight = $decoded["weight"];
$temperature = $decoded["temperature"];
$blood_pressure = $decoded["blood_pressure"];
$symptoms  = $decoded["symptoms"];
$address  = $decoded["address"];
$mobile  = $decoded["mobile"];
$checked  = $decoded["checked"];
if(isset($_GET['patient_id'])){
	$patient_id = $_GET['patient_id'];
	$sql = "update patient set doctor_id='$doctor_id',user_id='$user_id',first_name='$first_name',middle_name='$middle_name',last_name='$last_name',dob='$dob',appointment_slot='$appointment_slot',gender='$gender',age='$age',marital_status='$marital_status',height='$height',weight='$weight',temperature='$temperature',blood_pressure='$blood_pressure',symptoms='$symptoms',address='$address',mobile='$mobile',checked='$checked' where patient_id=$patient_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Patient Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Patient Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  patient(doctor_id,user_id,first_name,middle_name,last_name,dob,appointment_slot,gender,age,marital_status,height,weight,temperature,blood_pressure,symptoms,address,mobile,checked)values('$doctor_id','$user_id','$first_name','$middle_name','$last_name','$dob','$appointment_slot','$gender','$age','$marital_status','$height','$weight','$temperature','$blood_pressure','$symptoms','$address','$mobile','$checked')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Patient Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Patient Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}
 if($_GET['table']=='prescription'){
//$doctor_id = trim($decoded["doctor_id"]);
$patient_id = $decoded["patient_id"];
$prescription = json_encode($decoded['prescription']);
if(isset($_GET['prescription_id'])){
	$prescription_id = $_GET['prescription_id'];
	$sql = "update prescription set patient_id='$patient_id',prescription='$prescription' where prescription_id=$prescription_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Prescription Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Prescription Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  prescription(patient_id,prescription)values('$patient_id','$prescription')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The Prescription Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The Prescription Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}
 ?>
