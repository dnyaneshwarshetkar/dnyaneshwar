<?php
require_once("../connect.php");
session_start();
//for getting single patients data
if(isset($_GET['patient'])&&isset($_GET['patient_id'])){
	$patient_id = $_GET['patient_id'];
	$return = array();
	$result = mysqli_query($con,"SELECT * from patient where patient_id=$patient_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}
//for getting all patients data
if(isset($_GET['patient'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT p.*,d.first_name as dfirst_name,d.middle_name as dmiddle_name,d.last_name as dlast_name from patient as p inner join users as d on p.doctor_id = d.user_id");
	echo mysqli_error($con);
	if(mysqli_affected_rows($con)>=1){
		while($row = mysqli_fetch_assoc($result)){
			//$row['image'] = base64_encode($row['image']);
		array_push($return,$row);
		}
	}else{
		
	}
	$return = json_encode($return);
	echo $return;
}
//for getting single users information
if(isset($_GET['users'])&&isset($_GET['user_id'])){
	$user_id = $_GET['user_id'];
	$return = array();
	$result = mysqli_query($con,"SELECT * from users where user_id=$user_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}

//getting data of users for using as select list
if(isset($_GET['users'])&&isset($_GET['data'])){
	$return = array();
	if($_GET['users']=='all'){
		$result = mysqli_query($con,"SELECT  * from users");
	}else{
		$user_type = $_GET['users'];
	    $user_as = $user_type."_id";
	    $result = mysqli_query($con,"SELECT  u.user_id as $user_as,u.first_name,u.middle_name,u.last_name from users as u where u.user_type='$user_type' and status=1");
	}
	echo mysqli_error($con);
	if($result->num_rows>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}
	$return = json_encode($return);
	echo $return;
}

//for getting single medicine information
if(isset($_GET['medicine'])&&isset($_GET['medicine_id'])){
	$medicine_id = $_GET['medicine_id'];
	$return = array();
	$result = mysqli_query($con,"SELECT * from medicine where medicine_id=$medicine_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}

//for getting  all medicine information
if(isset($_GET['medicine'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT  m.*,ms.quantity,ms.price,ms.selling_price from medicine as m left join medicine_stock as ms on ms.medicine_id = m.medicine_id");
	echo mysqli_error($con);
	if($result->num_rows>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}
	$return = json_encode($return);
	echo $return;
}


//for getting  all room_type
if(isset($_GET['room_type'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT  * from room_type");
	echo mysqli_error($con);
	if($result->num_rows>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}
	$return = json_encode($return);
	echo $return;
}
//for getting single room information
if(isset($_GET['room'])&&isset($_GET['room_id'])){
	$room_id = $_GET['room_id'];
	$return = array();
	$result = mysqli_query($con,"SELECT * from room where room_id=$room_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}
//for getting  all rooms
if(isset($_GET['room'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT  r.*,rt.room_type from room as r inner join room_type as rt on rt.room_type_id = r.room_type_id");
	echo mysqli_error($con);
	if($result->num_rows>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}
	$return = json_encode($return);
	echo $return;
}
//for getting single Bed information
if(isset($_GET['bed'])&&isset($_GET['bed_id'])){
	$bed_id = $_GET['bed_id'];
	$return = array();
	$result = mysqli_query($con,"SELECT * from bed where bed_id=$bed_id");
	$row = mysqli_fetch_assoc($result);
	$row = json_encode($row);
	echo $row;
}
//for getting  all beds
if(isset($_GET['bed'])&&isset($_GET['data'])){
	$return = array();
	if(isset($_GET['room_id'])){
		$room_id = $_GET['room_id'];
		$result = mysqli_query($con,"SELECT * from bed where room_id=$room_id and status=1");
	}else{
	    $result = mysqli_query($con,"SELECT  b.*,r.room_name from bed as b inner join room as r on r.room_id = b.room_id");
	}
	echo mysqli_error($con);
	if($result->num_rows>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}
	$return = json_encode($return);
	echo $return;
}

//for getting  all beds
if(isset($_GET['bed_patient'])&&isset($_GET['data'])){
	$return = array();
	$result = mysqli_query($con,"SELECT bp.*,p.first_name,p.middle_name,p.last_name,r.room_name,b.bed_name from bed_patient as bp inner join patient as p on p.patient_id = bp.patient_id inner join room as r on r.room_id = bp.room_id inner join bed as b on b.bed_id = bp.bed_id");
	echo mysqli_error($con);
	if($result->num_rows>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}
	$return = json_encode($return);
	echo $return;
}

//for getting  all prescription of a particular patient_id
if(isset($_GET['prescription'])&&isset($_GET['data'])&&isset($_GET['patient_id'])){
	$return = array();
	$patient_id = $_GET['patient_id'];
	$result = mysqli_query($con,"select p.*,d.first_name,d.middle_name,d.last_name from prescription as p inner join users as d on d.user_id = p.doctor_id where p.patient_id = $patient_id");
	echo mysqli_error($con);
	if($result->num_rows>=1){
		while($row = mysqli_fetch_assoc($result)){
		array_push($return,$row);
		}
	}
	$return = json_encode($return);
	echo $return;
}

?>