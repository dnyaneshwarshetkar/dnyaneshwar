<?php
include('../connect.php');
session_start();
//Receive the RAW post data.
$content = trim(file_get_contents("php://input",true));
//Attempt to decode the incoming RAW post data from JSON.
//print_r($_POST);
//print_r($_FILES);
$decoded = $_POST;
 if($_GET['table']=='users'){
$parent_user_id = $_SESSION['user']["user_id"];//who added the user
$first_name = $decoded["first_name"];
$middle_name = $decoded["middle_name"];
$last_name = $decoded["last_name"];
$dob = $decoded["dob"];
$age = $decoded["age"];
$gender = $decoded["gender"];
$marital_status = $decoded["marital_status"];
$mobile = $decoded["mobile"];
$address = $decoded["address"];
$user_type = $decoded["user_type"];
$username = $decoded["username"];
$password  = $decoded["password"];
$email  = $decoded["email"];
$salary  = $decoded["salary"];
$target_file = "";
if($_FILES['image']){
$target_dir = "../uploads/profile/";
$file_name = time().basename($_FILES["image"]["name"]);
$target_file = $target_dir.$file_name;
$path = "uploads/profile/".$file_name;
$source_file = $_FILES['image']['tmp_name'];
move_uploaded_file($source_file,$target_file);
}
$image  = $path;
$education  = $decoded["education"];
$experience  = $decoded["experience"];
$specialization  = $decoded["specialization"];
if(isset($_GET['user_id'])){
	$user_id = $_GET['user_id'];
	$sql = "update users set parent_user_id='$parent_user_id',first_name='$first_name',middle_name='$middle_name',last_name='$last_name',dob='$dob',age='$age',gender='$gender',marital_status='$marital_status',mobile='$mobile',address='$address',user_type='$user_type',username='$username',password='$password',email='$email',salary='$salary',image='$image',education='$education',experience='$experience',specialization='$specialization' where user_id=$user_id";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The User Updated Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The User Not Updated".mysqli_error($con);
		echo json_encode($response);
	}
}else{
	$sql = "INSERT INTO  users(parent_user_id,first_name,middle_name,last_name,dob,age,gender,marital_status,mobile,address,user_type,username,password,email,salary,image,education,experience,specialization)values('$parent_user_id','$first_name','$middle_name','$last_name','$dob','$age','$gender','$marital_status','$mobile','$address','$user_type','$username','$password','$email','$salary','$image','$education','$experience','$specialization')";
	if($con->query($sql)){
		$response = array();
		$response['status'] ="SUCCESS";
		$response['message'] ="The User Added Successfully";
		echo json_encode($response);
	}
	else{
		$response = array();
		$response['status'] ="UNSUCCESS";
		$response['message'] ="The User Not Added ".mysqli_error($con);
		echo json_encode($response);
	}
}
}else{
	
}
 ?>
