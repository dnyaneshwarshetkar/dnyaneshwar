<?php

  session_start();

  require "connect.php";

  if(isset($_SESSION['admin']))

  {

    $uname=$_SESSION['admin'];

    $sql1 = "SELECT * FROM admin where Admin_id='$uname'";

    $result = $con->query($sql1);

    $fname = "";

    $lname = "";    

      $data = array();

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $fname=$row["fname"];

        $lname=$row["lname"];

        }

    }  

  } 

  else{

    header("location: index.php");

    }  



  if(isset($_POST['submit']))

  {

    $first=$_POST['name'];

    $last=$_POST['quan'];

    

    $sql = "INSERT INTO req(test,quantity) VALUES ('$first','$last')";

      if($con->query($sql)){

        echo "<script>alert('Added Succesfully');

       // window.location.assign('addStock.php');

         </script>";

      }

      else{

                die('Could not add data'.mysql_error());



      }

  }



  if(isset($_POST['save']))

  {

    $first=$_POST['name'];

    $price=$_POST['price'];

    $last=$_POST['quan'];

    

    $sql = "INSERT INTO cost(test,price,quantity) VALUES ('$first','$price','$last')";

      if($con->query($sql)){

        echo "<script>alert('Added Succesfully');

       // window.location.assign('addStock.php');

         </script>";

      }

      else{

                die('Could not add data'.mysql_error());



      }

  }

?>

<!DOCTYPE html>

<html lang="en">



<head>

  <meta charset="utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta name="description" content="">

  <meta name="author" content="">

  <title>Information | HMIS</title>

  <!-- Bootstrap core CSS-->

  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template-->

  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->

  <link href="css/sb-admin.css" rel="stylesheet">

</head>



<body class="fixed-nav sticky-footer bg-dark" id="page-top">

  <!-- Navigation-->

 <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">

    <a class="navbar-brand" href="admin.php"><?php echo $fname." ".$lname; ?></a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">

      <span class="navbar-toggler-icon"></span>

    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">

      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">

          <a class="nav-link" href="admin.php">

            <i class="fa fa-fw fa-dashboard"></i>

            <span class="nav-link-text">Dashboard</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">

          <a class="nav-link" href="bed.php">

            <i class="fa fa-fw fa-table"></i>

            <span class="nav-link-text">Bed Allotment</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">

          <a class="nav-link" href="admin_patient_list.php">

            <i class="fa fa-fw fa-table"></i>

            <span class="nav-link-text">Patient</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">

          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseMulti" data-parent="#exampleAccordion">

            <i class="fa fa-fw fa-sitemap"></i>

            <span class="nav-link-text">Registration</span>

          </a>

          <ul class="sidenav-second-level collapse" id="collapseMulti">

            <li>

              <a href="addDoc.php">Doctor</a>

            </li>

            <li>

              <a href="addNurse.php">Nurse</a>

            </li>

            <li>

              <a href="addAcc.php">Accountant</a>

            </li>

            <li>

              <a href="addPharma.php">Pharmacist</a>

            </li>

            <li>

              <a href="addLab.php">Laboratorist</a>

            </li>

            <li>

              <a href="addRec.php">Receptionist</a>

            </li>

          </ul>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">

          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseMulti1" data-parent="#exampleAccordion">

            <i class="fa fa-fw fa-sitemap"></i>

            <span class="nav-link-text">List</span>

          </a>

          <ul class="sidenav-second-level collapse" id="collapseMulti1">

            <li>

              <a href="list_doc.php">Doctor</a>

            </li>

            <li>

              <a href="list_nurse.php">Nurse</a>

            </li>

            <li>

              <a href="list_acc.php">Accountant</a>

            </li>

            <li>

              <a href="list_pharma.php">Pharmacist</a>

            </li>

            <li>

              <a href="list_lab.php">Laboratorist</a>

            </li>

            <li>

              <a href="list_rec.php">Receptionist</a>

            </li>

          </ul>

        </li>

       

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="admin_blood_bank.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Blood Bank</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="admin_blood_add.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Blood Donate</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="profile.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Profile</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="password.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Change Password</span>

          </a>

        </li>

      </ul>

      <ul class="navbar-nav sidenav-toggler">

        <li class="nav-item">

          <a class="nav-link text-center" id="sidenavToggler">

            <i class="fa fa-fw fa-angle-left"></i>

          </a>

        </li>

      </ul>

      <ul class="navbar-nav ml-auto">

        <li class="nav-item">

          <form class="form-inline my-2 my-lg-0 mr-lg-2">

            <div class="input-group">

              <input class="form-control" type="text" placeholder="Search for...">

              <span class="input-group-btn">

                <button class="btn btn-primary" type="button">

                  <i class="fa fa-search"></i>

                </button>

              </span>

            </div>

          </form>

        </li>

        <li class="nav-item">

          <a class="nav-link" href="logout_admin.php">

            <i class="fa fa-fw fa-sign-out"></i>Logout</a>

        </li>

      </ul>

    </div>

  </nav>

  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="admin.php">Dashboard</a>

        </li>

    		<li class="breadcrumb-item active">Information</li>

      </ol>

	  <br>

	  <div class="row">

        <div class="col-3">

          <a class="nav-link btn btn-primary btn-block" data-toggle="modal" data-target="#exampleModal">Order New </a>

        </div>

        <div class="col-3">

          <a class="nav-link btn btn-primary btn-block" data-toggle="modal" data-target="#exampleModal2">Add New </a>

        </div>

      </div>

	  <br><br>

      <div class="row">

        <div class="col-12">

          <h3>Stocks</h3>

        </div>

      </div>

	  <div class="row">

      <div class="col-md-12">

  	     <div class="card mb-3">

          <div class="card-header">

            <i class="fa fa-table"></i> Stock Table</div>

          <div class="card-body">

            <div class="table-responsive">

              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                <thead>

                  <tr>

                    <th>Item Name</th>

                    <th>Price per Head</th>

                    <th>Quantity</th>

                    </tr>

                </thead>

                <tbody>

                 <?php

                  $que="SELECT * FROM cost";

                  $res = $con->query($que);



                    while ($row = $res->fetch_assoc()) {

                      echo "<tr>";

                      echo "<td>".$row['test']."</td>";

                      echo "<td>".$row['price']."</td>";

                      echo "<td>".$row['quantity']."</td>";

                      echo "</tr>";

                    }

                  

                ?>             

                </tbody>

              </table>

            </div>

          </div>

          <div class="card-footer small text-muted"></div>

        </div>

      </div>

	  </div>

    </div>

    <!-- /.container-fluid-->

    <!-- /.content-wrapper-->

    <footer class="sticky-footer">

      <div class="container">

        <div class="text-center">

<small>Copyright © <a href="http://nishthaventures.com/"> nishthaventures.com  2018 </a> </small>

        </div>

      </div>

    </footer>

    <!-- Scroll to Top Button-->

    <a class="scroll-to-top rounded" href="#page-top">

      <i class="fa fa-angle-up"></i>

    </a>

	

	<!-- Logout Modal-->

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

      <div class="modal-dialog" role="document">

        <div class="modal-content">

          <div class="modal-header">

            <h5 class="modal-title" id="exampleModalLabel">Update Item</h5>

            <button class="close" type="button" data-dismiss="modal" aria-label="Close">

              <span aria-hidden="true">×</span>

            </button>

          </div>

          <div class="modal-body">

		  <form method="post" action="">

      <div class="form-group">

            <div class="form-row">

              <div class="col-md-6">

                <label for="exampleInputName">Item Name</label>

                <input name="name" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name">

              </div>

              <div class="col-md-6">

                <label for="exampleInputLastName">Quantity</label>

                <input name="quan" class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter last name">

              </div>

            </div>     		  

		  </div>

          <div class="modal-footer">

            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>

            <input type="submit" name="submit" class="btn btn-primary"/>

          </div>

          </form>

        </div>

      </div>

    </div>

</div>

    <!-- -->



    <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

      <div class="modal-dialog" role="document">

        <div class="modal-content">

          <div class="modal-header">

            <h5 class="modal-title" id="exampleModalLabel">Add Item</h5>

            <button class="close" type="button" data-dismiss="modal" aria-label="Close">

              <span aria-hidden="true">×</span>

            </button>

          </div>

          <div class="modal-body">

      <form method="post" action="">

      <div class="form-group">

            <div class="form-row">

              <div class="col-md-12">

                <label for="exampleInputName">Item Name</label>

                <input name="name" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name">

              </div>

            </div>

            <div class="form-row">

              <div class="col-md-6">

                <label for="exampleInputName">Price</label>

                <input name="price" class="form-control" id="exampleInputName" type="number" aria-describedby="nameHelp" placeholder="Enter first name">

              </div>

              <div class="col-md-6">

                <label for="exampleInputLastName">Quantity</label>

                <input name="quan" class="form-control" id="exampleInputLastName" type="number" aria-describedby="nameHelp" placeholder="Enter last name">

              </div>

            </div>          

      </div>

          <div class="modal-footer">

            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>

            <input type="submit" name="save" class="btn btn-primary"/>

          </div>

          </form>

        </div>

      </div>

    </div>

    <!-- Bootstrap core JavaScript-->

    <script src="vendor/jquery/jquery.min.js"></script>

    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->

    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->

    <script src="js/sb-admin.min.js"></script>

  </div>

</body>



</html>

