<?php
  session_start();
  require "connect.php";
  if(isset($_SESSION['username']))
  {
    $uname=$_SESSION['username'];
    $sql1 = "SELECT * FROM receptionist where rec_id='$uname'";
    $result = $con->query($sql1);
    $fname = "";
    $lname = "";    
      $data = array();
    if ($result->num_rows==1) 
    {
      while($row = $result->fetch_assoc()) 
      {
        $fname=$row["fname"];
        $lname=$row["lname"];
        }
    }  
  } 
  else{
    header("location: index.php");
    }

    if(isset($_POST['submit']))
  {
    $Pname=$_POST['Pname'];
    $Page=$_POST['Page'];
    $rea=$_POST['rea'];
    $gen=$_POST['gen'];
    $Nrel=$_POST['Nrel'];
    $Nname=$_POST['Nname'];
    $dod=$_POST['dod'];
    $cont=$_POST['con'];
    $addr=$_POST['addr'];
  // echo $first1;posi
    $sql =  "INSERT INTO death_report (Name, age, gen, Reason, Nrel, Nname, Contact, Address, dod) VALUES ('$Pname', '$Page', '$gen', '$rea', '$Nrel','$Nname', '$cont', '$addr', '$dod');";
      
      if($con->query($sql)){
        echo "<script>alert('Added Succesfully');
       // window.location.assign('rec_death.php');
         </script>";
      }
      else{
                die('Could not add data'.mysql_error());

      }
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>SB Admin - Start Bootstrap Template</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="receptionist.php"><?php echo $fname." ".$lname; ?></a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="receptionist.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="rec_patient_list.php">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">Patient List</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Charts">
          <a class="nav-link" href="patient.php">
            <i class="fa fa-fw fa-area-chart"></i>
            <span class="nav-link-text">Add Patients</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="appointment.php">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">Appointments</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Charts">
          <a class="nav-link" href="request.php">
            <i class="fa fa-fw fa-area-chart"></i>
            <span class="nav-link-text">Requests</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="rec_birth.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Birth Report</span>
          </a>
        </li><li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="rec_death.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Death Report</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="rec_payroll.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Payroll</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="rec_profile.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Profile</span>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <form class="form-inline my-2 my-lg-0 mr-lg-2">
            <div class="input-group">
              <input class="form-control" type="text" placeholder="Search for...">
              <span class="input-group-btn">
                <button class="btn btn-primary" type="button">
                  <i class="fa fa-search"></i>
                </button>
              </span>
            </div>
          </form>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Death Report</li>
      </ol>
      <br>
      <div class="row">
        <div class="col-3">
          <a class="nav-link btn btn-primary btn-block" data-toggle="modal" data-target="#exampleModal">Add New </a>
        </div>
      </div>
    <br>
     <div class="row">
        <div class="col-12">
          <h3>Death Report</h3><br>
        </div>
      </div>
    <div class="row">
      <div class="col-md-12">
    <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Data Table Example</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Age</th>
                  <th>Gender</th>
                  <th>Reason</th>
                  <th>Nominee Relation</th>
                  <th>Nominee Name</th>
                  <th>Contact</th>
                  <th>Address</th>
                  <th>date of death</th>
                </tr>
              </thead>
              <tbody>
              <?php
                $que="SELECT * FROM death_report";
                $res = $con->query($que);

                  while ($row = $res->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row['Name']."</td>";
                    echo "<td>".$row['age']."</td>";
                    echo "<td>".$row['gen']."</td>";
                    echo "<td>".$row['Reason']."</td>";
                    echo "<td>".$row['Nrel']."</td>";
                    echo "<td>".$row['Nname']."</td>";
                    echo "<td>".$row['Contact']."</td>";
                    echo "<td>".$row['Address']."</td>";
                    echo "<td>".$row['dod']."</td>";
                    echo "</tr>";
                  }
                
              ?>
       
              </tbody>
            </table>
          </div>
        </div>
        <div class="card-footer small text-muted"></div>
      </div>
      </div>
    </div>

        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add New Nurse</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">
          <form method="post" action="">
      <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">Patient Name</label>
                <input name="Pname" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name">
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Patient Age</label>
                <input name="Page" class="form-control" id="exampleInputLastName" type="integer" aria-describedby="nameHelp" placeholder="Enter last name">
              </div>
            </div>
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">Reason</label>
                <input name="rea" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name">
              </div>
              <div class="col-md-6">
                <label for="exampleInputName">Gender</label>
                <select name="gen" class="form-control" id="exampleInputName" aria-describedby="nameHelp">
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="col-md-12">
                <label for="exampleInputName">Date of Death</label>
                <input name="dod" class="form-control" id="exampleInputName" type="date" aria-describedby="nameHelp" placeholder="Enter Date">
              </div>
            </div>
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">Nominee Relation</label>
                <input name="Nrel" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name">
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Nominee Name</label>
                <input name="Nname" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name">
              </div>
            </div>
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">Contact</label>
                <input name="con" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="Enter first name">
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Address</label>
                <input name="addr" class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter Contact No">
              </div>
            </div>
      </div>
      </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <input type="submit" name="submit" class="btn btn-primary"/>
          </div>
          </form>
        </div>
      </div>
    </div>

    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->

    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © HMIS 2017</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
  </div>
</body>

</html>
