<?php include("header.php");?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="admin.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Profile</li>
      </ol>
		<form onsubmit="return submitData(event)">
		  <div class="form-row">
			<div class="form-group col-md-4">
			  <label for="first_name">First Name</label>
			  <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter First Name" required>
			</div>
			<div class="form-group col-md-4">
			  <label for="middle_name">Middle Name</label>
			  <input type="text" class="form-control" id="middle_name" name="middle_name" placeholder="Enter Middle Name" required>
			</div>
			<div class="form-group col-md-4">
			  <label for="last_name">Last Name</label>
			  <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter Last Name" required>
			</div>
		  </div>
		  <div class="form-row">
			<div class="form-group col-md-4">
			  <label for="email">Email</label>
			  <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email">
			</div>
			<div class="form-group col-md-4">
			  <label for="mobile">Mobile</label>
			  <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Enter Mobile">
			</div>
			<div class="form-group col-md-2">
			  <label for="image">Image</label>
			  <input type="file" class="form-control" id="image" name="image1" placeholder="Choose Profile Photo">
			</div>
			<div class="col-sm-2">
				<img id="profile" class="img-thumbnail profimg" src="images/exam.jpg"/>
			</div>
		  </div>
		<div class="form-row">
			<div class="form-group col-md-4">
			  <label for="dob">DOB</label>
			  <input type="date" class="form-control" id="dob" name="dob" placeholder="Select Date of Birth">
			</div>
			<div class="form-group col-md-4">
				<label for="age">Age</label>
				<input type="text" class="form-control" name="age" id="age" placeholder="Your Age"/>
			</div>
			<div class="form-group col-md-4">
			  <label for="dob">Gender</label>
			   <div class="form-check">
				<input type="radio" name="gender" value="male">
				<label for="male">Male</label>
				<input type="radio" name="gender" value="female">
				<label for="female">Female</label>
			   </div>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
			  <label for="education">Education</label>
			  <textarea class="form-control" id="education" name="education" placeholder="Enter Educational Details"></textarea>
			</div>
			<div class="form-group col-md-4">
			  <label for="experience">Experience</label>
			  <textarea class="form-control" id="experience" name="experience" placeholder="Enter Experience Details"></textarea>
			</div>
			<div class="form-group col-md-4">
			  <label for="specialization">Specialization</label>
			  <textarea class="form-control" id="specialization" name="specialization" placeholder="Enter Specialization"></textarea>
			</div>
		  </div>
		  <button type="submit" class="btn btn-primary">Submit</button>
	  </form>
    </div>
	 </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
	<?php include("footer.php"); ?>
	<script src="js/profile.js"></script>
</body>

</html>
