//  patient selection

function autocompleta(){
  var min_length = 0;
  var keyword = $('#patt').val();
  if (keyword.length >= min_length) {
    $.ajax({
      url:'ajax_refresh_pat.php',
      type:'POST',
      data: {keyword:keyword},
      success:function(data){
        $('#patt_id').show();
        $('#patt_id').html(data);
      }
    });
  }else{
    $('#patt_id').hide();
  }
}

function set_itema(item){
  $('#patt').val(item);
  $('#patt_id').hide();
}

function autocompletaa(){
  var min_length = 0;
  var keyword = $('#patta').val();
  if (keyword.length >= min_length) {
    $.ajax({
      url:'ajax_refresh_pat1.php',
      type:'POST',
      data: {keyword:keyword},
      success:function(data){
        $('#patt_ida').show();
        $('#patt_ida').html(data);
      }
    });
  }else{
    $('#patt_ida').hide();
  }
}

function set_itema1(item){
  $('#patta').val(item);
  $('#patt_ida').hide();
}