<?php include("header.php") ?>
  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="admin.php">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">Patient List</li>

      </ol>

		 <!--<div class="btn-group btn-group-sm mb-2" role="group">
		
				<button class="btn btn-secondary" data-toggle="modal" data-target="#roomModal"  data-backdrop="static" >Add Patient</button>
			
		  </div>-->
          <div class="table-responsive">

            <table class="table table-bordered" id="patientTable" width="100%" cellspacing="0">

              <thead>

                <tr>

                  <th>Sr.No</th>

                  <th>Patient Name</th>
				  
				  <th>Doctor Name</th>

                  <th>Gender</th>

                  <th>Age</th>

                  <th>Marital Status</th>

                  <th>Address</th>

                  <th>Mobile</th>
				  
				  <th>Status</th>
				  
				  <th>Manage</th>

                </tr>

              </thead>

              <tbody>
			  
              </tbody>

            </table>

          </div>
		  
		  <!--modal for Allocate Bed-->
		<div class="modal" tabindex="-1" role="dialog" id="prescriptionModal">
		  <div role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Prescription</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
			      <h6 class="text-center"></h6>
				  <div class="table-responsive">

						<table class="table table-bordered table-condensed" id="prescriptionTable" width="100%" cellspacing="0">

						  <thead>

							<tr>

							  <th>Sr</th>

							  <th>Type</th>
							  
							  <th>Drug</th>

							  <th>Dose</th>

							  <th>Freq</th>

							  <th>Days</th>

							  <th>Quan</th>

							  <th>Instruct</th>
							  
							  <th>Add</th>

							</tr>
							<form  name="prescriptionForm" id="prescriptionForm" onsubmit="return addPrescription(event)">
							<tr>

							  <th>#</th>

							  <th>
								  <select name="medicine_type" class="form-control" id="medicine_type" required />
										<option value="">Select Type</option>
										<option value="syrup">SYRUP</option>
										<option value="drops">DROPS</option>
										<option value="capsule">CAPSULE</option>
								   </select>
							  </th>
							  
							  <th> <input type="text" name="drug_name"  class="form-control typeahead" autocomplete="off" id="drug_name" required /></th>

							  <th> <input type="text" name="dose"  class="form-control" id="dose" required /></th>

							  <th><select name="frequency" class="form-control" id="frequency" required />
										<option value="">Select Type</option>
										<option value="1-0-0">1-0-0</option>
										<option value="0-1-0">0-1-0</option>
										<option value="0-0-1">0-0-1</option>
										<option value="1-1-0">1-1-0</option>
										<option value="1-0-1">1-0-1</option>
										<option value="0-1-1">0-1-1</option>
										<option value="0-0-1">1-1-1</option>
								   </select>
							 </th>

							  <th><input type="number" name="days"  class="form-control" id="days" required /></th>

							  <th> <input type="number" name="quantity"  class="form-control" id="quantity" required /></th>

							  <th> <input type="text" name="instructions"  class="form-control" id="instructions" required /></th>
							  
							  <th><button type="submit" class="btn btn-success">+</button></th>

							</tr>
			                </form>
						  </thead>
						  <tbody class="selectedMedicines">
						  </tbody>
						</table>

					  </div>
					  <h5>Prescription History</h5>
					  <div class="table-responsive">

						<table class="table table-bordered table-condensed" id="prescriptionHistoryTable" width="100%" cellspacing="0">

						  <thead>

							<tr>

							  <th>Sr</th>

							  <th>Doctor Name</th>
							  
							  <th>Date</th>
							  
							  <th>Date Modified</th>
							  
							  <th>Manage</th>

							</tr>
						  </thead>
						  <tbody>
						  </tbody>
						</table>
					  </div>
					  
					  
			  </div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success" onclick="submitPrescription()">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			</div>
		  </div>
		</div>
		  

    </div>
</div>
<?php include("footer.php"); ?>
<script src="js/patient.js"></script>
<script type="text/html" id="medicine">
	<tr>

		  <td data-content="sr_no">Sr</td>

		  <td data-content="medicine_type">Type</td>
		  
		  <td data-content="drug_name">Drug</td>

		  <td data-content="dose">Dose</td>

		  <td data-content="frequency">Freq</td>

		  <td data-content="days">Days</td>

		  <td data-content="quantity">Quan</td>

		  <td data-content="instructions">Instruct</td>
		  
		  <td><button type="button" class="btn btn-danger" data-value="sr_no" onclick="removePrescription(this.value)">-</button></td>

	</tr>
</script>
<script type="text/html" id="prescriptionReceipt">
	<section>
		<div class="col-sm-6">
		<h1>Deshmukh Hospital,<small class="text-muted">Itwara Bazar,Nanded-431604</small></h1>
		</div>
		<div class="col-sm-6">
		<h1>Dr. P. D. Deshmukh ,<small class="text-muted">MD,Nanded-431604</small></h1>
		</div>
	</section>
	<section>
		<div><div>Name : </div><div>Address : </div><div>Weight : </div></div>
		<div><div>Age : </div><div>Sex : </div><div>Date : </div></div>
	</section>
	<section>
		<div>Clinical Notes : FEVER,COUGH,LOOSE,MOTION</div>
	</section>
	<div class="table-responsive">
		<table class="table table-bordered">
			<thead>
				<tr>

					  <th>Sr</th>

					  <th>Type</th>
					  
					  <th>Drug</th>

					  <th>Dose</th>

					  <th>Freq</th>

					  <th>Days</th>

					  <th>Quan</th>

					  <th>Instruct</th>
					  
				</tr>
			</thead>
			<tbody>
			</tbody>
		</table>
	</div>
</script>
</body>

</html>