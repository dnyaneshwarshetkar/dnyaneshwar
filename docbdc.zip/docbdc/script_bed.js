function autocomplet(){
  var min_length = 0;
  var keyword = $('#gp').val();
  if (keyword.length >= min_length) {
    $.ajax({
      url:'ajax_refresh_bed.php',
      type:'POST',
      data: {keyword:keyword},
      success:function(data){
        $('#par').show();
        $('#par').html(data);
      }
    });
  }else{
    $('#par').hide();
  }
}

function set_item(item){
  $('#gp').val(item);
  $('#par').hide();
}

function autocompleta(){
  var min_length = 0;
  var keyword = $('#gpa').val();
  if (keyword.length >= min_length) {
    $.ajax({
      url:'ajax_refresh_bed1.php',
      type:'POST',
      data: {keyword:keyword},
      success:function(data){
        $('#para').show();
        $('#para').html(data);
      }
    });
  }else{
    $('#para').hide();
  }
}

function set_itema(item){
  $('#gpa').val(item);
  $('#para').hide();
}