//    doctor selection
function autocomplet(){
  var min_length = 0;
  var keyword = $('#to').val();
  if (keyword.length >= min_length) {
    $.ajax({
      url:'ajax_refresh.php',
      type:'POST',
      data: {keyword:keyword},
      success:function(data){
        $('#Doctor_id').show();
        $('#Doctor_id').html(data);
      }
    });
  }else{
    $('#Doctor_id').hide();
  }
}

function set_item(item){
  $('#to').val(item);
  $('#Doctor_id').hide();
}