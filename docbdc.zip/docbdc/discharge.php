<?php
	session_start();
  require "connect.php";
	$pat= $_GET["Patient_id"];
	
	
	$time2=date('Y-m-d H:i:s');

	$sql = "SELECT bed_id AS B FROM allot WHERE Patient_id='$pat' AND status='occupied'";
    $result = $con->query($sql);
    $row = $result->fetch_assoc();
    $old = $row['B'];
 
    $sql = "SELECT price AS P FROM bed where bed_id='$old'";
    $result = $con->query($sql);
    $row = $result->fetch_assoc();
    $price = $row['P'];
     
    //for time of first allotment
    $sql = "SELECT allot_time FROM allot WHERE Patient_id='$pat' AND status='occupied' AND bed_id='$old'";
    $result = $con->query($sql);
    $time3=""; 
    if ($result->num_rows==1) 
    {
      while($row = $result->fetch_assoc()) 
      {
        $time3=$row["allot_time"];
      }
    }
    $abc=$time3;
      //calculate differance
      $sql7="SELECT TIMESTAMPDIFF(DAY, '$abc', '$time2') AS T";
      $res = $con->query($sql7);
      $row = $res->fetch_assoc();
      $abc=$row['T'];
      if($abc==0){
        $abc=1;
      }
      $res2=$abc*$price; 

    //unoccupied
      $sql1 = "UPDATE allot SET left_time='$time2',status='unocupied',cost='$res2',cost_status='unpaid' WHERE Patient_id='$pat' AND status='occupied' AND bed_id='$old'";
      
    //inactive
      $sql2 = "UPDATE bed SET status='' WHERE bed_id='$old'";

      if($con->query($sql1) && $con->query($sql2)){
        echo "<script>alert('Added Succesfully');
        	     window.history.back();
         </script>";
      }
      else{
                die('Could not add data'.mysql_error());

      }


?>
