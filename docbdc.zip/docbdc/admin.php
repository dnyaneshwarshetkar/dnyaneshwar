<?php include("header.php"); ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="admin.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Home</li>
      </ol>
	  <!-- Test Part-->
	  <div class="row">
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-primary o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-heartbeat"></i>
              </div>
              <?php
                  $sql3 = "SELECT COUNT(user_id) FROM users";
                  $result = $con->query($sql3);
                  $rows = mysqli_fetch_row($result);
               ?>
              <div class="mr-5"><b> <?php echo $rows[0]; ?></b></div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="user.php">
              <span class="float-left">Users</span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-danger o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-toggle-on"></i>
              </div>
              <?php
                  $sql3 = "SELECT COUNT(medicine_id) FROM medicine";
                  $result = $con->query($sql3);
                  $rows = mysqli_fetch_row($result);
                  
               ?>
              <div class="mr-5"><b><?php echo $rows[0]; ?></b></div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="medicine.php">
              <span class="float-left">Medicine</span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-warning o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-hotel"></i>
              </div>
              <?php
                  $sql3 = "SELECT COUNT(bed_id) FROM bed";
                  $result = $con->query($sql3);
                  $rows = mysqli_fetch_row($result);
                  
               ?>
              <div class="mr-5"><b><?php echo $rows[0]; ?> </b></div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="bed.php">
              <span class="float-left">Bed</span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-primary o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-tint"></i>
              </div>
               <?php
                  $sql3 = "SELECT COUNT(test) FROM cost";
                  $result = $con->query($sql3);
                  $rows = mysqli_fetch_row($result);
                  
               ?>
              <div class="mr-5"><b><?php echo $rows[0]; ?></b></div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="addStock.php">
              <span class="float-left">Stock</span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-secondary o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-ambulance "></i>
              </div>
              <?php
                  $sql3 = "SELECT COUNT(patient_id) FROM patient";
                  $result = $con->query($sql3);
                  $rows = mysqli_fetch_row($result);
                  
               ?>
              <div class="mr-5"><b><?php echo $rows[0]; ?></b></div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="patient.php">
              <span class="float-left">Patient</span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-dark o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-ambulance "></i>
              </div>
              <?php
                  $sql3 = "SELECT COUNT(Baby_gen) FROM birth_report";
                  $result = $con->query($sql3);
                  $rows = mysqli_fetch_row($result);
                  
               ?>
              <div class="mr-5"><b><?php echo $rows[0]; ?></b></div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="admin_birth.php">
              <span class="float-left">Birth Report</span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-3">
          <div class="card text-white bg-info o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-ambulance "></i>
              </div>
              <?php
                  $sql3 = "SELECT COUNT(Name) FROM death_report";
                  $result = $con->query($sql3);
                  $rows = mysqli_fetch_row($result);
                  
               ?>
              <div class="mr-5"><b><?php echo $rows[0]; ?></b></div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="admin_death.php">
              <span class="float-left">Death Report</span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
      </div>
	  <!-- Test Part -->
	  <br><br>
    </div>
	</div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
<?php include("footer.php"); ?>

</body>

</html>
