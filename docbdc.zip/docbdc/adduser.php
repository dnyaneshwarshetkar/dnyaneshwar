<?php include("header.php"); ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="receptionist.php">Dashboard</a>
        </li>
        <?php if(isset($_GET['user_id'])){?>
        <li class="breadcrumb-item active">Edit User</li>
		<?php }else{ ?>
		<li class="breadcrumb-item active">Add User</li>
		<?php } ?>
      </ol>
	  <?php if(isset($_GET['user_id'])){ ?>
		<h5>Edit User</h5>
	  <?php }else{ ?>
		<h5>Add User</h5>
	  <?php } ?>
		  <?php if(isset($_GET['user_id'])){ ?>
      <form name="addUserForm" onsubmit="return submitData(event,<?php echo $_GET['user_id']?>)" id="addUserForm" enctype="multipart/form-data">
	  <?php }else{ ?>
	  <form name="addUserForm" onsubmit="return submitData(event)" id="addUserForm"  enctype="multipart/form-data">
	  <?php } ?>
			<div class="form-row">
				<div class="form-group col-md-4">
				  <label for="first_name">First Name</label>
				  <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter First Name" required>
				</div>
				<div class="form-group col-md-4">
				  <label for="middle_name">Middle Name</label>
				  <input type="text" class="form-control" id="middle_name" name="middle_name" placeholder="Enter Middle Name" required>
				</div>
				<div class="form-group col-md-4">
				  <label for="last_name">Last Name</label>
				  <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter Last Name" required>
				</div>
			</div>
			<div class="form-row">
				<div class="form-group col-md-4">
				  <label for="dob">DOB</label>
				  <input type="date" class="form-control" id="dob" name="dob" placeholder="Select Date of Birth" onchange="setAge(this.value)">
				</div>
				<div class="form-group col-md-4">
				<label for="age">Age</label>
				<input type="text" class="form-control" name="age" id="age" placeholder="Your Age" readonly/>
			  </div>
				<div class="form-group col-md-4">
				  <label for="dob">Gender</label>
				   <div class="form-check">
					<input type="radio" name="gender" id="male" value="male">
					<label for="male">Male</label>
					<input type="radio" name="gender" id="female" value="female">
					<label for="female">Female</label>
				   </div>
				</div>
			</div>
			<div class="form-row">
			  <div class="form-group col-md-4">
                <label for="marital_status">Marital Status</label>
                <select name="marital_status" class="form-control" id="marital_status">
					<option value="">Select Marital Status</option>
					<option value="0">Married</option>
					<option value="1">Unmarried</option>
				</select>
              </div>
				<div class="form-group col-md-4">
				  <label for="mobile">Mobile</label>
				  <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Enter Mobile">
				</div>
				<div class="form-group col-md-4">
				<label for="address">Address</label>
				<textarea name="address" class="form-control" id="address" placeholder="Enter Address"></textarea>
				</div>
			</div>
      <div class="form-row">
        <div class="form-group col-md-4">
          <label for="user_type">Select User Type</label>
           <select name="user_type" class="form-control" id="user_type">
				<option value="">Select User Type</option>
				<option value="admin">Admin</option>
				<option value="doctor">Doctor</option>
				<option value="receptionist">Receptionist</option>
				<option value="accountant">Accountant</option>
				<option value="laboratorist">Laboratorist</option>
				<option value="nurse">Nurse</option>
				<option value="pharmacist">Pharmacist</option>
		   </select>
        </div>
		<div class="form-group col-md-4">
				  <label for="username">User Name</label>
				  <input type="text" class="form-control" id="username" name="username" placeholder="Enter User Name"/>
				</div>
				<div class="form-group col-md-4">
				  <label for="password">Password</label>
				  <input type="text" class="form-control" id="password" name="password" placeholder="Enter Password"/>
				</div>
      </div>
	<div class="form-row">
	  <div class="form-group col-md-4">
				  <label for="email">Email</label>
				  <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email"/>
				</div>
	  <div class="form-group col-md-4">
				  <label for="salary">Salary</label>
				  <input type="integer" class="form-control" id="salary" name="salary" placeholder="Enter Salary">
				</div>
		<div class="form-group col-md-2">
			  <label for="image">Image(profile)</label>
			  <input type="file" class="form-control" id="image" name="image" placeholder="Select Image"/>
		</div>
		<div class="form-group col-md-2">
			 <img id="profile" class="profimg" alt="the profile is not set"/>
		</div>
     </div>
	<div class="form-row">
	  <div class="form-group col-md-4">
			  <label for="education">Education</label>
			  <textarea class="form-control" id="education" name="education" placeholder="Enter Education"></textarea>
		</div>
		<div class="form-group col-md-4">
			  <label for="experience">Experience</label>
			  <textarea class="form-control" id="experience" name="experience" placeholder="Enter Experience"></textarea>
		</div>
		<div class="form-group col-md-4">
			  <label for="specialization">Specialization</label>
			  <textarea class="form-control" id="specialization" name="specialization" placeholder="Enter Specialization"></textarea>
		</div>
     </div>
	<button type="submit" class="btn btn-primary">Submit</button>
	<button type="reset" class="btn btn-primary">Reset</button>
     </form>
    </div>
	</div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php include("footer.php");?>
	<script src="js/adduser.js"></script>
</body>

</html>
