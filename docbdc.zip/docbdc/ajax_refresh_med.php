<?php
function connect(){
	return new PDO('mysql:host=148.72.232.170:3306;dbname=newhospitaldb','hmsdbuser','nishtha@8989',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::MYSQL_ATTR_INIT_COMMAND =>"SET NAMES utf8"));
}

$pdo = connect();
$keyword = '%'.$_POST['keyword'].'%';
$query='';
$sql = "SELECT * FROM medical WHERE Medicine_name LIKE (:keyword) ORDER BY Medicine_name ASC LIMIT 0,10";
$query = $pdo->prepare($sql);
$query->bindParam(':keyword', $keyword);
$query->execute();
$list = $query->fetchAll();
foreach($list as $rs){
	$med = str_replace($_POST['keyword'], '<b>'.$_POST['keyword'].'<b>', $rs['Medicine_name']);
	echo '<li id="mid" onclick="set_item(\''.str_replace("'","\'", $rs['Medicine_name']).'\')">'.$med.'</li>';
}
?>