<?php
function connect(){
	return new PDO('mysql:host=148.72.232.170:3306;dbname=newhospitaldb','hmsdbuser','nishtha@8989',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::MYSQL_ATTR_INIT_COMMAND =>"SET NAMES utf8"));
}

$pdo = connect();
$keyword = '%'.$_POST['keyword'].'%';
$query='';
$sql = "SELECT * FROM doctor WHERE Doctor_id LIKE (:keyword) OR specification LIKE (:keyword) ORDER BY Doctor_id ASC LIMIT 0,10";
$query = $pdo->prepare($sql);
$query->bindParam(':keyword', $keyword);
$query->execute();
$list = $query->fetchAll();
foreach($list as $rs){
	$Doctor_id = str_replace($_POST['keyword'], '<b>'.$_POST['keyword'].'<b>', $rs['Doctor_id']);
	 $Spec = str_replace($_POST['keyword'], '<b>'.$_POST['keyword'].'<b>', $rs['specification']);
	echo '<li id="Doc" onclick="set_item(\''.str_replace("'","\'", $rs['Doctor_id']).'\')">'.$Doctor_id.'-'.$Spec.'</li>';
}
?>