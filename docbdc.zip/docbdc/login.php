<?php
	session_start();
	ini_set('display_errors', 1); 
	error_reporting(E_ALL);
    require "connect.php";
   if(isset($_POST['username']) && isset($_POST['password']) )
   {
		$username = $_POST['username'];
		$password = $_POST['password']; 
		$_SESSION['username']=$username;
		$_SESSION['passsword']=$password;
		$sql="SELECT  * FROM users as u WHERE first_name = '$username' AND mobile = '$password' AND status=1";
		if($result = $con->query($sql)){
			if($result->num_rows==1){//uniqueness of user is checked.
				$user = $result->fetch_assoc();
				$_SESSION['user'] = $user;
				$user_type = (string)$user['user_type'];
				switch($user_type){
					case "admin":
						header('Location: admin.php');
						break;
					case "doctor" :
						header('Location: doctor.php');
						break;
					case "accountant" :
						header('Location: accountant.php');
						break;
					case "laboratorist" :
						header('Location: laboratorist.php');
						break;
					case "nurse" :
						header('Location: nurse.php');
						break;
					case "pharmacist" :
						header('Location: pharmacist.php');
						break;
					case "receptionist" :
						header('Location: receptionist.php');
						break;
					default : 
						header('Location: index.php');
						break;
				}
			}
			if($result->num_rows>1){
				echo "<script>alert('There are more than one user having same first_name and mobile number');window.location.assign('index.php');</script>";
			}
			if($result->num_rows==0){
				echo "<script>alert('Sorry No Such Active User Found..Contact Administrator');window.location.assign('index.php');</script>";
			}
		}else{
			echo $con->error;
		}
   }else{
	   echo "Bye-Bye";
   }
?>
