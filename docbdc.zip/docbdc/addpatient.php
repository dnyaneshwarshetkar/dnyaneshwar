<?php include("header.php"); ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="receptionist.php">Dashboard</a>
        </li>
        <?php if(isset($_GET['patient_id'])){?>
        <li class="breadcrumb-item active">Edit Patient</li>
		<?php }else{ ?>
		<li class="breadcrumb-item active">Add Patient</li>
		<?php } ?>
      </ol>
	  <?php if(isset($_GET['patient_id'])){ ?>
		<h5>Edit Patient</h5>
	  <?php }else{ ?>
		<h5>Add Patient</h5>
	  <?php } ?>
		  <?php if(isset($_GET['patient_id'])){ ?>
      <form name="addPatientForm" onsubmit="return submitData(event,<?php echo $_GET['patient_id']?>)" id="addPatientForm">
	  <?php }else{ ?>
	  <form name="addPatientForm" onsubmit="return submitData(event)" id="addPatientForm">
	  <?php } ?>
			<div class="form-row">
				<div class="form-group col-md-4">
				  <label for="first_name">First Name</label>
				  <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter First Name" required>
				</div>
				<div class="form-group col-md-4">
				  <label for="middle_name">Middle Name</label>
				  <input type="text" class="form-control" id="middle_name" name="middle_name" placeholder="Enter Middle Name" required>
				</div>
				<div class="form-group col-md-4">
				  <label for="last_name">Last Name</label>
				  <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter Last Name" required>
				</div>
			</div>
			<div class="form-row">
				<div class="form-group col-md-4">
				  <label for="dob">DOB</label>
				  <input type="date" class="form-control" id="dob" name="dob" placeholder="Select Date of Birth" onchange="setAge(this.value)">
				</div>
				<div class="form-group col-md-4">
				<label for="age">Age</label>
				<input type="text" class="form-control" name="age" id="age" placeholder="Your Age" readonly/>
			  </div>
				<div class="form-group col-md-4">
				  <label for="dob">Gender</label>
				   <div class="form-check">
					<input type="radio" name="gender" id="male" value="male">
					<label for="male">Male</label>
					<input type="radio" name="gender" id="female" value="female">
					<label for="female">Female</label>
				   </div>
				</div>
			</div>
			<div class="form-row">
			  <div class="form-group col-md-4">
                <label for="marital_status">Marital Status</label>
                <select name="marital_status" class="form-control" id="marital_status">
					<option value="">Select Marital Status</option>
					<option value="0">Married</option>
					<option value="1">Unmarried</option>
				</select>
              </div>
				<div class="form-group col-md-4">
				  <label for="mobile">Mobile</label>
				  <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Enter Mobile">
				</div>
				<div class="form-group col-md-4">
				<label for="address">Address</label>
				<textarea name="address" class="form-control" id="address" placeholder="Enter Address"></textarea>
				</div>
			</div>
      <div class="form-row">
        <div class="form-group col-md-4">
          <label for="doctor_id">Allocate Doctor</label>
           <select name="doctor_id" class="form-control" id="doctor_id" placeholder="Enter Doctor">
				<option value="">Select</option>
		   </select>
        </div>
        <div class="form-group col-md-4">
          <label for="appointment_slot">Appointment Slot</label>
			<select name="appointment_slot" class="form-control" id="appointment_slot">
				<option value="">Select Appointment</option>
				  <option value="1">06:00 AM - 06:59 AM</option>
				  <option value="2">07:00 AM - 07:59 AM</option>
				  <option value="3">08:00 AM - 08:59 AM</option>
				  <option value="4">09:00 AM - 09:59 AM</option>
				  <option value="5">10:00 AM - 10:59 AM</option>
				  <option value="6">11:00 AM - 11:59 AM</option>
				  <option value="7">00:00 PM - 00:59 PM</option>
				  <option value="8">01:00 PM - 01:59 PM</option>
				  <option value="9">02:00 PM - 02:59 PM</option>
				  <option value="10">03:00 PM - 03:59 PM</option>
				  <option value="11">04:00 PM - 04:59 PM</option>
				  <option value="12">05:00 PM - 05:59 PM</option>
				  <option value="13">06:00 PM - 06:59 PM</option>
				  <option value="14">07:00 PM - 07:59 PM</option>
				  <option value="15">08:00 PM - 08:59 PM</option>
				  <option value="16">09:00 PM - 09:59 PM</option>
			</select>
        </div>
		<div class="form-group col-md-4">
		  <label for="height">Height</label>
			<input type="text" name="height" class="form-control" id="height" placeholder="Height in cm">
		</div>
      </div>
    <div class="form-row">
		<div class="form-group col-md-4">
		  <label for="weight">Weight</label>
			<input type="text" name="weight" class="form-control" id="weight" placeholder="Weight in kg">        
		</div>
		<div class="form-group col-md-4">
		  <label for="temperature">Temperature</label>
			<input type="text" name="temperature" class="form-control" id="temperature" placeholder="Temparature in Fh">     
		</div>
		<div class="form-group col-md-4">
		  <label for="blood_pressure">Blood Pressure</label>
		  <input type="text" name="blood_pressure" class="form-control" id="blood_pressure" placeholder="BP in mmHg">        
		</div>
	</div>
	<div class="form-row">
		<div class="form-group col-md-4">
		  <label for="symptoms">Symptoms</label>
			<textarea name="symptoms" class="form-control" id="symptoms" placeholder="Enter Symptoms"></textarea>
		</div>
		<div class="form-group col-md-4">
                <label for="checked">Checking Status</label>
                <select name="checked" class="form-control" id="checked">
					<option value="">Select Checking Status</option>
					<option value="1">Yes</option>
					<option value="0" selected>No</option>
				</select>
              </div>
	</div>
	<button type="submit" class="btn btn-primary">Submit</button>
	<button type="reset" class="btn btn-primary">Reset</button>
     </form>
    </div>
	</div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <?php include("footer.php");?>
	<script src="js/addpatient.js"></script>
</body>

</html>
