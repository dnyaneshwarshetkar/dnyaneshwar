<?php
	ini_set('display_errors', 1); 
	error_reporting(E_ALL);
    session_start();
    require "connect.php";
 
   if(isset($_POST['user']) | isset($_POST['dob']) )
   {
   $myusername = $_POST['user'];
   $mydob = $_POST['dob']; 
  
	$_SESSION['username']=$myusername;
	$_SESSION['passsword']=$mydob;
	$sql="SELECT * FROM doctor WHERE Doctor_id ='$myusername' AND dob='$mydob' ";
	$result = $con->query($sql);
	
	if($result->num_rows==1)
	{
		header("location: change.php");
	}
	else 
	{
		echo "<script>alert('invalid username and password');
		
					</script>";
	}
   }
   else
   {
	   echo "<script>alert('Enter Username or Password');
					window.location.assign('index.php');
					</script>";
   }

?>
