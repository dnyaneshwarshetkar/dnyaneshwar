var getRoomType = function(){
	var url = "server/get_data.php?room_type=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(roomTypeList){
				roomTypeList = JSON.parse(roomTypeList);
			    var mySelect = $('#room_type_id');
				$.each(roomTypeList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['room_type_id']).html(value['room_type']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getRoomType();

var getPatient = function(){
	var url = "server/get_data.php?patient=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(patientList){
				patientList = JSON.parse(patientList);
			    var mySelect = $('#patient_id');
				$.each(patientList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['patient_id']).html(value['first_name'] +" "+value['middle_name']+" "+value['last_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getPatient();

var getRoom = function(){
	var url = "server/get_data.php?room=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(roomTypeList){
				roomTypeList = JSON.parse(roomTypeList);
			    var mySelect = $('.room_id');
				$.each(roomTypeList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['room_id']).html(value['room_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getRoom();

var getBed = function(room_id){
	var url = "server/get_data.php?bed=true&data=true&room_id="+room_id;
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(bedList){
				bedList = JSON.parse(bedList);
				$('#bed_id').find('option').not(':first').remove();
			    var mySelect = $('#bed_id');
				$.each(bedList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['bed_id']).html(value['bed_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};

 var showBeds = function(){
	 $(".bed").show();
	  $(".room").hide();
	  $(".allocate").hide();
 }
 var showRooms = function(){
	  $(".bed").hide();
	  $(".room").show();
	  $(".allocate").hide();
 }
 var showAllocations = function(){
	  $(".bed").hide();
	  $(".room").hide();
	  $(".allocate").show();
 }
showRooms();
var addRoom = function(event,room_id){
	event.preventDefault();
	if(!!room_id){
		var url = "server/addroom.php?table=room&room_id="+room_id;
	}else{
		var url = "server/addroom.php?table=room";
	}
	var x = $('#roomForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  $('#roomForm')[0].reset();
			  $('form#roomForm h5').text("Add Room");
			  room.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}

var addBed = function(event,bed_id){
	event.preventDefault();
	if(!!bed_id){
		var url = "server/addroom.php?table=bed&bed_id="+bed_id;
	}else{
		var url = "server/addroom.php?table=bed";
	}
	var x = $('#bedForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  $('#bedForm')[0].reset();
			  $('form#bedForm h5').text("Add Bed");
			  bed.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}

var allocateBed = function(event,bed_patient_id){
	event.preventDefault();
	if(!!bed_patient_id){
		var url = "server/addroom.php?table=bed_patient&bed_patient_id="+bed_patient_id;
	}else{
		var url = "server/addroom.php?table=bed_patient";
	}
	var x = $('#allocateBedForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  $('#allocateBedForm')[0].reset();
			  $('form#allocateBedForm h5').text("Allocate Bed");
			  allocate.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}

$(document).ready(function(){
	//making medicine global object
	room = $('#roomTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?room=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "room_id"
		}, {
			data : "room_name"
		}, {
			data : "room_type"
		},{
			data : "room_description"
		},{
			data : "bed_price"
		}, {
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "room_id"
		}],
		'columnDefs': [{
		   'targets': 6,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0,\'room\')" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1,\'room\')" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '" onclick="editRoom(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button>'+status+'</div>';
		   }
		}]
	});
	$('#roomModal').on('hidden.bs.modal', function (e) {
		  $('#roomForm')[0].reset();
		  $('form#roomForm h5').text("Add Room");
	});
	bed = $('#bedTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?bed=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "bed_id"
		}, {
			data : "bed_name"
		}, {
			data : "room_name"
		},{
			data : "bed_description"
		}, {
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "bed_id"
		}],
		'columnDefs': [{
		   'targets': 5,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0,\'bed\')" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1,\'bed\')" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '" onclick="editBed(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button>'+status+'</div>';
		   }
		}]
	});
	$('#bedModal').on('hidden.bs.modal', function (e) {
		$('#bedForm')[0].reset();
	    $('form#bedForm h5').text("Add Bed");
    })

	allocate = $('#allocateTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?bed_patient=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "bed_patient_id"
		}, {
			data : "first_name",'render': function (data, type, full, meta){
			   return data +" "+full['middle_name']+" "+full['last_name'];
		   }
		}, {
			data : "room_name"
		},{
			data : "bed_name"
		},{
			data : "allocated_date"
		},{
			data : "release_date"
		}, {
			data : "bed_patient_id"
		}],
		'columnDefs': [{
		   'targets': 6,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '" onclick="releaseBed(this.value)" class="btn btn-success btn-sm"  title="Edit">Release Bed</button></div>';
		   }
		}]
	});
	$('#allocateBedModal').on('hidden.bs.modal', function (e) {
		$('#allocateBedForm')[0].reset();
    })
	
});
var editRoom = function(room_id){
	$('form#roomForm').attr('onsubmit','addRoom(event,'+room_id+')');
	$('form#roomForm h5').text("Edit Room");
	$.get("server/get_data.php?room=true&room_id="+room_id, function(data, status){
		data =JSON.parse(data);
		$.each(data, function(key, value){
				$('form#roomForm [name=' + key + ']').val(value);
				
		});
	});
	$("#roomModal").modal();
}
var editBed = function(bed_id){
	$('form#bedForm').attr('onsubmit','addBed(event,'+bed_id+')');
	$('form#bedForm h5').text("Edit Bed");
	$.get("server/get_data.php?bed=true&bed_id="+bed_id, function(data, status){
		data =JSON.parse(data);
		$.each(data, function(key, value){
				$('form#bedForm [name=' + key + ']').val(value);
		});
	});
	$("#bedModal").modal();
}
var changeStatus = function(id,status,tableName){
	if(tableName=='room'){
		var data = JSON.stringify({table:"room",room_id : id,status:status});
	}
	if(tableName=='bed'){
		var data = JSON.stringify({table:"bed",bed_id : id,status:status});
	}
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  if(tableName=='room'){
				  room.ajax.reload();
			  }
			  if(tableName=='bed'){
				  bed.ajax.reload();
			  }
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}

var releaseBed = function(bed_patient_id){
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
				  allocate.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}