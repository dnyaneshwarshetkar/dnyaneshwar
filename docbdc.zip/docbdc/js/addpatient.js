var getDoctor = function(){
	var url = "server/get_data.php?users=doctor&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(doctorList){
				doctorList = JSON.parse(doctorList);
			    var mySelect = $('#doctor_id');
				$.each(doctorList, function(key,value) {
					mySelect.append(
						$('<option></option>').val(value['doctor_id']).html(value['first_name'] +" " +value['middle_name'] +" "+ value['last_name']));
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getDoctor();
var submitData = function(event,patient_id){
	event.preventDefault();
	if(!!patient_id){
		var url = "server/addpatient.php?table=patient&patient_id="+patient_id;
	}else{
		var url = "server/addpatient.php?table=patient";
	}
	var x = $('#addPatientForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
var setAge = function(dob){
	$("#age").val(getAge(dob));
	return age;//in years
}
function getAge(dateString) {
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}
$(document).ready(function() {
	var params = getAllUrlParams(window.location.href);
	if(!!params['patient_id']){
	 editPatient(params['patient_id']);
	}
	});
var editPatient = function(patient_id){
	$.get("server/get_data.php?patient=true&patient_id="+patient_id, function(data, status){
		data =JSON.parse(data);
		$.each(data, function(key, value){
			if(key=='gender'){
				console.log(key,value);
				if(value=='male'){
					 $('form#addPatientForm #male').attr('checked','true');
				}
				if(value=='female'){
					$('form#addPatientForm #female').attr('checked','true');
				}
			}else{
				$('form#addPatientForm [name=' + key + ']').val(value);
			}
		});
	});
}