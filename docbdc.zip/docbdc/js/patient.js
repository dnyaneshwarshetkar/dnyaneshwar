var getMedicine = function(){
	var url = "server/get_data.php?medicine=true&data=true";
		$.ajax({
		  type: "GET",
		  url: url,
		  data: null,
		  success: function(medicineList){
			   $(".typeahead").typeahead({
				  displayText: function(item){
					  return item.medicine_name;
				  },
				  source: JSON.parse(medicineList),
				  autoSelect: false
				});
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getMedicine();


var submitData = function(event,patient_id){
	event.preventDefault();
	if(!!patient_id){
		var url = "server/addpatient.php?table=patient&patient_id="+patient_id;
	}else{
		var url = "server/addpatient.php?table=teacher";
	}
	var x = $('#addTeacherForm').serializeArray();
	var formData = {};
	$.each(x, function(_, kv) {
	  formData[kv.name] = kv.value;
	});
	formData = JSON.stringify(formData)
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
$(document).ready(function(){
	var params = getAllUrlParams(window.location.href);
	if(!!params['patient_id']){
		editPatient(params['patient_id']);
	}
	patient = $('#patientTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?patient=true&data=true",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "patient_id"
		}, {
			data : "first_name",render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		}, {
			data : "dfirst_name",render :function(data, type, row, meta){
				return data+" "+row['dmiddle_name']+" "+row['dlast_name'];
			}
		},{
			data : "gender"
		}, {
			data : "age"
		},{
			data : "marital_status",width:"10%","render":function(data, type, full, meta){
				if(data==0){
					return '<span>Married</span>';
				}else{
					return '<span>Unmarried</span>';
				}
			}
		},{
			data : "address"
		},{
			data : "mobile"
		},{
			data : "status",width:"10%","render":function(data, type, full, meta){
				if(data==1){
					return '<span>Active</span>';
				}else{
					return '<span>Inactive</span>';
				}
			}
		},{
			data : "patient_id"
		}],
		'columnDefs': [{
		   'targets': 9,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			    if(full.status==1){
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,0)" class="btn btn-success btn-sm"  title="Change Status">Change Status</button>'
			   }else{
				   var status = '<button value="' + $('<div/>').text(data).html() + '" onclick="changeStatus(this.value,1)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
			   }
			   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '" onclick="editData(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button><button value="' + $('<div/>').text(data).html() + '"  class="btn btn-success btn-sm prescription"  title="Prescription">Prescription</button>'+status+'</div>';
		   }
		}]
	});
	
	 $('#patientTable tbody').on( 'click', 'button.prescription', function () {
        var data = patient.row( $(this).parents('tr') ).data();
		prescription(data);
    });
	
});
var editData = function(patient_id){
	window.location.href = "addpatient.php?patient_id="+patient_id;
}
var selectedMedicines = [];
var prescriptionPatient ={};
var prescription = function(patientDetails){
	prescriptionPatient = patientDetails;
	$("#prescriptionModal h6").text(patientDetails['first_name']+" "+patientDetails['middle_name']+" "+patientDetails['last_name']);
	
	prescriptionList = $('#prescriptionHistoryTable').DataTable({
		processing : true,
		destroy: true,
		ajax: {
				url: "server/get_data.php?prescription=true&data=true&patient_id="+patientDetails.patient_id,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "prescription_id"
		}, {
			data : "first_name",render :function(data, type, row, meta){
				return data+" "+row['middle_name']+" "+row['last_name'];
			}
		}, {
			data : "date"
		},{
			data : "date_modified"
		},{
			data : "prescription_id"
		}],
		'columnDefs': [{
		   'targets': 4,
		   'searchable':false,
		   'orderable':false,
		   'className': 'dt-body-center',
		   'render': function (data, type, full, meta){
			   		   return '<div class="btn-group btn-group-sm"><button value="' + $('<div/>').text(data).html() + '"  class="btn btn-success btn-sm print"  title="Print ">Print</button></div>';
		   }
		}]
	});
	
	$('#prescriptionHistoryTable tbody').on( 'click', 'button.print', function () {
        var data = patient.row( $(this).parents('tr') ).data();
		prescription(data);
    });
	
	$("#prescriptionModal").modal();
}
var addPrescription = function(event){
	event.preventDefault();
	formData = new FormData(document.getElementById("prescriptionForm"));
	var object = {};
	formData.forEach(function(value, key){
		object[key] = value;
	});
	document.getElementById("prescriptionForm").reset();
	selectedMedicines.push(object);
	$.each(selectedMedicines,function(key,value){
		value['sr_no'] = key+1;
	});
	showList(selectedMedicines);
}
var showList = function(list){
	$(".selectedMedicines").loadTemplate("#medicine",list);
}
var removePrescription = function(sr_no){
	console.log(sr_no);
	selectedMedicines = $.grep(selectedMedicines,function(value,key){
		if(value['sr_no']!=sr_no){
			return true;
		}else{
			return false;
		}
	});
	$.each(selectedMedicines,function(key,value){
		value['sr_no'] = key+1;
	});
	showList(selectedMedicines);
}
var changeStatus = function(patient_id,status){
	var data = JSON.stringify({table:"patient",patient_id : patient_id,status:status});
	$.ajax({
		  type: "POST",
		  url: "server/change_status.php",
		  data: data,
		  success: function(data,status){
			  data = JSON.parse(data);
			  alert(data.message+" "+status);
			  location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}
var submitPrescription = function(prescription_id){
	if(!!prescription_id){
		var url = "server/addpatient.php?table=prescription&prescription_id="+prescription_id;
	}else{
		var url = "server/addpatient.php?table=prescription";
	}
	prescriptionPatient.prescription = selectedMedicines;
	formData = JSON.stringify(prescriptionPatient);
	$.ajax({
		  type: "POST",
		  url: url,
		  data: formData,
		  success: function(data,status){
			  data =JSON.parse(data);
			  alert(data.message);
			  prescriptionList.ajax.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
		});
}