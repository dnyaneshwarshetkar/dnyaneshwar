<?php

  session_start();

  require "connect.php";

  if(isset($_SESSION['username']))

  {

    $uname=$_SESSION['username'];

    $sql1 = "SELECT * FROM doctor where Doctor_id='$uname'";

    $result = $con->query($sql1);

    $fname = "";

    $lname = "";    

      $data = array();

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $fname=$row["fname"];

        $lname=$row["lname"];

        }

    }  

  } 

  else{

    header("location: index.php");

    }



    $Patient= $_GET["Patient_id"]; 

  if (isset($_GET["Patient_id"])) {

    $sql2 = "SELECT * FROM patient where Patient_id='$Patient'";

    $result = $con->query($sql2);

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $fir=$row["first"];

        $mid=$row["middle"];

        $las=$row["last"];

        $co=$row["Contact"];

        $dob=$row["dob"];

        $he=$row["Height"];

        $we=$row["Weight"];

        $te=$row["Temp"];

        $bp=$row["BP"];

        $sy=$row["Sym"];

        $Doctor=$row["Doctor_id"];

        }

    } 



   }

?>

<!DOCTYPE html>

<html lang="en">



<head>

  <meta charset="utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta name="description" content="">

  <meta name="author" content="">

  <title>Details | HMIS </title>

  <!-- Bootstrap core CSS-->

  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template-->

  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->

  <link href="css/sb-admin.css" rel="stylesheet">

  <script>

function myFunction() {

    window.print();

}

</script>

  <style type="text/css">

    #container{

      height: 100%;

      width: 100%;

    }

    #left{

      height: 1000px;

      float: left;

      width: 20%;

    }

    #center{

      height: 1000px;

      float: left;

      width: 60%;

    }

    #right{

      height: 1000px;

      float: left;

      width: 20%;

    }

    #doctor{

      float: right;

  width: 40%;

  height:100%;

    }

    #docpat{

      float: left;

  width: 20%;

    }

    #patient{

      float: left;

  width: 40%;

  height:100%;

    }

    #symtoms{

      float: left;

  width: 50%;

  height:100%;

    }

    #prescri{

      float: right;

  width: 50%;

  height:100%;

    }

    #medicine{

      float: left;

  width: 60%;

  height:100%;

    }

    #fees{

      float: right;

  width: 40%;

  height:100%;

    }

    #operation{

      float: left;

  width: 35%;

  height:100%;

    }

    #room{

      float: right;

  width: 65%;

  height:100%;

    }

  </style>

</head>



<body class="sticky-footer" id="page-top">

      <!-- Breadcrumbs-->

      





      <header class="text-center bg-dark ">

       <font color="white" size="20px">DOCBDC</font>

      </header>

      <br>

      <br>

      <div id="container">

      <div id="left"></div>

      <div id="center">

      <br>

      <div class="row">



        <div id="patient">

          <h5>Patient Details</h5>

            <p> Name :<?php echo $fir." ".$mid." ".$las;?></p>

            <p> Date of Birth : <?php echo $dob ;?></p>

            <p> Contact No : <?php echo $co ;?></p>





        </div>

        <div id="docpat"></div>

        <div id="doctor">

          <h5>Doctor Details</h5>

          <?php  $sql2 = "SELECT * FROM doctor where Doctor_id='$Doctor'";

       $result = $con->query($sql2);

        if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $fir1=$row["fname"];

        $las1=$row["lname"];

        $co1=$row["Contact_No"];

        $email=$row["email"];

        }

    } ?>

            <p> Name : <?php echo $fir1." ".$las1;?></p>

            <p> email id : <?php echo $email ;?></p>

            <p> Contact : <?php echo $co1 ;?></p>



        </div>

      </div>

      <hr>

      <br>

      <div class="row"> 

         

            <div id="prescri"><h5>Prescription</h5>

          <?php

         $sql2 = "SELECT * FROM prescription where Patient_id='$Patient'";

    $result = $con->query($sql2);

    if ($result->num_rows) 

    {

      while($row = $result->fetch_assoc()) 

      {

          echo $row["pres"]."<br>";

        }

    } ?>

        </div>

      </div>

      <hr>

      <br>

      <div class="row">

          <div id="medicine"><h5>Medicine</h5>

      <?php

         $sql2 = "SELECT * FROM medication where Patient_id='$Patient'";

    $result = $con->query($sql2);

    if ($result->num_rows) 

    {

      while($row = $result->fetch_assoc()) 

      {

          echo $row["Medicine_Name"]." - ".$row["Medicine_Dosage"]." - ".$row["quantity"]."<br>";

        }

    } ?>

          </div>

        

     <hr>

     </div>

              

     

     <br><br><br>

     <div class="row">

        <div class="col-md-4"></div>

           <!--<center><button onclick="myFunction()">Print this page</button> </center> -->



        <div class="col-md-4"></div>

      </div>

     



      </div>

      <div id="right"></div>

      </div>

    

    <!-- Scroll to Top Button-->

    <a class="scroll-to-top rounded" href="#page-top">

      <i class="fa fa-angle-up"></i>

    </a>

    <!-- Bootstrap core JavaScript-->

    <script src="vendor/jquery/jquery.min.js"></script>

    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->

    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->

    <script src="js/sb-admin.min.js"></script>

  </div>

</body>



</html>

