	<footer class="sticky-footer">
	  <div class="container">
		<div class="text-center">
		  <small>Copyright © <a href="http://nishthaventures.com/"> Nishtha Ventures Pvt. Ltd. 2018</a> </small>
		</div>
	  </div>
	</footer>
    <!-- Bootstrap core JavaScript-->
     <script src="vendor/jquery/jquery.min.js"></script>
	<!--<script src="js/popper.min.js"></script>-->
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
    <script src="js/sb-admin-charts.min.js"></script>
	<script src="js/typeahead.min.js"></script>
	<script src="js/jquery.loadTemplate.min.js"></script>
	<!--<script src="js/jquery.loadTemplate.min.js"></script>-->
	 <script src="js/basic.js"></script>