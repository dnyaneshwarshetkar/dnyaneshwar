<?php include("header.php") ?>
  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="admin.php">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">Medicine List</li>

      </ol>
	  
		<div class="btn-group btn-group-sm mb-2" role="group">
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#medicineModal">Add Medicine</button>
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#medicineStockModal">Add Medicine Stock</button>
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#saleMedicineModal">Sale Medicine</button>
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#orderMedicineModal">Order Medicine</button>
			
		</div>
          <div class="table-responsive">

            <table class="table table-bordered" id="medicineTable" width="100%" cellspacing="0">

              <thead>

                <tr>

                  <th>Sr.No</th>

                  <th>Medicine Name</th>
				  
				  <th>Quantity</th>

                  <th>Price</th>

                  <th>Selling Price</th>

				  <th>Status</th>
				  
				  <th>Manage</th>

                </tr>

              </thead>

              <tbody>
			  
              </tbody>

            </table>

          </div>
		<!--modal Starts for Medicine-->
		<div class="modal" tabindex="-1" role="dialog" id="medicineModal">
		  <div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<form  name="medicineForm" id="medicineForm" onsubmit="return addMedicine(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Add Medicine</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-6">
					  <label for="medicine_name">Name</label>
					  <input type="text" class="form-control" id="medicine_name" name="medicine_name" placeholder="Enter Medicine Name" required />
					</div>
					<div class="form-group col-sm-6">
					  <label for="medicine_description">Description</label>
					  <input type="text" class="form-control" id="medicine_description" name="medicine_description" placeholder="Enter Medicine Description"/>
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-6">
					  <label for="cgst">CGST</label>
					 <input type="number" class="form-control" id="cgst" name="cgst" placeholder="Enter CGST"  step="0.01" min="0" max="9" required  aria-describedby="cgstHelpBlock"/>
					 <small id="cgstHelpBlock" class="form-text text-muted">
						  in %
					</small>
					</div>
					<div class="form-group col-sm-6">
					  <label for="sgst">SGST</label>
					  <input type="number" class="form-control" id="sgst" name="sgst" placeholder="Enter SGST"  step="0.01" min="0" max="9" required aria-describedby="sgstHelpBlock"/>
					 <small id="sgstHelpBlock" class="form-text text-muted">
						  in %
					</small>
					</div>
				  </div>
				</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
		<!--modal for Medicine Stock-->
		<div class="modal" tabindex="-1" role="dialog" id="medicineStockModal">
		  <div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<form  name="medicineStockForm" id="medicineStockForm" onsubmit="return addMedicineStock(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Add Medicine Stock</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-6">
					  <label for="medicine_id">Select Medicine</label>
					  <select name="medicine_id" class="form-control" id="medicine_id" placeholder="Enter Doctor">
							<option value="">Select Medicine</option>
					   </select>
					</div>
					<div class="form-group col-md-6">
				      <label for="quantity">Quantity</label>
				      <input type="text" class="form-control" id="quantity" name="quantity" placeholder="Enter Quantity">
				   </div>
				  </div>
				  <div class="form-row">
				  <div class="form-group col-md-6">
				      <label for="price">Price</label>
				      <input type="text" class="form-control" id="price" name="price" placeholder="Enter Price">
				   </div>
				    <div class="form-group col-md-6">
				      <label for="selling_price">Selling Price</label>
				      <input type="text" class="form-control" id="selling_price" name="selling_price" placeholder="Enter Selling Price">
				   </div>
				  </div>
			</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
		<!--for selling of medicine-->
		<div class="modal" tabindex="-1" role="dialog" id="saleMedicineModal">
		  <div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<form  name="saleMedicineForm" id="saleMedicineForm" onsubmit="return addMedicineStock(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Sale Medicine</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-md-6">
				      <label for="cutomer_name">Customer Name</label>
				      <input type="text" class="form-control" id="cutomer_name" name="cutomer_name" placeholder="Enter Customer Name">
				   </div>
					<div class="form-group col-md-6">
				      <label for="mobile">Mobile</label>
				      <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Enter Mobile">
				   </div>
				  </div>
				  <div class="form-row">
					  <div class="form-group col-md-6">
						  <label for="medicine_id">Medicine Name</label>
						  <select name="medicine_id" class="form-control medicine_id" id="medicine_id" placeholder="Enter medicine">
							<option value="">Select Medicine</option>
					       </select>
					   </div>
						<div class="form-group col-md-6">
						  <label for="quantity">Quantity</label>
						  <input type="number" class="form-control" id="quantity" name="quantity" placeholder="Enter Quantity">
					   </div>
				  </div>
			</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
    </div>
</div>
<?php include("footer.php"); ?>
<script src="js/medicine.js"></script>
</body>

</html>