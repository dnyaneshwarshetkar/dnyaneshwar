<?php include("header.php") ?>
  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="admin.php">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">User List</li>

      </ol>

          <div class="table-responsive">

            <table class="table table-bordered" id="userTable" width="100%" cellspacing="0">

              <thead>

                <tr>

                  <th>Sr.No</th>

                  <th>User Name</th>
				  
				  <th>User Type</th>

                  <th>Gender</th>

                  <th>DOB</th>

                  <th>Email</th>

                  <th>Mobile</th>
				  
				  <th>Status</th>
				  
				  <th>Manage</th>

                </tr>

              </thead>

              <tbody>
			  
              </tbody>

            </table>

          </div>

    </div>
</div>
<?php include("footer.php"); ?>
<script src="js/user.js"></script>
</body>

</html>