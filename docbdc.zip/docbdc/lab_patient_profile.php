<?php

  session_start();

  require "connect.php";

  if(isset($_SESSION['username']))

  {

    $uname=$_SESSION['username'];

    $sql1 = "SELECT * FROM doctor where Doctor_id='$uname'";

    $result = $con->query($sql1);

    $fname = "";

    $lname = "";    

      $data = array();

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $fname=$row["fname"];

        $lname=$row["lname"];

        }

    }  

  } 

  else{

    header("location: index.php");

    } 



  $Patient= $_GET["Patient_id"]; 

  if (isset($_GET["Patient_id"])) {

    $sql2 = "SELECT * FROM patient where Patient_id='$Patient'";

    $result = $con->query($sql2);

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $fir=$row["first"];

        $mid=$row["middle"];

        $las=$row["last"];

        $ag=$row["age"];

        $co=$row["Contact"];

        $ad=$row["Address"];

        $he=$row["Height"];

        $we=$row["Weight"];

        $te=$row["Temp"];

        $bp=$row["BP"];

        $sy=$row["Sym"];

        }

    } 



   }





   //     REPORTS 

        //blood

  if (isset($_GET["Patient_id"])) {

      $sql2 = "SELECT * FROM report where Patient_id='$Patient' AND test='Blood'";

      $result = $con->query($sql2);

      $B="";

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $B = $row["test_result"];

        }



    }else{

      $B = "NONE";

    } 



   }



          //    urine

   if (isset($_GET["Patient_id"])) {

      $sql2 = "SELECT * FROM report where Patient_id='$Patient' AND test='Urine'";

      $result = $con->query($sql2);

      $U="";

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $U = $row["test_result"];

        }



    }else{

      $U = "NONE";

    } 



   }

          //    xray



   if (isset($_GET["Patient_id"])) {

      $sql2 = "SELECT * FROM report where Patient_id='$Patient' AND test='Xray'";

      $result = $con->query($sql2);

      $X="";

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $X = $row["test_result"];

        }



    }else{

      $X = "NONE";

    } 



   }

          // sonography

    if (isset($_GET["Patient_id"])) {

      $sql2 = "SELECT * FROM report where Patient_id='$Patient' AND test='Sonography'";

      $result = $con->query($sql2);

      $S="";

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $S = $row["test_result"];

        }



    }else{

      $S = "NONE";

    } 



   }



//    END REPORTS

             // presciption

/*

    if (isset($_GET["Patient_id"])) {

      $sql2 = "SELECT * FROM presciption where Patient_id='$Patient'";

      $result = $con->query($sql2);

      $I="";

      $j="";

    if ($result->num_rows) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $I = $row["pres"];

        $prc=$prc.$I;

        }



    }else{

      $prc = "NONE";

    } 



   }

*/

?>

<!DOCTYPE html>

<html lang="en">



<head>

  <meta charset="utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta name="description" content="">

  <meta name="author" content="">

  <title> Dashboard | HMIS </title>

  <!-- Bootstrap core CSS-->

  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template-->

  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->

  <link href="css/sb-admin.css" rel="stylesheet">

</head>



<body class="fixed-nav sticky-footer bg-dark" id="page-top">

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">

    <a class="navbar-brand" href="laboratorist.html"><?php echo $fname." ".$lname; ?></a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">

      <span class="navbar-toggler-icon"></span>

    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">

      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">

          <a class="nav-link" href="laboratorist.php">

            <i class="fa fa-fw fa-dashboard"></i>

            <span class="nav-link-text">Dashboard</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">

          <a class="nav-link" href="lab_patient_list.php">

            <i class="fa fa-fw fa-table"></i>

            <span class="nav-link-text">Patient</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">

          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseMulti" data-parent="#exampleAccordion">

            <i class="fa fa-fw fa-sitemap"></i>

            <span class="nav-link-text">Tests</span>

          </a>

          <ul class="sidenav-second-level collapse" id="collapseMulti">

            <li>

              <a href="blood.php">Blood Test</a>

            </li>

            <li>

              <a href="urine.php">Urine Test</a>

            </li>

            <li>

              <a href="sonography.php">Sonography</a>

            </li>

            <li>

              <a href="xray.php">X-ray</a>

            </li>

          </ul>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="lab_blood_bank.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Blood Bank</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="lab_blood_add.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Blood Donate</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="lab_payroll.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Payroll</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="lab_profile.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Profile</span>

          </a>

        </li>

      </ul>

      <ul class="navbar-nav sidenav-toggler">

        <li class="nav-item">

          <a class="nav-link text-center" id="sidenavToggler">

            <i class="fa fa-fw fa-angle-left"></i>

          </a>

        </li>

      </ul>

      <ul class="navbar-nav ml-auto">

        <li class="nav-item">

          <form class="form-inline my-2 my-lg-0 mr-lg-2">

            <div class="input-group">

              <input class="form-control" type="text" placeholder="Search for...">

              <span class="input-group-btn">

                <button class="btn btn-primary" type="button">

                  <i class="fa fa-search"></i>

                </button>

              </span>

            </div>

          </form>

        </li>

        <li class="nav-item">

          <a class="nav-link" href="logout.php">

            <i class="fa fa-fw fa-sign-out"></i>Logout</a>

        </li>

      </ul>

    </div>

  </nav>

  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="lab.php">Dashboard</a>

        </li>

        <li class="breadcrumb-item active"> Patient Information </li>

      </ol>

	  <br>

	  

	  

      <div class="row">

        <div class="col-12">

          <h3>Patient ID = <?php echo "$Patient"?></h3>

          
		  <br>

		  <form>

			<div class="form-group">

            <div class="form-row">

              <div class="col-md-4">

                <label for="exampleInputName">First name</label>

                <input class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="<?php echo $fir ;?>">

              </div>

			  <div class="col-md-4">

                <label for="exampleInputLastName">Middle name</label>

                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="<?php echo $mid; ?>">

              </div>

              <div class="col-md-4">

                <label for="exampleInputLastName">Last name</label>

                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="<?php echo $las; ?>">

              </div>

            </div>

			<br>

			<div class="form-row">

			  <div class="col-md-3">

                <label for="exampleInputName">Age</label>

                <input class="form-control" id="exampleInputName" type="number" aria-describedby="nameHelp" placeholder="<?php echo $ag; ?>">

              </div>

            </div>

			<br>

			<div class="form-row">

			  <div class="col-md-4">

				<label for="exampleInputName">Contact No.</label>

                <input class="form-control" id="exampleInputName" type="number" aria-describedby="nameHelp" placeholder="<?php echo $co; ?>">

              </div>

			  <div class="col-md-8">

				<label for="exampleInputName">Address</label>

                <input class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="<?php echo $ad; ?>">

              </div>

			</div>

          </div>

		  <br>		  

		  <br><br>

        </form>

		</div>

      </div><!-- row-->

	  

		  

		  <br><br>

		  <h3> Basic Info</h3>

    <form method="post" action="">



    <div class="form-row">



    <div class="col-md-3">

      <label for="exampleInputName">Height</label>

            <input name="hei" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="<?php echo $he; ?>">

    </div>

    <div class="col-md-3">

      <label for="exampleInputName">Weight</label>

            <input name="wei" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="<?php echo $we; ?>">        

    </div>

    <div class="col-md-3">

      <label for="exampleInputName">Temprature</label>

            <input name="temp" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="<?php echo $te; ?>">     

    </div>

    <div class="col-md-3">

      <label for="exampleInputName">Blood Pressure</label>

            <input name="blood" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="<?php echo $bp; ?>">        

    </div>

    </div>

      

    <br><br>

    </form>        

      <br>

      <!--  REPORT  -->

    <h3>Reports </h3>

      <div class="form-row">

        <div class="col-md-6">

            <label for="exampleInputName">Blood Report</label>

            <textarea name="sym" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp"><?php echo $B; ?> </textarea>



        </div>

        <div class="col-md-6">

            <label for="exampleInputName">Urine Report</label>

            <textarea name="sym" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp"><?php echo $U; ?> </textarea>



        </div>

        <div class="col-md-6">

            <label for="exampleInputName">Xray Report</label>

            <textarea name="sym" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp"><?php  echo $X; ?> </textarea>



        </div>

        <div class="col-md-6">

            <label for="exampleInputName">Sonography Report</label>

            <textarea class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp"><?php echo $S; ?> </textarea>



        </div>







      </div>



      <!--  REPORT  -->

<br><br>

       <h3> Symptoms</h3>

      

    <form method="post" action="">

            

    <div class="form-row">

      

    <div class="col-md-4">

      <label for="exampleInputName">Symptoms</label>

            <textarea class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp"><?php echo $sy; ?></textarea>       

    </div>

    <div class="col-md-4">

    <br>

    <br>

     </div>   

    </div>

      </form>



	  <br><br>

	<!--  <h3> Prescription </h3>

      <div class="form-row">

   

		<div class="col-md-6">

			<label for="exampleInputName">Prescription</label>

			<textarea class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp"><?php echo $prc; ?></textarea>

		</div>

		<div class="col-md-2">

						

		</div>

		<div class="col-md-4">

    <br>

		</div>

	  </div>

	  <br><br>

	  <br><br>

    </div>-->

    <!-- /.container-fluid-->

    <!-- /.content-wrapper-->

	

		  

		  <br><br>

		  

		  <br><br>

    <footer class="sticky-footer">

      <div class="container">

        <div class="text-center">

        <small>Copyright © <a href="http://nishthaventures.com/"> nishthaventures.com  2018 </a> </small>

        </div>

      </div>

    </footer>

    <!-- Scroll to Top Button-->

    <a class="scroll-to-top rounded" href="#page-top">

      <i class="fa fa-angle-up"></i>

    </a>

    <!-- Bootstrap core JavaScript-->

    <script src="vendor/jquery/jquery.min.js"></script>

    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->

    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->

    <script src="js/sb-admin.min.js"></script>

  </div>

</body>



</html>

