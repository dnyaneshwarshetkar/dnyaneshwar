<?php

  session_start();

  require "connect.php";

  if(isset($_SESSION['username']))

  {

    $uname=$_SESSION['username'];

    $sql1 = "SELECT * FROM doctor where Doctor_id='$uname'";

    $result = $con->query($sql1);

    $fname = "";

    $lname = "";    

      $data = array();

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $fname=$row["fname"];

        $lname=$row["lname"];

        }

    }  

  } 

  else{

    header("location: index.php");

    } 



    $Perform= $_GET["Perform_id"]; 

    if (isset($_GET["Perform_id"])) {

      $sql2 = "SELECT Patient_id,Operation_id FROM perform where Perform_id='$Perform'";

      $result = $con->query($sql2);

      $Patient="";

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $Patient = $row["Patient_id"];

        $Operation = $row["Operation_id"];

        }



    }

   }







  if (isset($_GET["Perform_id"])) {

    $sql2 = "SELECT * FROM patient where Patient_id='$Patient'";

    $result = $con->query($sql2);

    if ($result->num_rows==1) 

    {

      while($row = $result->fetch_assoc()) 

      {

        $fir=$row["first"];

        $mid=$row["middle"];

        $las=$row["last"];

        $he=$row["Height"];

        $we=$row["Weight"];

        $te=$row["Temp"];

        $bp=$row["BP"];

        $sy=$row["Sym"];

        }

    } 



   }



   if (isset($_POST['blood'])) {

      $bg=$_POST['bg'];

      $no=$_POST['no'];



    $sql = "SELECT price AS P FROM cost where test='blood_bag'";

    $result = $con->query($sql);

    $row = $result->fetch_assoc();

    $price = $row['P'];

    $costA= $price*$no;



    $sql3 = "INSERT INTO operation(Perform_id,Operation_id,Patient_id,tool_name,tool_quan,cost,cost_status) VALUES ('$Perform','$Operation','$Patient','blood_bag','$no','$costA','unpaid')";

      $sql2 = "UPDATE IGNORE blood_bank SET status = 'inactive' WHERE blood_group='A+' AND bag_id = (select bag_id from (SELECT MAX(bag_id) FROM blood_bank) as t) LIMIT '$no'";

      if($con->query($sql3) && $con->query($sql2)){

        echo "<script>alert('Updated Succesfully');</script>";

      }

      else{

                die('Could not add data'.mysql_error());

      }

  }





  if (isset($_POST['tool'])) {

      $to=$_POST['too'];

      $qua=$_POST['quan'];



    $sql = "SELECT price AS P FROM cost where test='$to'";

    $result = $con->query($sql);

    $row = $result->fetch_assoc();

    $price = $row['P'];

    $costB= $price*$qua;



    $sql3 = "INSERT INTO operation(Perform_id,Operation_id,Patient_id,tool_name,tool_quan,cost,cost_status) VALUES ('$Perform',$Operation','$Patient','$to','$qua','$costB','unpaid')";

     if($con->query($sql3)){

        echo "<script>alert('Inserted Succesfully');</script>";

      }

      else{

                die('Could not add data'.mysql_error());

      }

  }



  if (isset($_POST['doc'])) {

      $dr=$_POST['Dr'];

      $fee=$_POST['fee'];

      $add="Dr.".$dr;



    $sql3 = "INSERT INTO operation(Perform_id,Operation_id,Patient_id,tool_name,tool_quan,cost,cost_status) VALUES ('$Perform','$Operation','Patient','$add','1','$fee','unpaid')";

     if($con->query($sql3)){

        echo "<script>alert('Inserted Succesfully');</script>";

      }

      else{

                die('Could not add data'.mysql_error());

      }

  }



  if (isset($_POST['con'])) {

      $cons=$_POST['cons'];

     // $add="Dr.".$dr;



    $sql3 = "UPDATE perform SET Consultant_id='$cons' WHERE Perform_id='$Perform'";

     if($con->query($sql3)){

        echo "<script>alert('Added Succesfully');</script>";

      }

      else{

                die('Could not add data'.mysql_error());

      }

  }

?>

<!DOCTYPE html>

<html lang="en">



<head>

  <meta charset="utf-8">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <meta name="description" content="">

  <meta name="author" content="">

  <title>Operation | HMIS</title>

  <!-- Bootstrap core CSS-->

  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template-->

  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->

  <link href="css/sb-admin.css" rel="stylesheet">

</head>



<body class="fixed-nav sticky-footer bg-dark" id="page-top">

 <!-- Navigation-->

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">

    <a class="navbar-brand" href="doctor.php"><?php echo $fname." ".$lname; ?></a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">

    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">

      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">

          <a class="nav-link" href="doctor.php">

            <i class="fa fa-fw fa-dashboard"></i>

            <span class="nav-link-text">Dashboard</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">

          <a class="nav-link" href="doc_bed.php">

            <i class="fa fa-fw fa-table"></i>

            <span class="nav-link-text">Bed Allotment</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">

          <a class="nav-link" href="doc_patient_list.php">

            <i class="fa fa-fw fa-table"></i>

            <span class="nav-link-text">Patient</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">

          <a class="nav-link" href="operation.php">

            <i class="fa fa-fw fa-table"></i>

            <span class="nav-link-text">Operation Theater</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="blood_bank.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Blood Bank</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="blood_add.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Blood Donate</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="doc_payroll.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Payroll</span>

          </a>

        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">

          <a class="nav-link" href="doc_profile.php">

            <i class="fa fa-fw fa-link"></i>

            <span class="nav-link-text">Profile</span>

          </a>

        </li>

      </ul>

      <ul class="navbar-nav sidenav-toggler">

        <li class="nav-item">

          <a class="nav-link text-center" id="sidenavToggler">

            <i class="fa fa-fw fa-angle-left"></i>

          </a>

        </li>

      </ul>

      <ul class="navbar-nav ml-auto">

        <li class="nav-item">

          <form class="form-inline my-2 my-lg-0 mr-lg-2">

            <div class="input-group">

              <input class="form-control" type="text" placeholder="Search for...">

              <span class="input-group-btn">

                <button class="btn btn-primary" type="button">

                  <i class="fa fa-search"></i>

                </button>

              </span>

            </div>

          </form>

        </li>

        <li class="nav-item">

          <a class="nav-link" href="logout.php">

            <i class="fa fa-fw fa-sign-out"></i>Logout</a>

        </li>

      </ul>

    </div>

  </nav>

  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="doctor.php">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">Blank Page</li>

      </ol>

      <div class="row">

        <div class="col-8">

          <h3>Operation Room</h3>

          <h5>Patient ID = <?php echo "$Patient"?></h5>

      <br>

      <h3> Requirements</h3>

    <form method="post" action="">



    <div class="form-row">



    <div class="col-md-5">

      <label for="exampleInputName">Blood</label>

      <select name="bg" class="form-control" id="exampleInputName" aria-describedby="nameHelp">

        <option value="A+">A+</option>

        <option value="A-">A-</option>

        <option value="B+">B+</option>

        <option value="B-">B-</option>

        <option value="AB+">AB+</option>

        <option value="AB-">AB-</option>

        <option value="O+">O+</option>

        <option value="O-">O-</option>

      </select>

    </div>

    <div class="col-md-5">

      <label for="exampleInputName">No of bags</label>

            <input name="no" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="No of Bags">        

    </div>

    <div class="col-2">

    <br> &nbsp;   <input type="submit" name="blood" value="Add" class="btn btn-primary"/>

    </div>

    </div>

    </form>



      <br>

    <form method="post" action="">

    <div class="form-row">

    <div class="col-md-5">

      <label for="exampleInputName">Tools</label>

            <input name="too" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Assets">     

    </div>

    <div class="col-md-5">

      <label for="exampleInputName">Quantity</label>

            <input name="quan" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="Quantity">        

    </div>

    <div class="col-md-2">

          <br>&nbsp;   <input type="submit" name="tool" value="Add" class="btn btn-primary"/>

    </div>

    </div>

      

    <br><br>

    </form>



      

    </div>

    

    <div class="col-4"> 

    <div class="col-md-12">

     <h3>Add Consultant Details </h3>

     <form method="post" action="">

        <div class="form-group">

        <br>

            <div class="form-row">

                <label for="exampleInputName">Consultant Doctor</label>

            </div><br>

            <div class="form-row">

                  <input  name="cons" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Doctor Name">

                 <input type="submit" name="con" value="done" class="btn btn-primary"/>

            </div>



        </div>

    </form>





     </div>

    <div class="col-md-12">

    <h3> Add Doctor</h3>

    <form method="post" action="">

        <div class="form-group">

        <br>

            <div class="form-row">

                <label for="exampleInputName">Doctor</label>

                <input  name="Dr" class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Doctor Name">

            </div><br>

            <div class="form-row">

                <label for="exampleInputName">Fee</label>

                <input name="fee" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="Doctor Fee">

            </div><br>

            <div class="form-row">

                 <input type="submit" name="doc" value="Add" class="btn btn-primary"/>

            </div>



        </div>

    </form>

    </div>



     </div>

      </div><!-- row-->

      <br><br>

      <h3> Basic Info</h3>

    <form method="post" action="">  

      <div class="form-group">

            <div class="form-row">

              <div class="col-md-4">

                <label for="exampleInputName">First name</label>

                <input class="form-control" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="<?php echo $fir ;?>">

              </div>

        <div class="col-md-4">

                <label for="exampleInputLastName">Middle name</label>

                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="<?php echo $mid; ?>">

              </div>

              <div class="col-md-4">

                <label for="exampleInputLastName">Last name</label>

                <input class="form-control" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="<?php echo $las; ?>">

              </div>

            </div>

      <br>

          </div>

    <div class="form-row">



    <div class="col-md-3">

      <label for="exampleInputName">Height</label>

            <input name="hei" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="<?php echo $he; ?>">

    </div>

    <div class="col-md-3">

      <label for="exampleInputName">Weight</label>

            <input name="wei" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="<?php echo $we; ?>">        

    </div>

    <div class="col-md-3">

      <label for="exampleInputName">Temprature</label>

            <input name="temp" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="<?php echo $te; ?>">     

    </div>

    <div class="col-md-3">

      <label for="exampleInputName">Blood Pressure</label>

            <input name="blood" class="form-control" id="exampleInputName" type="integer" aria-describedby="nameHelp" placeholder="<?php echo $bp; ?>">        

    </div>

    </div>

      

    <br><br>

    </form>

    </div>

    <!-- /.container-fluid-->

    <!-- /.content-wrapper-->

    <footer class="sticky-footer">

      <div class="container">

        <div class="text-center">
<small>Copyright © <a href="http://nishthaventures.com/"> nishthaventures.com  2018 </a> </small>

        </div>

      </div>

    </footer>

    <!-- Scroll to Top Button-->

    <a class="scroll-to-top rounded" href="#page-top">

      <i class="fa fa-angle-up"></i>

    </a>

    <!-- Bootstrap core JavaScript-->

    <script src="vendor/jquery/jquery.min.js"></script>

    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->

    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->

    <script src="js/sb-admin.min.js"></script>

  </div>

</body>



</html>

