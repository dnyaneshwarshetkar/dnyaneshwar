<?php include("header.php") ?>
  <div class="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="admin.php">Dashboard</a>

        </li>

        <li class="breadcrumb-item active">Bed List</li>

      </ol>
	  
		<div class="btn-group btn-group-sm mb-2" role="group">
		
		    <button class="btn btn-secondary" data-toggle="modal" data-target="#roomModal"  data-backdrop="static" >Add Room</button>
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#bedModal"  data-backdrop="static" >Add Bed</button>
			
			<button class="btn btn-secondary" data-toggle="modal" data-target="#allocateBedModal"  data-backdrop="static" >Allocate Bed</button>
			
			<button class="btn btn-secondary" onclick="showBeds()">Beds</button>
			
			<button class="btn btn-secondary" onclick="showRooms()">Rooms</button>
			
			<button class="btn btn-secondary" onclick="showAllocations()">Allocations</button>
			
		</div>
          <div class="table-responsive room">
            <table class="table table-bordered" id="roomTable" width="100%" cellspacing="0">

              <thead>

                <tr>

                  <th>Sr.No</th>

                  <th>Room Name</th>
				  
				  <th>Room Type</th>
				  
				  <th>Room Description</th>

                  <th>Bed Price</th>

				  <th>Status</th>
				  
				  <th>Manage</th>

                </tr>

              </thead>

              <tbody>
			  
              </tbody>

            </table>
		</div>
         <div class="table-responsive bed">
            <table class="table table-bordered" id="bedTable" width="100%" cellspacing="0">

              <thead>

                <tr>

                  <th>Sr.No</th>

                  <th>Bed Name</th>
				  
				  <th>Room Name</th>

                  <th>Bed Description</th>

				  <th>Status</th>
				  
				  <th>Manage</th>

                </tr>

              </thead>

              <tbody>
			  
              </tbody>

            </table>

          </div>
		  <div class="table-responsive allocate">
            <table class="table table-bordered" id="allocateTable" width="100%" cellspacing="0">

              <thead>

                <tr>

                  <th>Sr.No</th>

                  <th>Patient Name</th>
				  
				  <th>Room Name</th>

                  <th>Bed Name</th>

				  <th>Allocated Date</th>
				  
				  <th>Release Date</th>
				  
				  <th>Manage</th>

                </tr>

              </thead>

              <tbody>
			  
              </tbody>

            </table>

          </div>
		  <!--modal Starts for Room-->
		<div class="modal" tabindex="-1" role="dialog" id="roomModal">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form  name="roomForm" id="roomForm" onsubmit="return addRoom(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Add Room</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="room_name">Name</label>
					  <input type="text" class="form-control" id="room_name" name="room_name" placeholder="Enter Room Name" required />
					</div>
				   </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="room_type_id">Room Type</label>
					  <select name="room_type_id" class="form-control" id="room_type_id" required />
							<option value="">Select Room Type</option>
					   </select>
					</div>
					</div>
					
					<div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="bed_price">Bed Price</label>
					  <input type="number" class="form-control" id="bed_price" name="bed_price"   step="0.01" min="0" placeholder="Enter Bed Price" required />
					</div>
					</div>
					<div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="bed_cgst">CGST</label>
					 <input type="number" class="form-control" id="bed_cgst" name="bed_cgst" placeholder="Enter CGST"  step="0.01" min="0" max="9" required  aria-describedby="cgstHelpBlock"/>
					 <small id="cgstHelpBlock" class="form-text text-muted">
						  in %
					</small>
					</div>
					</div>
					<div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="bed_sgst">SGST</label>
					  <input type="number" class="form-control" id="bed_sgst" name="bed_sgst" placeholder="Enter SGST"  step="0.01" min="0" max="9" required aria-describedby="sgstHelpBlock"/>
					 <small id="sgstHelpBlock" class="form-text text-muted">
						  in %
					</small>
					</div>
				  </div>
					<div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="room_description">Description</label>
					  <input type="text" class="form-control" id="room_description" name="room_description" placeholder="Enter Room Description"/>
					</div>
					</div>
				</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		  
		  
		<!--modal Starts for Bed-->
		<div class="modal" tabindex="-1" role="dialog" id="bedModal">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form  name="bedForm" id="bedForm" onsubmit="return addBed(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Add Bed</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="bed_name">Name</label>
					  <input type="text" class="form-control" id="bed_name" name="bed_name" placeholder="Enter Bed Name" required />
					</div>
					</div>
					<div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="room_id">Select Room</label>
					  <select name="room_id" class="form-control room_id" id="room_id" required />
							<option value="">Select Room</option>
					   </select>
					</div>
				  </div>
					<div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="bed_description">Description</label>
					  <input type="text" class="form-control" id="bed_description" name="bed_description" placeholder="Enter Bed Description"/>
					</div>
					</div>
				</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
		<!--modal for Allocate Bed-->
		<div class="modal" tabindex="-1" role="dialog" id="allocateBedModal">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
				<form  name="allocateBedForm" id="allocateBedForm" onsubmit="return allocateBed(event)">
			  <div class="modal-header">
				<h5 class="modal-title text-center">Allocate Bed </h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="patient_id">Select Patient</label>
					  <select name="patient_id" class="form-control" id="patient_id" required />
							<option value="">Select Patient</option>
					   </select>
					</div>
					</div>
					 <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="room_id">Select Room</label>
					  <select name="room_id" class="form-control room_id" id="room_id" onchange="getBed(this.value)" required />
							<option value="">Select Room</option>
					   </select>
					</div>
					</div>
					 <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="bed_id">Select Bed</label>
					  <select name="bed_id" class="form-control" id="bed_id" required />
							<option value="">Select Bed</option>
					   </select>
					</div>
				  </div>
				   <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="allocated_date">Allocated Date</label>
					  <input type="date" name="allocated_date"  class="form-control" id="allocated_date" required />
					</div>
				  </div>
				  <div class="form-row">
					<div class="form-group col-sm-12">
					  <label for="release_date">Release Date</label>
					  <input type="date" name="release_date"  class="form-control" id="release_date"/>
					</div>
				  </div>
			</div>
			  <div class="modal-footer">
				<button type="submit" class="btn btn-success">Submit</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			  </div>
			  </form>
			</div>
		  </div>
		</div>
		
    </div>
</div>
<?php include("footer.php"); ?>
<script src="js/bed.js"></script>
</body>

</html>