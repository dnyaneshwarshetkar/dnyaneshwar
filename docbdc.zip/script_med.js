function autocomplet(){
  var min_length = 0;
  var keyword = $('#med').val();
  if (keyword.length >= min_length) {
    $.ajax({
      url:'ajax_refresh_med.php',
      type:'POST',
      data: {keyword:keyword},
      success:function(data){
        $('#mad').show();
        $('#mad').html(data);
      }
    });
  }else{
    $('#mad').hide();
  }
}

function set_item(item){
  $('#med').val(item);
  $('#mad').hide();
}