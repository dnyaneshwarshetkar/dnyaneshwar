<?php

require_once("connect.php");

if(!empty($_POST["value"])) 

{

$query =mysqli_query($con,"SELECT * FROM  ".$_POST['value']);

?>

<option value="">Select User</option>

<?php

while($row=mysqli_fetch_array($query))  

{

?>

<option value="<?php echo $row['Contact_No']; ?>"><?php echo $row["fname"]; echo $row["lname"]?></option>

<?php

}

}

?>

