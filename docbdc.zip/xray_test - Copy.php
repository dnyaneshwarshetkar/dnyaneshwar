<?php
	ini_set('display_errors', 1); 
	error_reporting(E_ALL);
    session_start();
    require "connect.php";
	
    $sql1 = "SELECT price FROM cost where test='X-ray'";
    $result = $con->query($sql1);
    $price = "";  
  //    $data = array();
    if ($result->num_rows==1) 
    {
      while($row = $result->fetch_assoc()) 
      {
        $price=$row["price"];
      //  $lname=$row["lname"];
        }
    }
    	//echo $price;
	$Patient = $_GET['Patient_id']; 
   if(isset($_GET['Patient_id']))
   {
      $time=date('Y-m-d H:i:s');

//   echo $Patient;
   	$sql="INSERT INTO report(test,Patient_id,req_time,test_result,price) VALUES ('Xray','$Patient','$time','','$price')";
	if($con->query($sql)){
        echo "<script>alert('Xray Request Sent Succesfully');
       		window.location.assign('doctor.php');

         </script>";
      }
      else{
                die('Could not add data'.mysql_error());
      }	

   }
   else
   {
	   echo "<script>alert('Enter Username or Password');
					</script>";
   }
?>
